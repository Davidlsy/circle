"""
认证路由

处理用户注册、登录、Token 刷新、登出等请求。
业务逻辑委托给 AuthService 处理。
"""
from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.database import get_db
from app.models import User
from app.schemas import (
    UserCreate, UserPublic, TokenPair, Msg,
    ForgotPasswordRequest, ForgotPasswordResponse, ResetPasswordRequest,
    RefreshTokenRequest,
)
from app.auth import get_current_active_user
from app.services.auth_service import AuthService

router = APIRouter(prefix="/auth", tags=["认证"])

# 获取 limiter 实例（从 app.state 传递）
def get_limiter(request: Request) -> Limiter:
    return request.app.state.limiter


@router.post("/register", response_model=UserPublic, status_code=status.HTTP_201_CREATED)
@get_limiter.limit("5/minute")  # 注册限流：每分钟最多 5 次
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """
    用户注册
    - username: 唯一，必填，3-50字符
    - password: 必填，最少6字符
    - email/phone/nickname: 选填
    """
    service = AuthService(db)
    try:
        user = service.register(user_data)
        return user
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/login", response_model=TokenPair)
@get_limiter.limit("10/minute")  # 登录限流：每分钟最多 10 次
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """
    用户登录（OAuth2 兼容方式）
    - username 字段传用户名或邮箱
    - password 字段传密码
    返回 access_token 和 refresh_token
    """
    service = AuthService(db)
    try:
        return service.login(form_data.username, form_data.password)
    except ValueError as e:
        if "禁用" in str(e):
            raise HTTPException(status_code=400, detail=str(e))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e),
            headers={"WWW-Authenticate": "Bearer"},
        )


@router.post("/refresh", response_model=TokenPair)
@get_limiter.limit("20/minute")  # Token 刷新限流：每分钟最多 20 次
def refresh_token(request: RefreshTokenRequest, db: Session = Depends(get_db)):
    """
    使用 Refresh Token 刷新 Access Token
    - 验证 Refresh Token 有效性
    - 吊销旧 Refresh Token（一次性使用）
    - 签发新的 Access Token 和 Refresh Token
    """
    service = AuthService(db)
    try:
        return service.refresh_tokens(request.refresh_token)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e),
        )


@router.post("/logout", response_model=Msg)
def logout(request: RefreshTokenRequest, db: Session = Depends(get_db)):
    """
    登出（吊销当前 Refresh Token）
    - 前端需清除本地存储的 access_token 和 refresh_token
    """
    service = AuthService(db)
    revoked = service.logout(request.refresh_token)
    if revoked:
        return Msg(msg="登出成功")
    return Msg(msg="Token 已失效")


@router.post("/logout-all", response_model=Msg)
def logout_all(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """
    登出所有设备（吊销该用户的所有 Refresh Token）
    - 需要有效的 Access Token
    """
    service = AuthService(db)
    count = service.logout_all(current_user.id)
    return Msg(msg=f"已登出所有设备，共吊销 {count} 个 Refresh Token")


@router.post("/forgot-password", response_model=ForgotPasswordResponse)
@get_limiter.limit("3/minute")  # 找回密码限流：每分钟最多 3 次
def forgot_password(request: ForgotPasswordRequest, db: Session = Depends(get_db)):
    """
    发起找回密码
    - 凭用户名或邮箱查找用户
    - 生成6位验证码，存库（生产环境应通过邮件/短信发送）
    - 验证码15分钟内有效，且一次性使用
    """
    service = AuthService(db)
    return service.forgot_password(request.username)


@router.post("/reset-password", response_model=Msg)
@get_limiter.limit("5/minute")  # 重置密码限流：每分钟最多 5 次
def reset_password(request: ResetPasswordRequest, db: Session = Depends(get_db)):
    """
    重置密码
    - 验证6位验证码（一次性，15分钟内有效）
    - 验证通过后用新密码替换旧密码
    - 同时吊销该用户的所有 Refresh Token（安全措施）
    """
    service = AuthService(db)
    try:
        service.reset_password(request.code, request.new_password)
        return Msg(msg="密码重置成功，请使用新密码登录")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
