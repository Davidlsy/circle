from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # JWT 配置
    SECRET_KEY: str = "your-super-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 天

    # 数据库
    DATABASE_URL: str = "sqlite:///./fan_community.db"

    # 图片上传配置
    UPLOAD_DIR: str = "uploads"                    # 图片存储目录
    MAX_IMAGE_SIZE: int = 5 * 1024 * 1024          # 单张图片最大 5MB
    MAX_IMAGES_PER_POST: int = 9                    # 单篇帖子最多 9 张图
    ALLOWED_IMAGE_TYPES: list = ["image/jpeg", "image/png", "image/gif", "image/webp"]

    # CORS 配置
    # 生产环境请在 .env 文件中设置具体前端域名，逗号分隔，例如：
    # CORS_ORIGINS=http://localhost:3000,https://example.com
    CORS_ORIGINS: str = ""  # 空字符串表示仅允许本地开发，生产环境必须设置

    class Config:
        env_file = ".env"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
