"""
认证服务层

处理用户注册、登录、Token 刷新、密码重置等认证相关业务逻辑。
"""
from datetime import datetime, timedelta
from typing import Optional
from sqlalchemy.orm import Session
import secrets

from app.models import User, VerificationCode, RefreshToken
from app.services.base import BaseService
from app.auth import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    save_refresh_token,
    verify_refresh_token,
    revoke_refresh_token,
    revoke_all_refresh_tokens,
)
from app.config import get_settings
from app.constants import Auth
from app.schemas import UserCreate, TokenPair, ForgotPasswordResponse

settings = get_settings()


class AuthService(BaseService[User]):
    """认证服务"""

    def __init__(self, db: Session):
        super().__init__(db, User)
        self.verification_code_model = VerificationCode

    # ─── 用户注册 ───

    def register(self, user_data: UserCreate) -> User:
        """
        用户注册

        Args:
            user_data: 用户注册数据

        Returns:
            创建的用户对象

        Raises:
            ValueError: 用户名/邮箱/手机号已被注册
        """
        # 检查用户名唯一性
        if self.exists(username=user_data.username):
            raise ValueError("用户名已被注册")

        # 检查邮箱唯一性
        if user_data.email and self.exists(email=user_data.email):
            raise ValueError("邮箱已被注册")

        # 检查手机号唯一性
        if user_data.phone and self.exists(phone=user_data.phone):
            raise ValueError("手机号已被注册")

        # 创建用户
        return self.create(
            username=user_data.username,
            email=user_data.email,
            phone=user_data.phone,
            nickname=user_data.nickname or user_data.username,
            hashed_password=hash_password(user_data.password),
        )

    # ─── 用户登录 ───

    def login(self, username: str, password: str) -> TokenPair:
        """
        用户登录

        Args:
            username: 用户名或邮箱
            password: 密码

        Returns:
            TokenPair: 包含 access_token 和 refresh_token

        Raises:
            ValueError: 用户名或密码错误 / 用户已被禁用
        """
        # 查找用户（支持用户名或邮箱登录）
        user = self.db.query(User).filter(
            (User.username == username) | (User.email == username)
        ).first()

        if not user or not verify_password(password, user.hashed_password):
            raise ValueError("用户名或密码错误")

        if not user.is_active:
            raise ValueError("用户已被禁用")

        # 生成双 Token
        return self._generate_token_pair(user)

    # ─── Token 刷新 ───

    def refresh_tokens(self, refresh_token: str) -> TokenPair:
        """
        使用 Refresh Token 刷新 Access Token

        Args:
            refresh_token: 旧的 Refresh Token

        Returns:
            TokenPair: 新的双 Token

        Raises:
            ValueError: Refresh Token 无效或已过期
        """
        # 验证 Refresh Token
        stored = verify_refresh_token(self.db, refresh_token)
        if not stored:
            raise ValueError("Refresh Token 无效或已过期")

        # 验证用户是否仍然有效
        user = self.get_by_id(stored.user_id)
        if not user or not user.is_active:
            raise ValueError("用户不存在或已被禁用")

        # 吊销旧 Refresh Token（一次性使用）
        revoke_refresh_token(self.db, refresh_token)

        # 签发新的双 Token
        return self._generate_token_pair(user)

    def _generate_token_pair(self, user: User) -> TokenPair:
        """生成双 Token 并保存"""
        access_token = create_access_token(
            data={"sub": user.id},
            expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
        )
        refresh_token = create_refresh_token(
            data={"sub": user.id},
            expires_delta=timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        )
        save_refresh_token(self.db, user.id, refresh_token)

        return TokenPair(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer",
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    # ─── 登出 ───

    def logout(self, refresh_token: str) -> bool:
        """
        登出（吊销当前 Refresh Token）

        Returns:
            bool: 是否成功吊销
        """
        return revoke_refresh_token(self.db, refresh_token)

    def logout_all(self, user_id: int) -> int:
        """
        登出所有设备

        Returns:
            int: 吊销的 Token 数量
        """
        return revoke_all_refresh_tokens(self.db, user_id)

    # ─── 找回密码 ───

    def forgot_password(self, username: str) -> ForgotPasswordResponse:
        """
        发起找回密码

        Args:
            username: 用户名或邮箱

        Returns:
            ForgotPasswordResponse: 包含验证码（MVP 直接返回）
        """
        user = self.db.query(User).filter(
            (User.username == username) | (User.email == username)
        ).first()

        if not user:
            # 用户不存在也返回成功，防止恶意遍历
            return ForgotPasswordResponse(
                msg="如果账号存在，验证码已生成",
                code="------",
                expires_in_seconds=Auth.CODE_EXPIRE_MINUTES * 60
            )

        # 作废该用户的旧验证码
        self.db.query(VerificationCode).filter(
            VerificationCode.email == user.email,
            VerificationCode.purpose == "reset_password",
            VerificationCode.used == False
        ).update({"used": True})

        # 生成 6 位验证码
        code = "".join([str(secrets.randbelow(10)) for _ in range(6)])
        hashed_code = hash_password(code)

        verification = VerificationCode(
            email=user.email,
            phone=user.phone,
            code=hashed_code,
            purpose="reset_password",
            expires_at=datetime.utcnow() + timedelta(minutes=Auth.CODE_EXPIRE_MINUTES)
        )
        self.db.add(verification)
        self.db.commit()

        return ForgotPasswordResponse(
            msg="如果账号存在，验证码已生成",
            code=code,
            expires_in_seconds=Auth.CODE_EXPIRE_MINUTES * 60
        )

    def reset_password(self, code: str, new_password: str) -> None:
        """
        重置密码

        Args:
            code: 6 位验证码
            new_password: 新密码

        Raises:
            ValueError: 验证码无效或已过期
        """
        # 查找有效的验证码
        codes = self.db.query(VerificationCode).filter(
            VerificationCode.code != "------",
            VerificationCode.used == False,
            VerificationCode.expires_at > datetime.utcnow(),
            VerificationCode.purpose == "reset_password"
        ).order_by(VerificationCode.created_at.desc()).all()

        valid_code = None
        for vc in codes:
            if verify_password(code, vc.code):
                valid_code = vc
                break

        if not valid_code:
            raise ValueError("验证码无效或已过期")

        # 找到对应用户
        user = self.db.query(User).filter(User.email == valid_code.email).first()
        if not user:
            raise ValueError("用户不存在")

        # 更新密码
        user.hashed_password = hash_password(new_password)
        valid_code.used = True

        # 安全措施：吊销所有 Refresh Token
        revoke_all_refresh_tokens(self.db, user.id)

        self.db.commit()
