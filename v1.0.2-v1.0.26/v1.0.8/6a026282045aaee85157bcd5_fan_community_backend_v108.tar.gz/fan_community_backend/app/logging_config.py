"""
结构化日志配置

提供统一的日志格式，包含时间、级别、模块、请求信息等。
日志输出到控制台（开发环境），生产环境可扩展为文件或日志服务。
"""
import logging
import sys


def setup_logging(log_level: str = "INFO") -> None:
    """
    配置应用日志

    Args:
        log_level: 日志级别，默认 INFO。可选 DEBUG/INFO/WARNING/ERROR
    """
    log_format = (
        "%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s"
    )
    date_format = "%Y-%m-%d %H:%M:%S"

    # 根日志器
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # 清除已有 handler（防止重复）
    root_logger.handlers.clear()

    # 控制台 handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    console_handler.setFormatter(logging.Formatter(log_format, datefmt=date_format))
    root_logger.addHandler(console_handler)

    # 降低第三方库日志级别
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)

    # 应用日志器
    app_logger = logging.getLogger("app")
    app_logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    app_logger.info("日志系统初始化完成 | level=%s", log_level.upper())
