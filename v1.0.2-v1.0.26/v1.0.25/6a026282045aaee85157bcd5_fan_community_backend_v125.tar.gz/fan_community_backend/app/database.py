"""
数据库连接模块

自动检测数据库类型，配置合适的连接池：
- SQLite: 使用 StaticPool（单连接，适合开发和测试）
- MySQL / PostgreSQL: 使用 QueuePool（连接池，适合生产环境）

连接池参数可通过环境变量配置（DB_POOL_SIZE、DB_MAX_OVERFLOW 等）。
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import StaticPool, QueuePool

from app.config import get_settings
from app.logging_config import logger

settings = get_settings()

# ─── 解析数据库类型 ───
_database_url = settings.DATABASE_URL.lower()
_is_sqlite = _database_url.startswith("sqlite")


def _create_engine():
    """
    根据数据库类型创建引擎，自动配置连接池参数
    
    SQLite:
      - 使用 StaticPool（单连接，线程安全）
      - 必须设置 check_same_thread=False
    
    MySQL / PostgreSQL:
      - 使用 QueuePool（连接池）
      - 可配置 pool_size、max_overflow、pool_recycle、pool_timeout、pool_pre_ping
    """
    if _is_sqlite:
        logger.info("检测到 SQLite 数据库，使用 StaticPool（单连接模式）")
        return create_engine(
            settings.DATABASE_URL,
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
            echo=False,
        )
    else:
        logger.info(
            f"检测到生产数据库，使用 QueuePool "
            f"(pool_size={settings.DB_POOL_SIZE}, "
            f"max_overflow={settings.DB_MAX_OVERFLOW}, "
            f"pool_recycle={settings.DB_POOL_RECYCLE}s, "
            f"pool_timeout={settings.DB_POOL_TIMEOUT}s, "
            f"pool_pre_ping={settings.DB_POOL_PRE_PING})"
        )
        return create_engine(
            settings.DATABASE_URL,
            pool_size=settings.DB_POOL_SIZE,
            max_overflow=settings.DB_MAX_OVERFLOW,
            pool_recycle=settings.DB_POOL_RECYCLE,
            pool_timeout=settings.DB_POOL_TIMEOUT,
            pool_pre_ping=settings.DB_POOL_PRE_PING,
            echo=False,
        )


# ─── 创建引擎和会话 ───
engine = _create_engine()

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)

Base = declarative_base()


# ─── 依赖注入 ───

def get_db():
    """
    依赖注入：每个请求一个独立的数据库 session
    
    使用 try/finally 确保 session 在请求结束后正确关闭，
    即使请求处理过程中发生异常也不会泄漏连接。
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
