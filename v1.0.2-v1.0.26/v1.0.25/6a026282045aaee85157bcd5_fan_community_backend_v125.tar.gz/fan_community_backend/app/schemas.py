from __future__ import annotations
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List


# ─── 用户相关 ───

class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: Optional[str] = None
    phone: Optional[str] = None
    nickname: Optional[str] = None


class UserCreate(UserBase):
    password: str = Field(..., min_length=6, max_length=128)


class UserLogin(BaseModel):
    username: str
    password: str


class UserUpdate(BaseModel):
    nickname: Optional[str] = Field(None, max_length=50)
    avatar_url: Optional[str] = Field(None, max_length=500)
    bio: Optional[str] = Field(None, max_length=200)
    email: Optional[str] = Field(None, max_length=100)
    phone: Optional[str] = Field(None, max_length=20)


class UserPublic(BaseModel):
    id: int
    username: str
    nickname: Optional[str] = None
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    is_superuser: bool
    created_at: datetime

    class Config:
        from_attributes = True


class UserProfile(UserPublic):
    """用户公开资料（含粉丝数/关注数）"""
    follower_count: int = 0
    following_count: int = 0


# ─── 认证相关 ───

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    user_id: Optional[int] = None


# ─── 通用响应 ───

class Msg(BaseModel):
    msg: str


# ─── 图片相关（前置声明，避免 forward ref） ───

class PostImagePublic(BaseModel):
    id: int
    post_id: int
    url: str
    filename: str
    size: int
    order: int
    created_at: datetime

    class Config:
        from_attributes = True


# ─── 帖子相关 ───

class CommentBase(BaseModel):
    content: str = Field(..., min_length=1, max_length=2000)


class CommentCreate(CommentBase):
    post_id: int
    parent_id: Optional[int] = None


class CommentUpdate(BaseModel):
    content: str = Field(..., min_length=1, max_length=2000)


class CommentPublic(BaseModel):
    id: int
    content: str
    author_id: int
    post_id: int
    parent_id: Optional[int] = None
    status: str = "pending"
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class CommentWithAuthor(CommentPublic):
    author: UserPublic


class PostBase(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    content: str = Field(..., min_length=1)


class PostCreate(PostBase):
    is_published: bool = True


class PostUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    content: Optional[str] = Field(None, min_length=1)
    is_published: Optional[bool] = None


class PostPublic(BaseModel):
    id: int
    title: str
    content: str
    author_id: int
    is_published: bool
    status: str = "pending"   # pending / approved / rejected
    view_count: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class PostWithAuthor(PostPublic):
    author: UserPublic


class PostDetail(PostPublic):
    author: UserPublic
    comment_count: int = 0
    like_count: int = 0
    is_liked: bool = False
    collection_count: int = 0
    is_collected: bool = False
    images: List[PostImagePublic] = []
    tags: List[TagPublic] = []
    status: str = "pending"


class PostList(BaseModel):
    posts: List[PostDetail]
    total: int
    page: int
    page_size: int


class LikeResponse(BaseModel):
    msg: str
    liked: bool
    like_count: int


# ─── 关注相关 ───

class FollowResponse(BaseModel):
    msg: str
    following: bool
    follower_count: int
    following_count: int


class UserWithCounts(UserPublic):
    follower_count: int = 0
    following_count: int = 0


class UserList(BaseModel):
    users: List[UserWithCounts]
    total: int


class FollowStatus(BaseModel):
    is_following: bool
    is_followed_by: bool
    follower_count: int
    following_count: int


# ─── 找回密码相关 ───

class ForgotPasswordRequest(BaseModel):
    username: str = Field(..., description="用户名或注册邮箱")


class ForgotPasswordResponse(BaseModel):
    msg: str
    code: str = Field(..., description="6位验证码")
    expires_in_seconds: int


class ResetPasswordRequest(BaseModel):
    code: str = Field(..., min_length=6, max_length=6)
    new_password: str = Field(..., min_length=6, max_length=128)


# ─── 图片上传相关 ───

class ImageUploadResponse(BaseModel):
    images: List[PostImagePublic]
    uploaded_count: int
    post_id: int


class ImageDeleteResponse(BaseModel):
    msg: str
    remaining_count: int


# ─── 收藏相关 ───

class CollectionResponse(BaseModel):
    msg: str
    collected: bool
    collection_count: int


class CollectionList(BaseModel):
    posts: List[PostDetail]
    total: int
    page: int
    page_size: int


# ─── 私信相关 ───

class ConversationCreate(BaseModel):
    """发起或获取一个会话"""
    target_user_id: int


class ConversationPublic(BaseModel):
    id: int
    user1_id: int
    user2_id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ConversationListItem(BaseModel):
    """会话列表项：含对方用户信息、最后一条消息、未读数"""
    id: int
    other_user: UserPublic
    last_message: Optional["MessagePublic"] = None
    unread_count: int = 0
    updated_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ConversationList(BaseModel):
    conversations: List[ConversationListItem]
    total: int


class MessageSend(BaseModel):
    content: str = Field(..., min_length=1, max_length=2000)


class MessagePublic(BaseModel):
    id: int
    conversation_id: int
    sender_id: int
    content: str
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True


class MessageWithSender(MessagePublic):
    sender: UserPublic


class MessageList(BaseModel):
    messages: List[MessageWithSender]
    total: int
    page: int
    page_size: int


class MarkReadResponse(BaseModel):
    msg: str
    read_count: int


# ─── 标签/话题相关 ───

class TagPublic(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    post_count: int = 0
    created_at: datetime

    class Config:
        from_attributes = True


class TagList(BaseModel):
    tags: List[TagPublic]
    total: int


class PostTagPublic(BaseModel):
    id: int
    tag_id: int
    tag: TagPublic
    created_at: datetime

    class Config:
        from_attributes = True


class AddTagsRequest(BaseModel):
    tag_ids: List[int] = Field(..., min_length=1, max_length=9, description="最多9个标签ID")


# ─── 内容审核相关 ───

class AuditRequest(BaseModel):
    status: str = Field(..., description="审核状态: approved 或 rejected")
    reason: Optional[str] = Field(None, max_length=200, description="驳回原因（可选）")


class AuditResponse(BaseModel):
    msg: str
    id: int
    status: str


class PendingPostItem(BaseModel):
    id: int
    title: str
    content: str
    author: UserPublic
    created_at: datetime

    class Config:
        from_attributes = True


class PendingPostList(BaseModel):
    posts: List[PendingPostItem]
    total: int
    page: int
    page_size: int


class PendingCommentItem(BaseModel):
    id: int
    content: str
    author: UserPublic
    post_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class PendingCommentList(BaseModel):
    comments: List[PendingCommentItem]
    total: int
    page: int
    page_size: int
