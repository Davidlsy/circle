"""
用户模块单元测试

覆盖范围：
- 用户注册（正常注册、重复注册、参数校验）
- 用户登录（正常登录、错误密码、不存在用户）
- 用户信息获取（自己的信息、他人信息）
- 用户信息更新（正常更新、部分更新）
- 用户列表（分页、搜索）
- 密码修改（正常修改、错误旧密码）
"""
import pytest


# ═══════════════════════════════════════════════════════
# Fixtures
# ═══════════════════════════════════════════════════════

@pytest.fixture
def create_test_user(db):
    """创建测试用户的辅助函数"""
    from app.models import User
    from app.auth import hash_password
    
    def _create_user(username, is_superuser=False, is_active=True):
        user = User(
            username=username,
            email=f"{username}@example.com",
            hashed_password=hash_password("password123"),
            nickname=f"User {username}",
            is_active=is_active,
            is_superuser=is_superuser,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        return user
    return _create_user


@pytest.fixture
def auth_client(client, create_test_user):
    """获取已认证用户的测试客户端"""
    from app.auth import create_access_token
    
    user = create_test_user("testuser")
    token = create_access_token(data={"sub": user.id})
    client.headers = {"Authorization": f"Bearer {token}"}
    return client, user


@pytest.fixture
def admin_client(client, create_test_user):
    """获取管理员用户的测试客户端"""
    from app.auth import create_access_token
    
    admin = create_test_user("admin", is_superuser=True)
    token = create_access_token(data={"sub": admin.id})
    client.headers = {"Authorization": f"Bearer {token}"}
    return client, admin


# ═══════════════════════════════════════════════════════
# 一、用户注册测试
# ═══════════════════════════════════════════════════════

class TestUserRegister:
    """用户注册接口测试"""

    def test_register_success(self, client):
        """正常注册"""
        response = client.post("/v1/auth/register", json={
            "username": "newuser",
            "password": "password123",
            "email": "newuser@example.com",
            "nickname": "New User",
        })
        assert response.status_code == 201
        data = response.json()
        assert data["username"] == "newuser"
        assert data["email"] == "newuser@example.com"
        assert data["nickname"] == "New User"
        assert "id" in data
        assert "created_at" in data

    def test_register_duplicate_username(self, client, create_test_user):
        """重复用户名"""
        create_test_user("existing")
        response = client.post("/v1/auth/register", json={
            "username": "existing",
            "password": "password123",
        })
        assert response.status_code == 400
        assert "已被注册" in response.json()["detail"]

    def test_register_duplicate_email(self, client, create_test_user):
        """重复邮箱"""
        create_test_user("user1")
        response = client.post("/v1/auth/register", json={
            "username": "user2",
            "password": "password123",
            "email": "user1@example.com",
        })
        assert response.status_code == 400
        assert "已被注册" in response.json()["detail"]

    def test_register_password_too_short(self, client):
        """密码太短"""
        response = client.post("/v1/auth/register", json={
            "username": "shortpass",
            "password": "12345",
        })
        assert response.status_code == 422

    def test_register_missing_username(self, client):
        """缺少用户名"""
        response = client.post("/v1/auth/register", json={
            "password": "password123",
        })
        assert response.status_code == 422

    def test_register_missing_password(self, client):
        """缺少密码"""
        response = client.post("/v1/auth/register", json={
            "username": "nopassword",
        })
        assert response.status_code == 422


# ═══════════════════════════════════════════════════════
# 二、用户登录测试
# ═══════════════════════════════════════════════════════

class TestUserLogin:
    """用户登录接口测试"""

    def test_login_success(self, client, create_test_user):
        """正常登录"""
        create_test_user("logintest")
        response = client.post("/v1/auth/login", data={
            "username": "logintest",
            "password": "password123",
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"

    def test_login_with_email(self, client, create_test_user):
        """使用邮箱登录"""
        create_test_user("emailtest")
        response = client.post("/v1/auth/login", data={
            "username": "emailtest@example.com",
            "password": "password123",
        })
        assert response.status_code == 200
        assert "access_token" in response.json()

    def test_login_wrong_password(self, client, create_test_user):
        """错误密码"""
        create_test_user("wrongpass")
        response = client.post("/v1/auth/login", data={
            "username": "wrongpass",
            "password": "wrongpassword",
        })
        assert response.status_code == 401

    def test_login_nonexistent_user(self, client):
        """用户不存在"""
        response = client.post("/v1/auth/login", data={
            "username": "nonexistent",
            "password": "password123",
        })
        assert response.status_code == 401

    def test_login_inactive_user(self, client, create_test_user):
        """未激活用户登录"""
        user = create_test_user("inactive", is_active=False)
        response = client.post("/v1/auth/login", data={
            "username": "inactive",
            "password": "password123",
        })
        # 根据实际业务逻辑调整
        assert response.status_code in [401, 403]


# ═══════════════════════════════════════════════════════
# 三、用户信息获取测试
# ═══════════════════════════════════════════════════════

class TestGetUserInfo:
    """获取用户信息接口测试"""

    def test_get_current_user(self, auth_client):
        """获取当前用户信息"""
        client, user = auth_client
        response = client.get("/v1/users/me")
        assert response.status_code == 200
        data = response.json()
        assert data["username"] == user.username
        assert data["id"] == user.id

    def test_get_user_by_id(self, auth_client, create_test_user):
        """通过ID获取用户信息"""
        client, _ = auth_client
        other = create_test_user("other")
        response = client.get(f"/v1/users/{other.id}")
        assert response.status_code == 200
        data = response.json()
        assert data["username"] == "other"
        assert data["id"] == other.id

    def test_get_user_not_found(self, auth_client):
        """获取不存在的用户"""
        client, _ = auth_client
        response = client.get("/v1/users/99999")
        assert response.status_code == 404

    def test_get_user_unauthorized(self, client, create_test_user):
        """未认证获取用户信息"""
        user = create_test_user("test")
        response = client.get(f"/v1/users/{user.id}")
        # 根据实际业务逻辑调整
        # 可能允许未认证访问，也可能需要认证
        assert response.status_code in [200, 401]


# ═══════════════════════════════════════════════════════
# 四、用户信息更新测试
# ═══════════════════════════════════════════════════════

class TestUpdateUserInfo:
    """更新用户信息接口测试"""

    def test_update_nickname(self, auth_client):
        """更新昵称"""
        client, user = auth_client
        response = client.put("/v1/users/me", json={
            "nickname": "New Nickname",
        })
        assert response.status_code == 200
        assert response.json()["nickname"] == "New Nickname"

    def test_update_avatar(self, auth_client):
        """更新头像"""
        client, user = auth_client
        response = client.put("/v1/users/me", json={
            "avatar": "https://example.com/avatar.jpg",
        })
        assert response.status_code == 200
        assert response.json()["avatar"] == "https://example.com/avatar.jpg"

    def test_update_bio(self, auth_client):
        """更新个人简介"""
        client, user = auth_client
        response = client.put("/v1/users/me", json={
            "bio": "This is my bio",
        })
        assert response.status_code == 200
        assert response.json()["bio"] == "This is my bio"

    def test_update_multiple_fields(self, auth_client):
        """同时更新多个字段"""
        client, user = auth_client
        response = client.put("/v1/users/me", json={
            "nickname": "Updated Name",
            "bio": "Updated bio",
            "avatar": "https://example.com/new.jpg",
        })
        assert response.status_code == 200
        data = response.json()
        assert data["nickname"] == "Updated Name"
        assert data["bio"] == "Updated bio"
        assert data["avatar"] == "https://example.com/new.jpg"

    def test_update_user_unauthorized(self, client):
        """未认证更新用户信息"""
        response = client.put("/v1/users/me", json={
            "nickname": "Hacked",
        })
        assert response.status_code == 401


# ═══════════════════════════════════════════════════════
# 五、用户列表测试
# ═══════════════════════════════════════════════════════

class TestListUsers:
    """用户列表接口测试"""

    def test_list_users_empty(self, auth_client):
        """空用户列表（排除自己）"""
        client, user = auth_client
        response = client.get("/v1/users/")
        assert response.status_code == 200
        data = response.json()
        # 可能包含自己或其他用户，根据实际业务调整
        assert "users" in data
        assert "total" in data

    def test_list_users_with_data(self, auth_client, create_test_user):
        """有多个用户"""
        client, _ = auth_client
        for i in range(5):
            create_test_user(f"user{i}")
        
        response = client.get("/v1/users/")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] >= 5

    def test_list_users_pagination(self, auth_client, create_test_user):
        """用户列表分页"""
        client, _ = auth_client
        for i in range(15):
            create_test_user(f"pageuser{i}")
        
        response = client.get("/v1/users/?page=1&page_size=10")
        assert response.status_code == 200
        data = response.json()
        assert len(data["users"]) <= 10

    def test_list_users_search(self, auth_client, create_test_user):
        """搜索用户"""
        client, _ = auth_client
        create_test_user("searchable")
        
        response = client.get("/v1/users/?q=search")
        assert response.status_code == 200
        # 根据实际搜索功能调整断言


# ═══════════════════════════════════════════════════════
# 六、密码修改测试
# ═══════════════════════════════════════════════════════

class TestChangePassword:
    """修改密码接口测试"""

    def test_change_password_success(self, auth_client, client):
        """正常修改密码"""
        client_auth, user = auth_client
        response = client_auth.post("/v1/auth/change-password", json={
            "old_password": "password123",
            "new_password": "newpassword456",
        })
        assert response.status_code == 200
        
        # 使用新密码登录
        login_response = client.post("/v1/auth/login", data={
            "username": user.username,
            "password": "newpassword456",
        })
        assert login_response.status_code == 200

    def test_change_password_wrong_old(self, auth_client):
        """错误旧密码"""
        client, _ = auth_client
        response = client.post("/v1/auth/change-password", json={
            "old_password": "wrongpassword",
            "new_password": "newpassword456",
        })
        assert response.status_code == 400

    def test_change_password_too_short(self, auth_client):
        """新密码太短"""
        client, _ = auth_client
        response = client.post("/v1/auth/change-password", json={
            "old_password": "password123",
            "new_password": "12345",
        })
        assert response.status_code == 422

    def test_change_password_same_as_old(self, auth_client):
        """新密码与旧密码相同"""
        client, _ = auth_client
        response = client.post("/v1/auth/change-password", json={
            "old_password": "password123",
            "new_password": "password123",
        })
        # 根据实际业务逻辑调整
        # 可能允许相同密码，也可能返回错误
        assert response.status_code in [200, 400]


# ═══════════════════════════════════════════════════════
# 七、管理员功能测试
# ═══════════════════════════════════════════════════════

class TestAdminFunctions:
    """管理员功能测试"""

    def test_admin_get_all_users(self, admin_client, create_test_user):
        """管理员获取所有用户"""
        client, _ = admin_client
        for i in range(5):
            create_test_user(f"normal{i}")
        
        response = client.get("/v1/admin/users")
        # 根据实际管理员接口调整
        # assert response.status_code == 200

    def test_admin_delete_user(self, admin_client, create_test_user, db):
        """管理员删除用户"""
        from app.models import User
        
        client, _ = admin_client
        user = create_test_user("tobedeleted")
        
        # 根据实际管理员接口调整
        # response = client.delete(f"/v1/admin/users/{user.id}")
        # assert response.status_code == 200
        # 
        # # 验证用户已删除
        # deleted_user = db.query(User).filter(User.id == user.id).first()
        # assert deleted_user is None

    def test_normal_user_cannot_access_admin(self, auth_client):
        """普通用户不能访问管理员接口"""
        client, _ = auth_client
        # 根据实际管理员接口调整
        # response = client.get("/v1/admin/users")
        # assert response.status_code == 403


# ═══════════════════════════════════════════════════════
# 八、用户统计测试
# ═══════════════════════════════════════════════════════

class TestUserStats:
    """用户统计测试"""

    def test_user_post_count(self, auth_client, create_test_user, db):
        """用户帖子数统计"""
        from app.models import Post
        
        client, user = auth_client
        
        # 创建测试帖子
        for i in range(5):
            post = Post(
                title=f"Post {i}",
                content=f"Content {i}",
                author_id=user.id,
                status="approved",
            )
            db.add(post)
        db.commit()
        
        response = client.get("/v1/users/me")
        assert response.status_code == 200
        # 根据实际返回结构调整
        # assert response.json()["post_count"] == 5

    def test_user_stats_include_in_response(self, auth_client):
        """用户统计包含在响应中"""
        client, _ = auth_client
        response = client.get("/v1/users/me")
        assert response.status_code == 200
        data = response.json()
        # 检查是否包含统计字段
        # assert "post_count" in data
        # assert "follower_count" in data
        # assert "following_count" in data
