"""
关注模块单元测试

覆盖范围：
- 关注用户（正常关注、重复关注、关注自己、关注不存在用户）
- 取消关注（正常取消、未关注取消）
- 关注列表（粉丝列表、关注列表、互关好友）
- 关注状态检查（是否已关注）
"""
import pytest


# ═══════════════════════════════════════════════════════
# Fixtures
# ═══════════════════════════════════════════════════════

@pytest.fixture
def create_test_user(db):
    """创建测试用户的辅助函数"""
    from app.models import User
    from app.auth import hash_password
    
    def _create_user(username, is_superuser=False):
        user = User(
            username=username,
            email=f"{username}@example.com",
            hashed_password=hash_password("password123"),
            nickname=f"User {username}",
            is_active=True,
            is_superuser=is_superuser,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        return user
    return _create_user


@pytest.fixture
def auth_client(client, create_test_user):
    """获取已认证用户的测试客户端"""
    from app.auth import create_access_token
    
    user = create_test_user("testuser")
    token = create_access_token(data={"sub": user.id})
    client.headers = {"Authorization": f"Bearer {token}"}
    return client, user


@pytest.fixture
def create_follow(db):
    """创建关注关系的辅助函数"""
    from app.models import Follow
    
    def _create_follow(follower_id, following_id):
        follow = Follow(follower_id=follower_id, following_id=following_id)
        db.add(follow)
        db.commit()
        return follow
    return _create_follow


# ═══════════════════════════════════════════════════════
# 一、关注用户测试
# ═══════════════════════════════════════════════════════

class TestFollowUser:
    """关注用户接口测试"""

    def test_follow_user_success(self, auth_client, create_test_user, db):
        """正常关注用户"""
        from app.models import Follow
        
        client, user = auth_client
        target = create_test_user("target")
        
        response = client.post(f"/v1/users/{target.id}/follow")
        assert response.status_code == 200
        data = response.json()
        assert data["is_following"] is True
        assert "msg" in data
        
        # 验证数据库
        follow = db.query(Follow).filter(
            Follow.follower_id == user.id,
            Follow.following_id == target.id
        ).first()
        assert follow is not None

    def test_follow_already_following(self, auth_client, create_test_user, create_follow):
        """重复关注应返回已关注状态"""
        client, user = auth_client
        target = create_test_user("target")
        create_follow(user.id, target.id)
        
        response = client.post(f"/v1/users/{target.id}/follow")
        assert response.status_code == 200
        data = response.json()
        assert data["is_following"] is False  # 取消关注

    def test_follow_self(self, auth_client):
        """不能关注自己"""
        client, user = auth_client
        response = client.post(f"/v1/users/{user.id}/follow")
        assert response.status_code == 400
        assert "不能关注自己" in response.json()["detail"]

    def test_follow_nonexistent_user(self, auth_client):
        """关注不存在的用户"""
        client, _ = auth_client
        response = client.post("/v1/users/99999/follow")
        assert response.status_code == 404

    def test_follow_unauthorized(self, client, create_test_user):
        """未认证不能关注"""
        target = create_test_user("target")
        response = client.post(f"/v1/users/{target.id}/follow")
        assert response.status_code == 401


# ═══════════════════════════════════════════════════════
# 二、取消关注测试
# ═══════════════════════════════════════════════════════

class TestUnfollowUser:
    """取消关注接口测试"""

    def test_unfollow_user_success(self, auth_client, create_test_user, create_follow, db):
        """正常取消关注"""
        from app.models import Follow
        
        client, user = auth_client
        target = create_test_user("target")
        create_follow(user.id, target.id)
        
        response = client.post(f"/v1/users/{target.id}/follow")  # 再次调用是取消关注
        assert response.status_code == 200
        data = response.json()
        assert data["is_following"] is False
        
        # 验证数据库
        follow = db.query(Follow).filter(
            Follow.follower_id == user.id,
            Follow.following_id == target.id
        ).first()
        assert follow is None

    def test_unfollow_not_following(self, auth_client, create_test_user):
        """取消未关注的关系"""
        client, user = auth_client
        target = create_test_user("target")
        
        response = client.post(f"/v1/users/{target.id}/follow")
        # 第一次是关注，第二次才是取消
        # 这里测试的是第一次调用，应该是关注
        # 但因为我们没有预先创建关系，所以这里会创建关系
        # 这个测试用例可能需要根据实际业务逻辑调整
        assert response.status_code == 200

    def test_unfollow_nonexistent_user(self, auth_client):
        """取消关注不存在的用户"""
        client, _ = auth_client
        response = client.post("/v1/users/99999/follow")
        assert response.status_code == 404


# ═══════════════════════════════════════════════════════
# 三、关注列表测试
# ═══════════════════════════════════════════════════════

class TestFollowersList:
    """粉丝列表接口测试"""

    def test_get_followers_empty(self, auth_client):
        """没有粉丝"""
        client, user = auth_client
        response = client.get(f"/v1/users/{user.id}/followers")
        assert response.status_code == 200
        data = response.json()
        assert data["users"] == []
        assert data["total"] == 0

    def test_get_followers_with_data(self, auth_client, create_test_user, create_follow):
        """有粉丝的情况"""
        client, user = auth_client
        follower1 = create_test_user("follower1")
        follower2 = create_test_user("follower2")
        create_follow(follower1.id, user.id)
        create_follow(follower2.id, user.id)
        
        response = client.get(f"/v1/users/{user.id}/followers")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 2
        assert len(data["users"]) == 2

    def test_get_followers_pagination(self, auth_client, create_test_user, create_follow):
        """粉丝列表分页"""
        client, user = auth_client
        for i in range(15):
            follower = create_test_user(f"follower{i}")
            create_follow(follower.id, user.id)
        
        response = client.get(f"/v1/users/{user.id}/followers?page=1&page_size=10")
        assert response.status_code == 200
        data = response.json()
        assert len(data["users"]) == 10
        assert data["total"] == 15

    def test_get_followers_user_not_found(self, auth_client):
        """获取不存在用户的粉丝"""
        client, _ = auth_client
        response = client.get("/v1/users/99999/followers")
        assert response.status_code == 404


class TestFollowingList:
    """关注列表接口测试"""

    def test_get_following_empty(self, auth_client):
        """没有关注任何人"""
        client, user = auth_client
        response = client.get(f"/v1/users/{user.id}/following")
        assert response.status_code == 200
        data = response.json()
        assert data["users"] == []
        assert data["total"] == 0

    def test_get_following_with_data(self, auth_client, create_test_user, create_follow):
        """有关注的人"""
        client, user = auth_client
        following1 = create_test_user("following1")
        following2 = create_test_user("following2")
        create_follow(user.id, following1.id)
        create_follow(user.id, following2.id)
        
        response = client.get(f"/v1/users/{user.id}/following")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 2
        assert len(data["users"]) == 2

    def test_get_following_pagination(self, auth_client, create_test_user, create_follow):
        """关注列表分页"""
        client, user = auth_client
        for i in range(15):
            following = create_test_user(f"following{i}")
            create_follow(user.id, following.id)
        
        response = client.get(f"/v1/users/{user.id}/following?page=1&page_size=10")
        assert response.status_code == 200
        data = response.json()
        assert len(data["users"]) == 10
        assert data["total"] == 15


# ═══════════════════════════════════════════════════════
# 四、互关好友测试
# ═══════════════════════════════════════════════════════

class TestFriendsList:
    """互关好友列表接口测试"""

    def test_get_friends_empty(self, auth_client):
        """没有互关好友"""
        client, user = auth_client
        response = client.get("/v1/users/me/friends")
        assert response.status_code == 200
        data = response.json()
        assert data["users"] == []
        assert data["total"] == 0

    def test_get_friends_with_mutual(self, auth_client, create_test_user, create_follow):
        """有互关好友"""
        client, user = auth_client
        friend = create_test_user("friend")
        # 互相关注
        create_follow(user.id, friend.id)
        create_follow(friend.id, user.id)
        
        response = client.get("/v1/users/me/friends")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 1
        assert len(data["users"]) == 1
        assert data["users"][0]["username"] == "friend"

    def test_get_friends_not_mutual(self, auth_client, create_test_user, create_follow):
        """单方面关注不算好友"""
        client, user = auth_client
        following = create_test_user("following")
        # 只关注对方
        create_follow(user.id, following.id)
        
        response = client.get("/v1/users/me/friends")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 0

    def test_get_friends_pagination(self, auth_client, create_test_user, create_follow):
        """好友列表分页"""
        client, user = auth_client
        for i in range(15):
            friend = create_test_user(f"friend{i}")
            create_follow(user.id, friend.id)
            create_follow(friend.id, user.id)
        
        response = client.get("/v1/users/me/friends?page=1&page_size=10")
        assert response.status_code == 200
        data = response.json()
        assert len(data["users"]) == 10
        assert data["total"] == 15


# ═══════════════════════════════════════════════════════
# 五、关注状态检查测试
# ═══════════════════════════════════════════════════════

class TestFollowStatus:
    """关注状态检查测试"""

    def test_check_following_true(self, auth_client, create_test_user, create_follow):
        """已关注状态"""
        client, user = auth_client
        target = create_test_user("target")
        create_follow(user.id, target.id)
        
        # 通过获取用户信息检查关注状态
        response = client.get(f"/v1/users/{target.id}")
        assert response.status_code == 200
        # 根据实际 API 返回结构调整
        # assert response.json()["is_following"] is True

    def test_check_following_false(self, auth_client, create_test_user):
        """未关注状态"""
        client, user = auth_client
        target = create_test_user("target")
        
        response = client.get(f"/v1/users/{target.id}")
        assert response.status_code == 200
        # 根据实际 API 返回结构调整
        # assert response.json()["is_following"] is False


# ═══════════════════════════════════════════════════════
# 六、关注统计测试
# ═══════════════════════════════════════════════════════

class TestFollowStats:
    """关注统计测试"""

    def test_follower_count(self, auth_client, create_test_user, create_follow):
        """粉丝数统计"""
        client, user = auth_client
        for i in range(5):
            follower = create_test_user(f"follower{i}")
            create_follow(follower.id, user.id)
        
        response = client.get(f"/v1/users/{user.id}")
        assert response.status_code == 200
        # 根据实际 API 返回结构调整
        # assert response.json()["follower_count"] == 5

    def test_following_count(self, auth_client, create_test_user, create_follow):
        """关注数统计"""
        client, user = auth_client
        for i in range(3):
            following = create_test_user(f"following{i}")
            create_follow(user.id, following.id)
        
        response = client.get(f"/v1/users/{user.id}")
        assert response.status_code == 200
        # 根据实际 API 返回结构调整
        # assert response.json()["following_count"] == 3


# ═══════════════════════════════════════════════════════
# 七、边界情况测试
# ═══════════════════════════════════════════════════════

class TestFollowEdgeCases:
    """关注功能边界情况测试"""

    def test_follow_inactive_user(self, auth_client, create_test_user):
        """关注未激活用户"""
        from app.models import User
        
        client, user = auth_client
        inactive = create_test_user("inactive")
        inactive.is_active = False
        # 需要根据实际业务逻辑判断是否可以关注未激活用户
        
        response = client.post(f"/v1/users/{inactive.id}/follow")
        # 根据实际业务逻辑调整断言
        # assert response.status_code in [200, 400, 404]

    def test_follow_deleted_user(self, auth_client, create_test_user, db):
        """关注已删除用户"""
        from app.models import User
        
        client, user = auth_client
        deleted = create_test_user("deleted")
        db.delete(deleted)
        db.commit()
        
        response = client.post(f"/v1/users/{deleted.id}/follow")
        assert response.status_code == 404

    def test_mass_follow_performance(self, auth_client, create_test_user):
        """批量关注性能测试"""
        client, user = auth_client
        
        # 创建多个用户并关注
        for i in range(50):
            target = create_test_user(f"target{i}")
            response = client.post(f"/v1/users/{target.id}/follow")
            assert response.status_code == 200
        
        # 验证关注列表
        response = client.get(f"/v1/users/{user.id}/following")
        assert response.status_code == 200
        assert response.json()["total"] == 50
