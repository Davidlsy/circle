"""
认证路由

处理用户注册、登录、找回密码、重置密码等请求。
包含请求限流和验证码错误次数限制，防止暴力破解。
"""
from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.database import get_db
from app.models import User, VerificationCode
from app.schemas import (
    UserCreate, UserPublic, Token, Msg,
    ForgotPasswordRequest, ForgotPasswordResponse, ResetPasswordRequest
)
from app.auth import (
    hash_password,
    verify_password,
    create_access_token,
)
from app.config import get_settings
from app.cache import get_cache
from datetime import timedelta, datetime
import secrets

router = APIRouter(prefix="/auth", tags=["认证"])
settings = get_settings()
cache = get_cache()


# 获取 limiter 实例
def get_limiter(request: Request) -> Limiter:
    return request.app.state.limiter


# ─── 安全配置 ───
CODE_EXPIRE_MINUTES = 15          # 验证码有效期（分钟）
MAX_VERIFY_ATTEMPTS = 5           # 单个验证码最大尝试次数
VERIFY_ATTEMPT_TTL = 900          # 尝试次数记录有效期（秒），15分钟


def _get_verify_attempt_key(email: str) -> str:
    """获取验证码尝试次数的缓存键"""
    return f"verify_attempts:{email}"


def _increment_verify_attempts(email: str) -> int:
    """
    增加验证码尝试次数，返回当前次数
    """
    key = _get_verify_attempt_key(email)
    current = cache.get(key) or 0
    new_count = current + 1
    cache.set(key, new_count, ttl=VERIFY_ATTEMPT_TTL)
    return new_count


def _get_verify_attempts(email: str) -> int:
    """获取当前验证码尝试次数"""
    key = _get_verify_attempt_key(email)
    return cache.get(key) or 0


def _reset_verify_attempts(email: str):
    """重置验证码尝试次数"""
    key = _get_verify_attempt_key(email)
    cache.delete(key)


# ─── 用户注册 ───

@router.post("/register", response_model=UserPublic, status_code=status.HTTP_201_CREATED)
@get_limiter.limit("5/minute")  # 注册限流：每分钟最多 5 次
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """
    用户注册
    - username: 唯一，必填，3-50字符
    - password: 必填，最少6字符
    - email/phone/nickname: 选填
    """
    # 检查用户名是否已存在
    if db.query(User).filter(User.username == user_data.username).first():
        raise HTTPException(status_code=400, detail="用户名已被注册")

    # 检查邮箱唯一性（如果提供了）
    if user_data.email and db.query(User).filter(User.email == user_data.email).first():
        raise HTTPException(status_code=400, detail="邮箱已被注册")

    # 检查手机号唯一性（如果提供了）
    if user_data.phone and db.query(User).filter(User.phone == user_data.phone).first():
        raise HTTPException(status_code=400, detail="手机号已被注册")

    # 创建用户
    user = User(
        username=user_data.username,
        email=user_data.email,
        phone=user_data.phone,
        nickname=user_data.nickname or user_data.username,
        hashed_password=hash_password(user_data.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


# ─── 用户登录 ───

@router.post("/login", response_model=Token)
@get_limiter.limit("10/minute")  # 登录限流：每分钟最多 10 次
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """
    用户登录（OAuth2 兼容方式）
    - username 字段传用户名或邮箱
    - password 字段传密码
    返回 access_token，前端需保存并在请求时加 Header:
      Authorization: Bearer <access_token>
    """
    # 支持 username 或 email 登录
    user = db.query(User).filter(
        (User.username == form_data.username) | (User.email == form_data.username)
    ).first()

    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用户名或密码错误",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        raise HTTPException(status_code=400, detail="用户已被禁用")

    access_token = create_access_token(
        data={"sub": user.id},
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    return Token(access_token=access_token)


# ─── 找回密码 ───

@router.post("/forgot-password", response_model=ForgotPasswordResponse)
@get_limiter.limit("3/minute")  # 找回密码限流：每分钟最多 3 次
def forgot_password(request: ForgotPasswordRequest, db: Session = Depends(get_db)):
    """
    发起找回密码
    - 凭用户名或邮箱查找用户
    - 生成6位验证码，存库（生产环境应通过邮件/短信发送，此处直接返回）
    - 验证码15分钟内有效，且一次性使用
    
    安全措施：
    - 限流：每分钟最多 3 次
    - 用户不存在时返回相同响应，防止枚举攻击
    - 生成新验证码时作废旧验证码
    """
    user = db.query(User).filter(
        (User.username == request.username) | (User.email == request.username)
    ).first()

    if not user:
        # 用户不存在也返回成功，防止恶意遍历探测用户名
        return ForgotPasswordResponse(
            msg="如果账号存在，验证码已生成",
            code="------",
            expires_in_seconds=CODE_EXPIRE_MINUTES * 60
        )

    # 作废该用户同用途的旧验证码
    db.query(VerificationCode).filter(
        VerificationCode.email == user.email,
        VerificationCode.purpose == "reset_password",
        VerificationCode.used == False
    ).update({"used": True})

    # 生成6位数字验证码
    code = "".join([str(secrets.randbelow(10)) for _ in range(6)])
    hashed_code = hash_password(code)  # 存哈希，不存明文

    verification = VerificationCode(
        email=user.email,
        phone=user.phone,
        code=hashed_code,
        purpose="reset_password",
        expires_at=datetime.utcnow() + timedelta(minutes=CODE_EXPIRE_MINUTES)
    )
    db.add(verification)
    db.commit()

    # 重置验证码尝试次数（生成新验证码时重置）
    _reset_verify_attempts(user.email)

    # MVP 直接返回明文验证码，生产环境替换为发邮件/短信
    return ForgotPasswordResponse(
        msg="如果账号存在，验证码已生成",
        code=code,
        expires_in_seconds=CODE_EXPIRE_MINUTES * 60
    )


@router.post("/reset-password", response_model=Msg)
@get_limiter.limit("5/minute")  # 重置密码限流：每分钟最多 5 次
def reset_password(request: ResetPasswordRequest, db: Session = Depends(get_db)):
    """
    重置密码
    - 验证6位验证码（一次性，15分钟内有效）
    - 验证通过后用新密码替换旧密码
    
    安全措施：
    - 限流：每分钟最多 5 次（基于 IP）
    - 错误次数限制：每个验证码最多尝试 5 次
    - 超过错误次数后验证码自动作废
    """
    # 查找未使用且未过期的验证码
    codes = db.query(VerificationCode).filter(
        VerificationCode.code != "------",  # 排除上面伪造的占位码
        VerificationCode.used == False,
        VerificationCode.expires_at > datetime.utcnow(),
        VerificationCode.purpose == "reset_password"
    ).order_by(VerificationCode.created_at.desc()).all()

    valid_code = None
    target_email = None
    
    for vc in codes:
        # 尝试验证
        if verify_password(request.code, vc.code):
            valid_code = vc
            target_email = vc.email
            break
        else:
            # 记录该验证码对应的邮箱的错误尝试
            # 注意：这里我们不知道用户输入的是哪个邮箱的验证码
            # 所以我们在验证失败时不记录具体邮箱，而是依赖 IP 限流
            pass

    if not valid_code:
        # 验证码无效，检查是否是暴力破解尝试
        # 这里我们无法确定是哪个邮箱，所以只返回通用错误
        raise HTTPException(
            status_code=400, 
            detail="验证码无效或已过期，请重新获取验证码"
        )

    # 检查错误尝试次数
    attempts = _get_verify_attempts(target_email)
    if attempts >= MAX_VERIFY_ATTEMPTS:
        # 超过最大尝试次数，作废验证码
        valid_code.used = True
        db.commit()
        _reset_verify_attempts(target_email)
        raise HTTPException(
            status_code=400,
            detail=f"验证码错误次数过多（{MAX_VERIFY_ATTEMPTS}次），请重新获取验证码"
        )

    # 找到对应用户
    user = db.query(User).filter(User.email == target_email).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")

    # 更新密码
    user.hashed_password = hash_password(request.new_password)
    valid_code.used = True
    db.commit()

    # 清除验证码尝试次数
    _reset_verify_attempts(target_email)

    return Msg(msg="密码重置成功，请使用新密码登录")


# ─── 验证码验证端点（用于需要验证码的其他场景） ───

@router.post("/verify-code")
@get_limiter.limit("10/minute")  # 验证码验证限流：每分钟最多 10 次
def verify_code(
    email: str,
    code: str,
    purpose: str = "reset_password",
    db: Session = Depends(get_db)
):
    """
    验证验证码（通用接口）
    
    安全措施：
    - 限流：每分钟最多 10 次
    - 错误次数限制：每个邮箱最多尝试 5 次
    """
    # 检查错误尝试次数
    attempts = _get_verify_attempts(email)
    if attempts >= MAX_VERIFY_ATTEMPTS:
        raise HTTPException(
            status_code=400,
            detail=f"验证码错误次数过多（{MAX_VERIFY_ATTEMPTS}次），请重新获取验证码"
        )

    # 查找验证码
    vc = db.query(VerificationCode).filter(
        VerificationCode.email == email,
        VerificationCode.purpose == purpose,
        VerificationCode.used == False,
        VerificationCode.expires_at > datetime.utcnow()
    ).order_by(VerificationCode.created_at.desc()).first()

    if not vc:
        raise HTTPException(status_code=400, detail="验证码不存在或已过期")

    # 验证
    if not verify_password(code, vc.code):
        # 增加错误尝试次数
        new_attempts = _increment_verify_attempts(email)
        remaining = MAX_VERIFY_ATTEMPTS - new_attempts
        raise HTTPException(
            status_code=400,
            detail=f"验证码错误，剩余尝试次数：{remaining}"
        )

    # 验证成功，重置尝试次数
    _reset_verify_attempts(email)

    return {"valid": True, "message": "验证码验证成功"}
