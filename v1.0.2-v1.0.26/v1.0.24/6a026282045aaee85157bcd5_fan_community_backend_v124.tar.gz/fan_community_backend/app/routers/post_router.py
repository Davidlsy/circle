"""
帖子路由

处理帖子、评论、点赞、收藏、图片上传等请求。
使用子查询和 joinedload 优化 N+1 查询问题。
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session, joinedload, contains_eager
from sqlalchemy import func, select, case, literal_column
from typing import List, Optional, Dict, Set
from datetime import datetime
import os
import uuid
import shutil

from app.database import get_db
from app.models import User, Post, Comment, Like, PostImage, Collection, Tag, PostTag
from app.schemas import (
    PostCreate, PostUpdate, PostPublic, PostDetail, PostList,
    CommentCreate, CommentUpdate, CommentPublic, CommentWithAuthor,
    LikeResponse, Msg, UserPublic, PostImagePublic,
    ImageUploadResponse, ImageDeleteResponse, CollectionResponse,
    TagPublic
)
from app.auth import get_current_active_user
from app.config import get_settings
from app.cache import get_cache, CacheKeys

settings = get_settings()
router = APIRouter(prefix="/posts", tags=["帖子"])

# ─── 缓存实例 ───
cache = get_cache()


# ─── 工具函数 ───

def _ensure_upload_dir():
    """确保上传目录存在"""
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)


def _save_image_file(file: UploadFile) -> tuple[str, int]:
    """
    保存图片文件，返回 (filename, size)
    不返回完整 URL，路径存储在数据库，URL 由静态文件服务提供
    """
    _ensure_upload_dir()

    # 校验文件类型
    if file.content_type not in settings.ALLOWED_IMAGE_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"不支持的图片格式，仅支持：{', '.join(settings.ALLOWED_IMAGE_TYPES)}"
        )

    # 读取内容校验大小
    content = file.file.read()
    size = len(content)

    if size > settings.MAX_IMAGE_SIZE:
        max_mb = settings.MAX_IMAGE_SIZE / (1024 * 1024)
        raise HTTPException(
            status_code=400,
            detail=f"单张图片大小不能超过 {max_mb:.0f}MB，当前 {size / (1024*1024):.2f}MB"
        )

    if size == 0:
        raise HTTPException(status_code=400, detail="图片文件不能为空")

    # 生成唯一文件名，保留原始扩展名
    ext = os.path.splitext(file.filename or ".jpg")[1] or ".jpg"
    unique_name = f"{uuid.uuid4().hex}{ext}"
    file_path = os.path.join(settings.UPLOAD_DIR, unique_name)

    # 写文件
    with open(file_path, "wb") as f:
        f.write(content)

    return unique_name, size


def _build_image_url(filename: str, base_url: str = "/uploads") -> str:
    """构建图片的访问 URL"""
    return f"{base_url}/{filename}"


def _invalidate_post_cache(post_id: int):
    """失效帖子相关的所有缓存"""
    cache.delete(CacheKeys.post_detail(post_id))
    cache.delete(CacheKeys.post_comments(post_id))
    cache.delete(CacheKeys.post_images(post_id))
    # 按通配符清除帖子列表缓存
    cache.delete_pattern("post:list:*")


# ─── 帖子 CRUD ───

@router.post("/", response_model=PostPublic, status_code=status.HTTP_201_CREATED)
def create_post(
    post: PostCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """创建帖子（需审核：普通用户 pending，管理员 approved）"""
    initial_status = "approved" if current_user.is_superuser else "pending"
    db_post = Post(
        title=post.title,
        content=post.content,
        author_id=current_user.id,
        is_published=post.is_published,
        status=initial_status
    )
    db.add(db_post)
    db.commit()
    db.refresh(db_post)

    # 新建帖子时清除列表缓存
    cache.delete_pattern("post:list:*")

    return db_post


@router.get("/", response_model=PostList)
def list_posts(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=50),
    author_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_active_user)
):
    """
    获取帖子列表（分页，仅审核通过的帖子）
    
    性能优化：
    - 使用子查询预计算统计数据（comment_count, like_count, collection_count）
    - 使用 joinedload 预加载作者、图片、标签
    - 批量查询用户的点赞/收藏状态
    - 将 N+1 查询优化为固定 3-4 次查询
    """
    # 尝试读取缓存（仅未登录用户缓存公开数据）
    cache_key = CacheKeys.post_list(page, page_size, author_id or 0)
    if not current_user:
        cached = cache.get(cache_key)
        if cached is not None:
            return cached

    # ─── 第一步：查询帖子列表 ───
    query = db.query(Post).filter(Post.is_published == True)

    if current_user:
        query = query.filter(
            (Post.author_id == current_user.id) | (Post.status == "approved")
        )
    else:
        query = query.filter(Post.status == "approved")

    if author_id:
        query = query.filter(Post.author_id == author_id)

    total = query.count()
    
    # 使用 joinedload 预加载关联数据
    posts = query.options(
        joinedload(Post.author),
        joinedload(Post.images),
        joinedload(Post.tags).joinedload(PostTag.tag),
    ).order_by(Post.created_at.desc())\
        .offset((page - 1) * page_size)\
        .limit(page_size)\
        .all()

    if not posts:
        return PostList(posts=[], total=total, page=page, page_size=page_size)

    post_ids = [p.id for p in posts]

    # ─── 第二步：批量查询统计数据（子查询） ───
    # 一次查询获取所有帖子的统计数据
    stats_query = db.query(
        Comment.post_id.label('post_id'),
        func.count(Comment.id).label('comment_count')
    ).filter(Comment.post_id.in_(post_ids)).group_by(Comment.post_id)
    comment_stats = {row.post_id: row.comment_count for row in stats_query.all()}

    stats_query = db.query(
        Like.post_id.label('post_id'),
        func.count(Like.id).label('like_count')
    ).filter(Like.post_id.in_(post_ids)).group_by(Like.post_id)
    like_stats = {row.post_id: row.like_count for row in stats_query.all()}

    stats_query = db.query(
        Collection.post_id.label('post_id'),
        func.count(Collection.id).label('collection_count')
    ).filter(Collection.post_id.in_(post_ids)).group_by(Collection.post_id)
    collection_stats = {row.post_id: row.collection_count for row in stats_query.all()}

    # ─── 第三步：批量查询用户的点赞/收藏状态 ───
    liked_post_ids: Set[int] = set()
    collected_post_ids: Set[int] = set()
    
    if current_user:
        # 批量查询点赞状态
        liked_query = db.query(Like.post_id).filter(
            Like.post_id.in_(post_ids),
            Like.user_id == current_user.id
        )
        liked_post_ids = {row.post_id for row in liked_query.all()}

        # 批量查询收藏状态
        collected_query = db.query(Collection.post_id).filter(
            Collection.post_id.in_(post_ids),
            Collection.user_id == current_user.id
        )
        collected_post_ids = {row.post_id for row in collected_query.all()}

    # ─── 第四步：构建响应 ───
    post_details = []
    for p in posts:
        # 从预加载的关联数据获取图片和标签
        images = [PostImagePublic.model_validate(img) for img in p.images]
        tags = [TagPublic.model_validate(pt.tag) for pt in p.tags if pt.tag]

        post_details.append(PostDetail(
            id=p.id,
            title=p.title,
            content=p.content,
            author_id=p.author_id,
            is_published=p.is_published,
            view_count=p.view_count,
            created_at=p.created_at,
            updated_at=p.updated_at,
            author=UserPublic.model_validate(p.author),
            comment_count=comment_stats.get(p.id, 0),
            like_count=like_stats.get(p.id, 0),
            is_liked=p.id in liked_post_ids,
            images=images,
            collection_count=collection_stats.get(p.id, 0),
            is_collected=p.id in collected_post_ids,
            tags=tags,
            status=p.status
        ))

    result = PostList(posts=post_details, total=total, page=page, page_size=page_size)

    # 仅缓存公开数据（未登录用户视角）
    if not current_user:
        cache.set(cache_key, result, ttl=60)

    return result


@router.get("/{post_id}", response_model=PostDetail)
def get_post(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_active_user)
):
    """获取帖子详情（未审核帖子仅作者和管理员可见）"""
    # 使用 joinedload 预加载关联数据
    post = db.query(Post).options(
        joinedload(Post.author),
        joinedload(Post.images),
        joinedload(Post.tags).joinedload(PostTag.tag),
    ).filter(Post.id == post_id).first()
    
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")

    # 非管理员且非作者只能看 approved 帖子
    if post.status != "approved":
        if not current_user or (current_user.id != post.author_id and not current_user.is_superuser):
            raise HTTPException(status_code=404, detail="帖子不存在")

    # 增加浏览量
    post.view_count += 1
    db.commit()

    # 尝试读取缓存（仅 approved 帖子缓存，且不含用户个性化数据时）
    cache_key = CacheKeys.post_detail(post_id)
    if post.status == "approved" and not current_user:
        cached = cache.get(cache_key)
        if cached is not None:
            # 更新浏览量后返回（缓存中的 view_count 可能略旧，但可接受）
            return cached

    # 批量查询统计数据
    comment_count = db.query(func.count(Comment.id)).filter(Comment.post_id == post.id).scalar()
    like_count = db.query(func.count(Like.id)).filter(Like.post_id == post.id).scalar()
    collection_count = db.query(func.count(Collection.id)).filter(Collection.post_id == post.id).scalar()

    # 从预加载的关联数据获取图片和标签
    images = [PostImagePublic.model_validate(img) for img in post.images]
    tags = [TagPublic.model_validate(pt.tag) for pt in post.tags if pt.tag]

    is_liked = False
    is_collected = False
    if current_user:
        is_liked = db.query(Like).filter(
            Like.post_id == post.id,
            Like.user_id == current_user.id
        ).first() is not None
        is_collected = db.query(Collection).filter(
            Collection.post_id == post.id,
            Collection.user_id == current_user.id
        ).first() is not None

    result = PostDetail(
        id=post.id,
        title=post.title,
        content=post.content,
        author_id=post.author_id,
        is_published=post.is_published,
        view_count=post.view_count,
        created_at=post.created_at,
        updated_at=post.updated_at,
        author=UserPublic.model_validate(post.author),
        comment_count=comment_count,
        like_count=like_count,
        is_liked=is_liked,
        collection_count=collection_count,
        is_collected=is_collected,
        images=images,
        tags=tags,
        status=post.status
    )

    # 缓存 approved 帖子的公开版本
    if post.status == "approved" and not current_user:
        cache.set(cache_key, result, ttl=120)

    return result


@router.put("/{post_id}", response_model=PostPublic)
def update_post(
    post_id: int,
    post_update: PostUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """更新帖子（仅作者）"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")
    if post.author_id != current_user.id:
        raise HTTPException(status_code=403, detail="无权修改此帖子")

    update_data = post_update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(post, key, value)

    db.commit()
    db.refresh(post)

    # 更新帖子时清除相关缓存
    _invalidate_post_cache(post_id)

    return post


@router.delete("/{post_id}", response_model=Msg)
def delete_post(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除帖子（仅作者或超级管理员）"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")
    if post.author_id != current_user.id and not current_user.is_superuser:
        raise HTTPException(status_code=403, detail="无权删除此帖子")

    # 删除帖子关联的本地图片文件
    images = db.query(PostImage).filter(PostImage.post_id == post_id).all()
    for img in images:
        file_path = os.path.join(settings.UPLOAD_DIR, os.path.basename(img.url))
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass

    db.delete(post)
    db.commit()

    # 删除帖子时清除相关缓存
    _invalidate_post_cache(post_id)

    return Msg(msg="帖子已删除")


# ─── 评论 CRUD ───

@router.post("/{post_id}/comments", response_model=CommentPublic, status_code=status.HTTP_201_CREATED)
def create_comment(
    post_id: int,
    comment: CommentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """评论帖子"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")

    if comment.parent_id:
        parent = db.query(Comment).filter(Comment.id == comment.parent_id).first()
        if not parent or parent.post_id != post_id:
            raise HTTPException(status_code=400, detail="无效的回复目标")

    db_comment = Comment(
        content=comment.content,
        author_id=current_user.id,
        post_id=post_id,
        parent_id=comment.parent_id,
        status="approved" if current_user.is_superuser else "pending"
    )
    db.add(db_comment)
    db.commit()
    db.refresh(db_comment)

    # 新评论时清除帖子详情和评论列表缓存
    _invalidate_post_cache(post_id)

    return db_comment


@router.get("/{post_id}/comments", response_model=List[CommentWithAuthor])
def list_comments(
    post_id: int,
    db: Session = Depends(get_db)
):
    """获取帖子的评论列表"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")

    # 尝试读取缓存
    cache_key = CacheKeys.post_comments(post_id)
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    # 使用 joinedload 预加载作者
    comments = db.query(Comment).options(
        joinedload(Comment.author)
    ).filter(
        Comment.post_id == post_id,
        Comment.parent_id == None,
        Comment.status == "approved"
    ).order_by(Comment.created_at.desc()).all()

    result = [CommentWithAuthor(
        id=c.id,
        content=c.content,
        author_id=c.author_id,
        post_id=c.post_id,
        parent_id=c.parent_id,
        status=c.status,
        created_at=c.created_at,
        updated_at=c.updated_at,
        author=UserPublic.model_validate(c.author)
    ) for c in comments]

    # 缓存评论列表
    cache.set(cache_key, result, ttl=60)

    return result


@router.delete("/comments/{comment_id}", response_model=Msg)
def delete_comment(
    comment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除评论（仅作者或超级管理员）"""
    comment = db.query(Comment).filter(Comment.id == comment_id).first()
    if not comment:
        raise HTTPException(status_code=404, detail="评论不存在")
    if comment.author_id != current_user.id and not current_user.is_superuser:
        raise HTTPException(status_code=403, detail="无权删除此评论")

    post_id = comment.post_id
    db.delete(comment)
    db.commit()

    # 删除评论时清除帖子相关缓存
    _invalidate_post_cache(post_id)

    return Msg(msg="评论已删除")


# ─── 点赞功能 ───

@router.post("/{post_id}/like", response_model=LikeResponse)
def toggle_like(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """切换帖子点赞状态"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")

    existing_like = db.query(Like).filter(
        Like.post_id == post_id,
        Like.user_id == current_user.id
    ).first()

    if existing_like:
        db.delete(existing_like)
        db.commit()
        liked = False
        msg = "取消点赞成功"
    else:
        new_like = Like(user_id=current_user.id, post_id=post_id)
        db.add(new_like)
        db.commit()
        liked = True
        msg = "点赞成功"

    like_count = db.query(func.count(Like.id)).filter(Like.post_id == post_id).scalar()

    # 点赞变更时清除帖子详情缓存
    _invalidate_post_cache(post_id)

    return LikeResponse(msg=msg, liked=liked, like_count=like_count)


# ─── 图片上传 ───

@router.post("/{post_id}/images", response_model=ImageUploadResponse)
async def upload_images(
    post_id: int,
    files: List[UploadFile] = File(..., description="图片文件，最多9张，支持 jpeg/png/gif/webp"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    上传帖子图片

    - 单张图片最大 5MB
    - 单篇帖子最多 9 张图片
    - 支持格式：jpeg / png / gif / webp
    - 已有的图片不计入新上传数量限制检查
    - 图片 URL 通过 /uploads/{filename} 访问（需在 main.py 挂载静态文件）
    """
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")
    if post.author_id != current_user.id and not current_user.is_superuser:
        raise HTTPException(status_code=403, detail="无权为此帖上传图片")

    # 已有图片数量
    existing_count = db.query(func.count(PostImage.id)).filter(
        PostImage.post_id == post_id
    ).scalar()

    if existing_count >= settings.MAX_IMAGES_PER_POST:
        raise HTTPException(
            status_code=400,
            detail=f"该帖子已达到最大图片数量上限（{settings.MAX_IMAGES_PER_POST}张）"
        )

    remaining_slots = settings.MAX_IMAGES_PER_POST - existing_count
    if len(files) > remaining_slots:
        raise HTTPException(
            status_code=400,
            detail=f"最多只能再上传 {remaining_slots} 张图片，该帖子已有 {existing_count} 张"
        )

    # 获取当前最大 order
    max_order = db.query(func.max(PostImage.order)).filter(
        PostImage.post_id == post_id
    ).scalar() or 0

    saved_images = []
    for i, file in enumerate(files):
        try:
            filename, size = _save_image_file(file)
            order = max_order + i + 1
            url = _build_image_url(filename)

            db_image = PostImage(
                post_id=post_id,
                url=url,
                filename=file.filename or filename,
                size=size,
                order=order
            )
            db.add(db_image)
            saved_images.append(db_image)
        except HTTPException:
            # 单张失败，回滚已保存的文件
            db.rollback()
            for saved in saved_images:
                fpath = os.path.join(settings.UPLOAD_DIR, os.path.basename(saved.url))
                if os.path.exists(fpath):
                    try:
                        os.remove(fpath)
                    except OSError:
                        pass
            raise

    db.commit()
    for img in saved_images:
        db.refresh(img)

    # 上传图片后清除帖子图片缓存
    cache.delete(CacheKeys.post_images(post_id))
    _invalidate_post_cache(post_id)

    result = [PostImagePublic.model_validate(img) for img in saved_images]
    return ImageUploadResponse(
        images=result,
        uploaded_count=len(result),
        post_id=post_id
    )


@router.get("/{post_id}/images", response_model=List[PostImagePublic])
def get_post_images(
    post_id: int,
    db: Session = Depends(get_db)
):
    """获取帖子的所有图片"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")

    # 尝试读取缓存
    cache_key = CacheKeys.post_images(post_id)
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    images = db.query(PostImage).filter(
        PostImage.post_id == post_id
    ).order_by(PostImage.order, PostImage.created_at).all()
    result = [PostImagePublic.model_validate(img) for img in images]

    # 缓存图片列表
    cache.set(cache_key, result, ttl=120)

    return result


@router.delete("/images/{image_id}", response_model=ImageDeleteResponse)
def delete_image(
    image_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除指定图片（仅帖子作者或超管）"""
    image = db.query(PostImage).filter(PostImage.id == image_id).first()
    if not image:
        raise HTTPException(status_code=404, detail="图片不存在")

    post = db.query(Post).filter(Post.id == image.post_id).first()
    if post.author_id != current_user.id and not current_user.is_superuser:
        raise HTTPException(status_code=403, detail="无权删除此图片")

    # 删除本地文件
    filename = os.path.basename(image.url)
    file_path = os.path.join(settings.UPLOAD_DIR, filename)
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
        except OSError:
            pass

    post_id = image.post_id
    db.delete(image)
    db.commit()

    # 删除图片后清除缓存
    cache.delete(CacheKeys.post_images(post_id))
    _invalidate_post_cache(post_id)

    remaining = db.query(func.count(PostImage.id)).filter(
        PostImage.post_id == post_id
    ).scalar()

    return ImageDeleteResponse(
        msg="图片已删除",
        remaining_count=remaining
    )


# ─── 收藏功能 ───

@router.post("/{post_id}/collect", response_model=CollectionResponse)
def toggle_collection(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """收藏/取消收藏帖子（toggle）"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")

    existing = db.query(Collection).filter(
        Collection.post_id == post_id,
        Collection.user_id == current_user.id
    ).first()

    if existing:
        db.delete(existing)
        db.commit()
        collected = False
        msg = "取消收藏成功"
    else:
        new_collection = Collection(user_id=current_user.id, post_id=post_id)
        db.add(new_collection)
        db.commit()
        collected = True
        msg = "收藏成功"

    collection_count = db.query(func.count(Collection.id)).filter(
        Collection.post_id == post_id
    ).scalar()

    # 收藏变更时清除帖子详情缓存
    _invalidate_post_cache(post_id)

    return CollectionResponse(
        msg=msg,
        collected=collected,
        collection_count=collection_count
    )
