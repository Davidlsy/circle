"""
缓存工厂

根据配置创建缓存实例（单例模式）。
优先使用 Redis，不可用时自动降级为内存缓存。
"""
from functools import lru_cache

from app.cache.base import CacheBackend
from app.cache.redis_backend import RedisCacheBackend
from app.cache.memory_backend import MemoryCacheBackend
from app.config import get_settings
from app.logging_config import logger


@lru_cache(maxsize=1)
def get_cache() -> CacheBackend:
    """
    获取缓存实例（单例）

    优先使用 Redis，连接失败时降级为内存缓存。
    """
    settings = get_settings()

    # 尝试 Redis
    if settings.REDIS_URL:
        redis_cache = RedisCacheBackend(
            redis_url=settings.REDIS_URL,
            key_prefix=settings.CACHE_KEY_PREFIX,
            default_ttl=settings.CACHE_DEFAULT_TTL,
        )
        if redis_cache.available:
            return redis_cache
        logger.warning("Redis 不可用，降级为内存缓存")

    # 降级为内存缓存
    logger.info("使用内存缓存（开发/降级模式）")
    return MemoryCacheBackend(
        key_prefix=settings.CACHE_KEY_PREFIX,
        default_ttl=settings.CACHE_DEFAULT_TTL,
    )


# ─── 缓存键命名规范 ───

class CacheKeys:
    """缓存键命名规范常量"""

    # 帖子详情: post:detail:{post_id}
    POST_DETAIL = "post:detail:{post_id}"

    # 帖子列表: post:list:{page}:{page_size}:{author_id}
    POST_LIST = "post:list:{page}:{page_size}:{author_id}"

    # 帖子评论: post:comments:{post_id}
    POST_COMMENTS = "post:comments:{post_id}"

    # 用户资料: user:profile:{user_id}
    USER_PROFILE = "user:profile:{user_id}"

    # 用户关注数: user:counts:{user_id}
    USER_COUNTS = "user:counts:{user_id}"

    # 粉丝列表: user:followers:{user_id}:{page}:{page_size}
    USER_FOLLOWERS = "user:followers:{user_id}:{page}:{page_size}"

    # 关注列表: user:following:{user_id}:{page}:{page_size}
    USER_FOLLOWING = "user:following:{user_id}:{page}:{page_size}"

    # 帖子图片: post:images:{post_id}
    POST_IMAGES = "post:images:{post_id}"

    @staticmethod
    def post_detail(post_id: int) -> str:
        return CacheKeys.POST_DETAIL.format(post_id=post_id)

    @staticmethod
    def post_list(page: int, page_size: int, author_id: int = 0) -> str:
        return CacheKeys.POST_LIST.format(
            page=page, page_size=page_size, author_id=author_id
        )

    @staticmethod
    def post_comments(post_id: int) -> str:
        return CacheKeys.POST_COMMENTS.format(post_id=post_id)

    @staticmethod
    def user_profile(user_id: int) -> str:
        return CacheKeys.USER_PROFILE.format(user_id=user_id)

    @staticmethod
    def user_counts(user_id: int) -> str:
        return CacheKeys.USER_COUNTS.format(user_id=user_id)

    @staticmethod
    def user_followers(user_id: int, page: int, page_size: int) -> str:
        return CacheKeys.USER_FOLLOWERS.format(
            user_id=user_id, page=page, page_size=page_size
        )

    @staticmethod
    def user_following(user_id: int, page: int, page_size: int) -> str:
        return CacheKeys.USER_FOLLOWING.format(
            user_id=user_id, page=page, page_size=page_size
        )

    @staticmethod
    def post_images(post_id: int) -> str:
        return CacheKeys.POST_IMAGES.format(post_id=post_id)
