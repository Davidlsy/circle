"""
Redis 缓存后端

使用 redis-py 连接 Redis 服务，支持 JSON 序列化。
"""
import json
import fnmatch
from typing import Any, Optional

import redis

from app.cache.base import CacheBackend
from app.logging_config import logger


class RedisCacheBackend(CacheBackend):
    """Redis 缓存后端"""

    def __init__(self, redis_url: str, key_prefix: str = "fc:", default_ttl: int = 300):
        """
        初始化 Redis 连接

        - redis_url: Redis 连接地址，如 redis://localhost:6379/0
        - key_prefix: 键前缀，避免与其他应用冲突
        - default_ttl: 默认过期时间（秒），默认 5 分钟
        """
        self.key_prefix = key_prefix
        self.default_ttl = default_ttl
        self._client: Optional[redis.Redis] = None
        self._redis_url = redis_url

        try:
            self._client = redis.from_url(
                redis_url,
                decode_responses=True,
                max_connections=20,
                socket_timeout=5,
                socket_connect_timeout=5,
            )
            self._client.ping()
            logger.info(f"Redis 缓存连接成功: {redis_url}")
        except Exception as e:
            logger.warning(f"Redis 连接失败，将降级为内存缓存: {e}")
            self._client = None

    @property
    def available(self) -> bool:
        """Redis 是否可用"""
        return self._client is not None

    def _full_key(self, key: str) -> str:
        """添加前缀"""
        return f"{self.key_prefix}{key}"

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值"""
        if not self._client:
            return None
        try:
            data = self._client.get(self._full_key(key))
            if data is not None:
                return json.loads(data)
        except Exception as e:
            logger.warning(f"缓存读取失败 [{key}]: {e}")
        return None

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """设置缓存值"""
        if not self._client:
            return False
        try:
            ttl = ttl if ttl is not None else self.default_ttl
            self._client.setex(
                self._full_key(key),
                ttl,
                json.dumps(value, ensure_ascii=False, default=str),
            )
            return True
        except Exception as e:
            logger.warning(f"缓存写入失败 [{key}]: {e}")
            return False

    def delete(self, key: str) -> bool:
        """删除缓存键"""
        if not self._client:
            return False
        try:
            return self._client.delete(self._full_key(key)) > 0
        except Exception as e:
            logger.warning(f"缓存删除失败 [{key}]: {e}")
            return False

    def delete_pattern(self, pattern: str) -> int:
        """按通配符批量删除"""
        if not self._client:
            return 0
        try:
            full_pattern = self._full_key(pattern)
            keys = self._client.keys(full_pattern)
            if keys:
                return self._client.delete(*keys)
            return 0
        except Exception as e:
            logger.warning(f"缓存批量删除失败 [{pattern}]: {e}")
            return 0

    def exists(self, key: str) -> bool:
        """检查键是否存在"""
        if not self._client:
            return False
        try:
            return bool(self._client.exists(self._full_key(key)))
        except Exception:
            return False

    def clear(self) -> bool:
        """清空前缀下的所有缓存"""
        if not self._client:
            return False
        try:
            keys = self._client.keys(f"{self.key_prefix}*")
            if keys:
                self._client.delete(*keys)
            return True
        except Exception as e:
            logger.warning(f"缓存清空失败: {e}")
            return False

    def ping(self) -> bool:
        """检测连接"""
        if not self._client:
            return False
        try:
            return self._client.ping()
        except Exception:
            return False

    def close(self) -> None:
        """关闭连接"""
        if self._client:
            try:
                self._client.close()
            except Exception:
                pass
            self._client = None
