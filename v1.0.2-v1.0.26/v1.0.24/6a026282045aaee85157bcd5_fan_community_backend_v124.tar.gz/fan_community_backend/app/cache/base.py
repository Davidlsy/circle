"""
缓存后端抽象基类

定义缓存操作的统一接口。
"""
from abc import ABC, abstractmethod
from typing import Any, Optional


class CacheBackend(ABC):
    """缓存后端抽象基类"""

    @abstractmethod
    def get(self, key: str) -> Optional[Any]:
        """获取缓存值，不存在返回 None"""
        ...

    @abstractmethod
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """
        设置缓存值
        - key: 缓存键
        - value: 缓存值（需可 JSON 序列化）
        - ttl: 过期时间（秒），None 表示永不过期
        """
        ...

    @abstractmethod
    def delete(self, key: str) -> bool:
        """删除缓存键，返回是否成功"""
        ...

    @abstractmethod
    def delete_pattern(self, pattern: str) -> int:
        """
        按通配符模式批量删除
        - pattern: 如 "post:*" 或 "user:123:*"
        - 返回删除的键数量
        """
        ...

    @abstractmethod
    def exists(self, key: str) -> bool:
        """检查键是否存在"""
        ...

    @abstractmethod
    def clear(self) -> bool:
        """清空所有缓存"""
        ...

    @abstractmethod
    def ping(self) -> bool:
        """检测连接是否正常"""
        ...

    @abstractmethod
    def close(self) -> None:
        """关闭连接"""
        ...
