"""
内存缓存后端（降级方案）

当 Redis 不可用时自动使用内存缓存。
适合开发环境和单实例部署。
"""
import json
import time
import fnmatch
import threading
from typing import Any, Optional

from app.cache.base import CacheBackend


class MemoryCacheBackend(CacheBackend):
    """内存缓存后端（线程安全）"""

    def __init__(self, key_prefix: str = "fc:", default_ttl: int = 300):
        self.key_prefix = key_prefix
        self.default_ttl = default_ttl
        self._store: dict[str, tuple[float, Any]] = {}  # {key: (expire_at, value)}
        self._lock = threading.Lock()

    def _full_key(self, key: str) -> str:
        return f"{self.key_prefix}{key}"

    def _is_expired(self, key: str) -> bool:
        """检查是否过期"""
        if key in self._store:
            expire_at, _ = self._store[key]
            if expire_at is None or time.time() < expire_at:
                return False
            # 过期则清理
            del self._store[key]
        return True

    def get(self, key: str) -> Optional[Any]:
        full_key = self._full_key(key)
        with self._lock:
            if self._is_expired(full_key):
                return None
            return self._store[full_key][1]

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        full_key = self._full_key(key)
        expire_at = time.time() + ttl if ttl is not None else None
        with self._lock:
            self._store[full_key] = (expire_at, value)
        return True

    def delete(self, key: str) -> bool:
        full_key = self._full_key(key)
        with self._lock:
            if full_key in self._store:
                del self._store[full_key]
                return True
            return False

    def delete_pattern(self, pattern: str) -> int:
        full_pattern = self._full_key(pattern)
        count = 0
        with self._lock:
            keys_to_delete = [
                k for k in self._store
                if fnmatch.fnmatch(k, full_pattern)
            ]
            for k in keys_to_delete:
                del self._store[k]
                count += 1
        return count

    def exists(self, key: str) -> bool:
        full_key = self._full_key(key)
        with self._lock:
            return not self._is_expired(full_key)

    def clear(self) -> bool:
        with self._lock:
            self._store.clear()
        return True

    def ping(self) -> bool:
        return True

    def close(self) -> None:
        with self._lock:
            self._store.clear()
