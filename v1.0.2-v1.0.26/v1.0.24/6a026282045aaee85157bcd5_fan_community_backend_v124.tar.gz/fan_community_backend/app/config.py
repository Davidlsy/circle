"""
应用配置模块

所有敏感配置项必须通过环境变量设置，不提供默认值。
启动时会校验必要配置项是否已设置。
"""
import os
import sys
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # ─── JWT 配置 ───
    # SECRET_KEY 必须通过环境变量设置，不提供默认值
    # 生成方法: python -c "import secrets; print(secrets.token_urlsafe(32))"
    SECRET_KEY: str = ""  # 必须设置，否则启动失败
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 天

    # ─── 数据库配置 ───
    DATABASE_URL: str = "sqlite:///./fan_community.db"

    # ─── 图片上传配置 ───
    UPLOAD_DIR: str = "uploads"                    # 图片存储目录
    MAX_IMAGE_SIZE: int = 5 * 1024 * 1024          # 单张图片最大 5MB
    MAX_IMAGES_PER_POST: int = 9                    # 单篇帖子最多 9 张图
    ALLOWED_IMAGE_TYPES: list = ["image/jpeg", "image/png", "image/gif", "image/webp"]

    # ─── CORS 配置 ───
    # 生产环境请在 .env 文件中设置具体前端域名，逗号分隔，例如：
    # CORS_ORIGINS=http://localhost:3000,https://example.com
    CORS_ORIGINS: str = ""  # 空字符串表示仅允许本地开发，生产环境必须设置

    # ─── Redis 缓存配置 ───
    REDIS_URL: str = ""                            # Redis 连接地址，如 redis://localhost:6379/0
    CACHE_KEY_PREFIX: str = "fc:"                   # 缓存键前缀
    CACHE_DEFAULT_TTL: int = 300                    # 默认缓存过期时间（秒），5 分钟

    class Config:
        env_file = ".env"


@lru_cache()
def get_settings() -> Settings:
    """获取配置单例"""
    return Settings()


def validate_settings() -> None:
    """
    校验必要的配置项是否已设置
    
    在应用启动时调用，确保生产环境安全配置已正确设置。
    如果必要配置项未设置，将打印错误信息并退出程序。
    """
    settings = get_settings()
    errors = []
    
    # 校验 SECRET_KEY
    if not settings.SECRET_KEY:
        errors.append(
            "❌ SECRET_KEY 未设置！\n"
            "   请在 .env 文件或环境变量中设置 SECRET_KEY。\n"
            "   生成方法: python -c \"import secrets; print(secrets.token_urlsafe(32))\""
        )
    elif settings.SECRET_KEY == "your-super-secret-key-change-in-production":
        errors.append(
            "❌ SECRET_KEY 使用了不安全的默认值！\n"
            "   请生成新的密钥并在 .env 文件或环境变量中设置。"
        )
    elif len(settings.SECRET_KEY) < 32:
        errors.append(
            f"⚠️  SECRET_KEY 长度过短（{len(settings.SECRET_KEY)} 字符），建议至少 32 字符。"
        )
    
    # 校验生产环境 CORS 配置
    if not settings.CORS_ORIGINS and "sqlite" not in settings.DATABASE_URL:
        errors.append(
            "⚠️  生产环境建议设置 CORS_ORIGINS 以限制允许的前端域名。"
        )
    
    # 如果有错误，打印并退出
    if errors:
        print("\n" + "=" * 60)
        print("配置校验失败")
        print("=" * 60)
        for error in errors:
            print(error)
        print("=" * 60 + "\n")
        sys.exit(1)
    
    # 校验通过
    print("✅ 配置校验通过")
