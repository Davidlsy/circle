import time
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
from app.config import get_settings

# ─── 日志初始化（在导入其他模块之前） ───
from app.logging_config import logger

settings = get_settings()

from app.database import engine, Base
from app.schemas import Msg
from app.routers.auth_router import router as auth_router
from app.routers.post_router import router as post_router
from app.routers.follow_router import router as follow_router
from app.routers.message_router import router as message_router
from app.routers.feed_router import router as feed_router
from app.routers.tag_router import router as tag_router
from app.routers.audit_router import router as audit_router
from app.error_handlers import register_exception_handlers

# 创建所有表
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="粉丝社群平台 API",
    description="MVP 后端接口",
    version="1.0.13",
)

# ─── 注册全局异常处理器 ───
register_exception_handlers(app)

# ─── 请求日志中间件 ───
@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    """记录每个请求的耗时和状态码"""
    start_time = time.time()

    # 处理请求
    response = await call_next(request)

    # 计算耗时
    process_time = (time.time() - start_time) * 1000

    # 使用 loguru 记录访问日志
    logger.access(
        method=request.method,
        path=request.url.path,
        status=response.status_code,
        duration_ms=process_time,
        client=request.client.host if request.client else "unknown",
    )

    # 在响应头中添加耗时
    response.headers["X-Process-Time"] = f"{process_time:.1f}ms"
    return response

# CORS 配置：根据环境变量动态设置允许的前端域名
# 开发环境：CORS_ORIGINS 未设置或为空，仅允许 localhost
# 生产环境：CORS_ORIGINS 设置为具体前端域名，逗号分隔
_origins = settings.CORS_ORIGINS
if _origins:
    cors_origins = [origin.strip() for origin in _origins.split(",") if origin.strip()]
else:
    # 生产环境必须设置 CORS_ORIGINS，未设置时仅允许本地开发
    cors_origins = ["http://localhost:3000", "http://127.0.0.1:3000"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(auth_router)
app.include_router(post_router)
app.include_router(follow_router)
app.include_router(message_router)
app.include_router(feed_router)
app.include_router(tag_router)
app.include_router(audit_router)

# 静态文件：上传的图片（开发环境）
# 生产环境建议使用 Nginx 或 CDN 代理
if os.path.exists(settings.UPLOAD_DIR):
    app.mount("/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")


# ─── 健康检查 ───

@app.get("/", tags=["健康"])
def root():
    return {"msg": "粉丝社群平台 API 正常运行中"}


@app.get("/health", tags=["健康"])
def health():
    return {"status": "ok"}
