"""
动态流路由

处理关注用户帖子流请求。
业务逻辑委托给 PostService 处理，公共查询使用 query_helpers。
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional

from app.database import get_db
from app.models import User, Post, Follow
from app.schemas import PostList
from app.auth import get_current_active_user
from app.utils import build_post_detail

router = APIRouter(prefix="/feed", tags=["动态流"])


@router.get("/", response_model=PostList)
def get_feed(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=50),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    获取动态流（关注用户的帖子）

    - 返回当前用户关注的所有用户发布的帖子
    - 按发布时间倒序
    - 分页展示
    - 需登录
    """
    # 获取当前用户关注的所有用户ID
    following_ids = db.query(Follow.following_id).filter(
        Follow.follower_id == current_user.id
    ).all()
    following_id_list = [f[0] for f in following_ids]

    if not following_id_list:
        return PostList(posts=[], total=0, page=page, page_size=page_size)

    # 查询这些用户发布的帖子
    query = db.query(Post).filter(
        Post.author_id.in_(following_id_list),
        Post.is_published == True,
        Post.status == "approved"  # 只显示审核通过的帖子
    )

    total = query.count()
    posts = query.order_by(Post.created_at.desc())\
        .offset((page - 1) * page_size)\
        .limit(page_size)\
        .all()

    # 使用公共工具函数构建详情
    post_details = [build_post_detail(db, p, current_user.id) for p in posts]
    return PostList(posts=post_details, total=total, page=page, page_size=page_size)
