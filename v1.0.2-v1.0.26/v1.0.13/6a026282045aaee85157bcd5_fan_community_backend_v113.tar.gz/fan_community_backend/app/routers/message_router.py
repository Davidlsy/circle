"""
私信路由

处理私信会话、消息发送等请求。
业务逻辑委托给 MessageService 处理。
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User
from app.schemas import (
    ConversationCreate, ConversationPublic, ConversationList,
    ConversationListItem, MessageSend, MessagePublic,
    MessageWithSender, MessageList, MarkReadResponse,
    UserPublic, Msg
)
from app.auth import get_current_active_user
from app.services.message_service import MessageService

router = APIRouter(prefix="/messages", tags=["私信"])


@router.post("/conversations", response_model=ConversationPublic)
def get_or_create_conversation(
    data: ConversationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    获取或创建一个与目标用户的私信会话
    如果已有会话则返回已有会话，不重复创建
    """
    service = MessageService(db)
    try:
        conv = service.get_or_create_conversation(current_user.id, data.target_user_id)
        return conv
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/conversations", response_model=ConversationList)
def list_conversations(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    获取当前用户的会话列表
    按最新消息时间倒序，含未读计数
    """
    service = MessageService(db)
    conversations = service.list_conversations(current_user.id)
    return ConversationList(conversations=conversations, total=len(conversations))


@router.post("/conversations/{conv_id}/messages", response_model=MessageWithSender)
def send_message(
    conv_id: int,
    data: MessageSend,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """在指定会话中发送消息"""
    service = MessageService(db)
    try:
        return service.send_message(conv_id, current_user.id, data.content)
    except ValueError as e:
        if "无权" in str(e):
            raise HTTPException(status_code=403, detail=str(e))
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/conversations/{conv_id}/messages", response_model=MessageList)
def list_messages(
    conv_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=50),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取会话中的消息列表（分页，最新消息在前）"""
    service = MessageService(db)
    try:
        messages, total = service.list_messages(
            conv_id,
            current_user.id,
            page=page,
            page_size=page_size
        )
        return MessageList(messages=messages, total=total, page=page, page_size=page_size)
    except ValueError as e:
        if "无权" in str(e):
            raise HTTPException(status_code=403, detail=str(e))
        raise HTTPException(status_code=404, detail=str(e))


@router.put("/conversations/{conv_id}/read", response_model=MarkReadResponse)
def mark_all_as_read(
    conv_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """将会话中所有对方发的消息标记为已读"""
    service = MessageService(db)
    try:
        count = service.mark_all_as_read(conv_id, current_user.id)
        return MarkReadResponse(msg="已标记为已读", read_count=count)
    except ValueError as e:
        if "无权" in str(e):
            raise HTTPException(status_code=403, detail=str(e))
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/conversations/unread-count", response_model=dict)
def total_unread_count(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取当前用户所有会话的未读消息总数"""
    service = MessageService(db)
    total = service.get_total_unread(current_user.id)
    return {"unread_total": total}
