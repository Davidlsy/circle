"""
用户/关注路由

处理用户资料、关注关系等请求。
业务逻辑委托给 UserService 处理。
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User
from app.schemas import (
    FollowResponse, FollowStatus, UserWithCounts,
    UserList, UserPublic, UserProfile, UserUpdate, Msg
)
from app.auth import get_current_active_user
from app.services.user_service import UserService

router = APIRouter(prefix="/users", tags=["关注"])


@router.patch("/me", response_model=UserProfile)
def update_my_profile(
    update_data: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    编辑当前用户的个人资料
    - nickname / avatar_url / bio / email / phone 均为选填
    - email/phone 如填写须唯一（不能和他人重复）
    """
    service = UserService(db)
    try:
        user = service.update_profile(current_user, update_data)
        return service.get_profile(user.id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/me", response_model=UserProfile)
def get_my_profile(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取当前登录用户的个人资料（含粉丝数/关注数）"""
    service = UserService(db)
    return service.get_profile(current_user.id)


@router.get("/{user_id}", response_model=UserProfile)
def get_user_profile(
    user_id: int,
    db: Session = Depends(get_db)
):
    """获取指定用户的公开资料（任何人可访问）"""
    service = UserService(db)
    profile = service.get_profile(user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="用户不存在")
    return profile


# ─── 关注 / 取关 ───

@router.post("/{user_id}/follow", response_model=FollowResponse)
def toggle_follow(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """关注或取消关注指定用户"""
    service = UserService(db)
    try:
        following, msg = service.toggle_follow(current_user.id, user_id)
        follower_count, following_count = service.get_follow_counts(current_user.id)
        return FollowResponse(
            msg=msg,
            following=following,
            follower_count=follower_count,
            following_count=following_count
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{user_id}/follow/status", response_model=FollowStatus)
def get_follow_status(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取当前用户与目标用户的关注关系"""
    service = UserService(db)
    if not service.get_by_id(user_id):
        raise HTTPException(status_code=404, detail="用户不存在")
    return service.get_follow_status(current_user.id, user_id)


# ─── 粉丝列表 ───

@router.get("/{user_id}/followers", response_model=UserList)
def list_followers(
    user_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=50),
    db: Session = Depends(get_db)
):
    """获取指定用户的粉丝列表"""
    service = UserService(db)
    if not service.get_by_id(user_id):
        raise HTTPException(status_code=404, detail="用户不存在")

    users, total = service.get_followers(
        user_id,
        skip=(page - 1) * page_size,
        limit=page_size
    )
    return UserList(users=users, total=total)


# ─── 关注列表 ───

@router.get("/{user_id}/following", response_model=UserList)
def list_following(
    user_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=50),
    db: Session = Depends(get_db)
):
    """获取指定用户的关注列表"""
    service = UserService(db)
    if not service.get_by_id(user_id):
        raise HTTPException(status_code=404, detail="用户不存在")

    users, total = service.get_following(
        user_id,
        skip=(page - 1) * page_size,
        limit=page_size
    )
    return UserList(users=users, total=total)


# ─── 互相关注的好友列表 ───

@router.get("/me/friends", response_model=UserList)
def list_friends(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=50),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取当前用户互相关注的好友列表"""
    service = UserService(db)
    users, total = service.get_friends(
        current_user.id,
        skip=(page - 1) * page_size,
        limit=page_size
    )
    return UserList(users=users, total=total)
