"""
用户服务层

处理用户资料、关注关系等业务逻辑。
"""
from datetime import datetime
from typing import Optional, Tuple, List
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.models import User, Follow
from app.services.base import BaseService
from app.schemas import UserUpdate, UserProfile, UserWithCounts, FollowStatus


class UserService(BaseService[User]):
    """用户服务"""

    def __init__(self, db: Session):
        super().__init__(db, User)

    # ─── 用户资料 ───

    def get_profile(self, user_id: int) -> Optional[UserProfile]:
        """
        获取用户资料（含粉丝数/关注数）

        Args:
            user_id: 用户 ID

        Returns:
            UserProfile 或 None
        """
        user = self.get_by_id(user_id)
        if not user:
            return None

        follower_count, following_count = self.get_follow_counts(user_id)
        return UserProfile(
            id=user.id,
            username=user.username,
            nickname=user.nickname,
            avatar_url=user.avatar_url,
            bio=user.bio,
            is_superuser=user.is_superuser,
            created_at=user.created_at,
            follower_count=follower_count,
            following_count=following_count,
        )

    def update_profile(self, user: User, update_data: UserUpdate) -> User:
        """
        更新用户资料

        Args:
            user: 当前用户
            update_data: 更新数据

        Returns:
            更新后的用户对象

        Raises:
            ValueError: 邮箱/手机号已被使用
        """
        # 检查邮箱唯一性
        if update_data.email:
            if self.db.query(User).filter(
                User.email == update_data.email,
                User.id != user.id
            ).first():
                raise ValueError("该邮箱已被使用")

        # 检查手机号唯一性
        if update_data.phone:
            if self.db.query(User).filter(
                User.phone == update_data.phone,
                User.id != user.id
            ).first():
                raise ValueError("该手机号已被使用")

        # 更新字段
        update_dict = update_data.model_dump(exclude_unset=True)
        for key, value in update_dict.items():
            setattr(user, key, value)

        user.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(user)
        return user

    # ─── 关注统计 ───

    def get_follow_counts(self, user_id: int) -> Tuple[int, int]:
        """
        获取用户的粉丝数和关注数

        Returns:
            (follower_count, following_count)
        """
        follower_count = self.db.query(func.count(Follow.id)).filter(
            Follow.following_id == user_id
        ).scalar() or 0

        following_count = self.db.query(func.count(Follow.id)).filter(
            Follow.follower_id == user_id
        ).scalar() or 0

        return follower_count, following_count

    def get_user_with_counts(self, user: User) -> UserWithCounts:
        """获取带统计数据的用户信息"""
        follower_count, following_count = self.get_follow_counts(user.id)
        return UserWithCounts(
            id=user.id,
            username=user.username,
            nickname=user.nickname,
            avatar_url=user.avatar_url,
            bio=user.bio,
            is_superuser=user.is_superuser,
            created_at=user.created_at,
            follower_count=follower_count,
            following_count=following_count,
        )

    # ─── 关注关系 ───

    def is_following(self, follower_id: int, following_id: int) -> bool:
        """检查是否关注"""
        return self.db.query(Follow).filter(
            Follow.follower_id == follower_id,
            Follow.following_id == following_id
        ).first() is not None

    def toggle_follow(self, current_user_id: int, target_user_id: int) -> Tuple[bool, str]:
        """
        切换关注状态

        Args:
            current_user_id: 当前用户 ID
            target_user_id: 目标用户 ID

        Returns:
            (is_following, message)

        Raises:
            ValueError: 不能关注自己 / 用户不存在
        """
        if current_user_id == target_user_id:
            raise ValueError("不能关注自己")

        target = self.get_by_id(target_user_id)
        if not target:
            raise ValueError("用户不存在")

        existing = self.db.query(Follow).filter(
            Follow.follower_id == current_user_id,
            Follow.following_id == target_user_id
        ).first()

        if existing:
            self.db.delete(existing)
            self.db.commit()
            return False, "取消关注成功"
        else:
            new_follow = Follow(
                follower_id=current_user_id,
                following_id=target_user_id
            )
            self.db.add(new_follow)
            self.db.commit()
            return True, "关注成功"

    def get_follow_status(self, current_user_id: Optional[int], target_user_id: int) -> FollowStatus:
        """获取关注状态"""
        follower_count, following_count = self.get_follow_counts(target_user_id)

        is_following = False
        is_followed_by = False

        if current_user_id and current_user_id != target_user_id:
            is_following = self.is_following(current_user_id, target_user_id)
            is_followed_by = self.is_following(target_user_id, current_user_id)

        return FollowStatus(
            is_following=is_following,
            is_followed_by=is_followed_by,
            follower_count=follower_count,
            following_count=following_count,
        )

    # ─── 粉丝/关注列表 ───

    def get_followers(self, user_id: int, skip: int = 0, limit: int = 20) -> Tuple[List[UserWithCounts], int]:
        """
        获取粉丝列表

        Returns:
            (users, total)
        """
        query = self.db.query(Follow).filter(Follow.following_id == user_id)
        total = query.count()
        follows = query.order_by(Follow.created_at.desc()).offset(skip).limit(limit).all()

        users = [self.get_user_with_counts(f.follower) for f in follows]
        return users, total

    def get_following(self, user_id: int, skip: int = 0, limit: int = 20) -> Tuple[List[UserWithCounts], int]:
        """
        获取关注列表

        Returns:
            (users, total)
        """
        query = self.db.query(Follow).filter(Follow.follower_id == user_id)
        total = query.count()
        follows = query.order_by(Follow.created_at.desc()).offset(skip).limit(limit).all()

        users = [self.get_user_with_counts(f.following) for f in follows]
        return users, total

    def get_friends(self, user_id: int, skip: int = 0, limit: int = 20) -> Tuple[List[UserWithCounts], int]:
        """
        获取互相关注的好友列表

        Returns:
            (users, total)
        """
        # 获取我关注的人
        following_set = self.db.query(Follow.following_id).filter(
            Follow.follower_id == user_id
        ).all()
        following_ids = {f[0] for f in following_set}

        # 查询互相关注
        mutual_query = self.db.query(Follow).filter(
            Follow.follower_id == user_id,
            Follow.following_id.in_(following_ids),
            Follow.following_id.in_(
                self.db.query(Follow.follower_id).filter(Follow.following_id == user_id)
            )
        )

        total = mutual_query.count()
        follows = mutual_query.order_by(Follow.created_at.desc()).offset(skip).limit(limit).all()

        users = [self.get_user_with_counts(f.following) for f in follows]
        return users, total
