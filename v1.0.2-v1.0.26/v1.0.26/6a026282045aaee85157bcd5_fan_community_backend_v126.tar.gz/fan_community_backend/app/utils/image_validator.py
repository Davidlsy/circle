"""
图片安全校验模块

提供图片上传的安全校验功能：
- 文件魔数（Magic Number）校验：防止伪装成图片的恶意文件
- 文件名安全过滤：防止路径遍历和特殊字符注入
- 文件内容安全检查：防止嵌入恶意代码
- Content-Type 与实际内容一致性校验
"""
import os
import struct
from typing import Optional, Tuple

from app.logging_config import logger


# ─── 图片文件魔数（Magic Number）定义 ───
# 格式: {魔数字节: (对应的 MIME 类型, 文件扩展名)}
IMAGE_MAGIC_NUMBERS: dict[bytes, Tuple[str, str]] = {
    # JPEG: FF D8 FF
    b'\xff\xd8\xff': ('image/jpeg', '.jpg'),
    # PNG: 89 50 4E 47 0D 0A 1A 0A
    b'\x89PNG\r\n\x1a\n': ('image/png', '.png'),
    # GIF87a: 47 49 46 38 37 61
    b'GIF87a': ('image/gif', '.gif'),
    # GIF89a: 47 49 46 38 39 61
    b'GIF89a': ('image/gif', '.gif'),
    # WebP: RIFF....WEBP
    b'RIFF': ('image/webp', '.webp'),
}

# Content-Type 到魔数的映射（用于快速查找）
CONTENT_TYPE_TO_MAGIC: dict[str, list[bytes]] = {
    'image/jpeg': [b'\xff\xd8\xff'],
    'image/png': [b'\x89PNG\r\n\x1a\n'],
    'image/gif': [b'GIF87a', b'GIF89a'],
    'image/webp': [b'RIFF'],
}

# 允许的文件扩展名
ALLOWED_EXTENSIONS: set[str] = {'.jpg', '.jpeg', '.png', '.gif', '.webp'}

# 不安全的文件名字符
UNSAFE_FILENAME_CHARS: set[str] = {'/', '\\', '..', '\0', '<', '>', '|', '*', '?', '"', "'"}

# 图片文件最小大小（字节）
# 正常图片至少有几十字节（文件头 + 最小数据）
MIN_IMAGE_SIZE: int = 64


def validate_magic_number(content: bytes) -> Tuple[str, str]:
    """
    通过文件魔数（Magic Number）校验文件真实类型
    
    参数:
        content: 文件二进制内容
    
    返回:
        (mime_type, extension): 文件的真实 MIME 类型和扩展名
    
    异常:
        ValueError: 无法识别的文件类型
    """
    for magic_bytes, (mime_type, extension) in IMAGE_MAGIC_NUMBERS.items():
        if content[:len(magic_bytes)] == magic_bytes:
            # WebP 需要额外检查：RIFF 开头后 8 字节处应为 "WEBP"
            if magic_bytes == b'RIFF':
                if len(content) < 12 or content[8:12] != b'WEBP':
                    continue
            return mime_type, extension
    
    raise ValueError(
        f"无法识别的文件类型，文件头不匹配任何已知图片格式。"
        f"文件头（十六进制）: {content[:16].hex()}"
    )


def validate_content_type_consistency(
    content_type: Optional[str],
    actual_mime: str
) -> None:
    """
    校验 Content-Type 与文件实际类型是否一致
    
    参数:
        content_type: 客户端声明的 Content-Type
        actual_mime: 通过魔数检测到的实际 MIME 类型
    
    异常:
        ValueError: Content-Type 与实际类型不匹配
    """
    if not content_type:
        return
    
    # 标准化比较
    ct_lower = content_type.lower().split(';')[0].strip()
    actual_lower = actual_mime.lower().split(';')[0].strip()
    
    if ct_lower != actual_lower:
        raise ValueError(
            f"Content-Type 与文件实际类型不匹配："
            f"声明为 {content_type}，实际为 {actual_mime}"
        )


def sanitize_filename(filename: str) -> str:
    """
    安全过滤文件名
    
    - 移除路径遍历字符（..、/、\）
    - 移除特殊字符（<、>、|、*、?、"、'）
    - 移除空字节
    - 限制文件名长度
    
    参数:
        filename: 原始文件名
    
    返回:
        安全的文件名（仅保留基础名，不含路径）
    """
    if not filename:
        return "unnamed"
    
    # 仅取文件名部分（去除路径）
    filename = os.path.basename(filename)
    
    # 移除不安全字符
    safe_name = ''.join(
        c for c in filename
        if c not in UNSAFE_FILENAME_CHARS
    )
    
    # 限制长度（保留扩展名）
    name_part, ext_part = os.path.splitext(safe_name)
    max_name_length = 100
    if len(name_part) > max_name_length:
        name_part = name_part[:max_name_length]
    
    safe_name = name_part + ext_part
    
    # 如果过滤后为空，使用默认名
    if not safe_name or safe_name.startswith('.'):
        return "unnamed"
    
    return safe_name


def get_extension_from_mime(mime_type: str) -> str:
    """
    从 MIME 类型获取安全的文件扩展名
    
    参数:
        mime_type: MIME 类型字符串
    
    返回:
        文件扩展名（含点号，如 ".jpg"）
    """
    mime_to_ext = {
        'image/jpeg': '.jpg',
        'image/png': '.png',
        'image/gif': '.gif',
        'image/webp': '.webp',
    }
    return mime_to_ext.get(mime_type, '.jpg')


def validate_image_content(content: bytes) -> None:
    """
    校验图片内容安全性
    
    检查项：
    - 文件大小是否在合理范围内
    - 是否包含可疑的脚本标签（防止 polyglot 攻击）
    
    参数:
        content: 文件二进制内容
    
    异常:
        ValueError: 检测到不安全内容
    """
    # 检查最小文件大小
    if len(content) < MIN_IMAGE_SIZE:
        raise ValueError(f"文件过小（{len(content)} 字节），可能不是有效的图片文件")
    
    # 检查是否包含嵌入的脚本标签（polyglot 攻击防护）
    # 某些恶意文件可以在图片中嵌入 HTML/JS 代码
    suspicious_patterns = [
        b'<script',
        b'<?php',
        b'<%',
        b'<!DOCTYPE',
    ]
    
    # 只在文件前 1024 字节和后 1024 字节检查（减少误报）
    check_ranges = [
        content[:1024],
        content[-1024:] if len(content) > 1024 else content,
    ]
    
    for check_content in check_ranges:
        for pattern in suspicious_patterns:
            if pattern.lower() in check_content.lower():
                raise ValueError(
                    f"检测到可疑内容：文件中包含不安全的脚本标签。"
                    f"该文件可能不是合法的图片文件。"
                )


def full_image_validation(
    content: bytes,
    content_type: Optional[str],
    original_filename: Optional[str]
) -> Tuple[str, str]:
    """
    完整的图片安全校验流程
    
    执行以下校验步骤：
    1. 文件大小检查
    2. 文件魔数校验（确定真实文件类型）
    3. Content-Type 一致性校验
    4. 文件内容安全检查
    5. 文件名安全过滤
    
    参数:
        content: 文件二进制内容
        content_type: 客户端声明的 Content-Type
        original_filename: 原始文件名
    
    返回:
        (safe_filename, detected_mime): 安全的文件名和检测到的 MIME 类型
    
    异常:
        ValueError: 任一校验步骤失败
    """
    # 1. 文件大小检查
    if not content or len(content) == 0:
        raise ValueError("图片文件不能为空")
    
    # 2. 文件魔数校验
    detected_mime, detected_ext = validate_magic_number(content)
    
    # 3. Content-Type 一致性校验
    validate_content_type_consistency(content_type, detected_mime)
    
    # 4. 文件内容安全检查
    validate_image_content(content)
    
    # 5. 文件名安全过滤
    safe_name = sanitize_filename(original_filename) if original_filename else "unnamed"
    
    # 确保扩展名与实际文件类型一致
    _, name_ext = os.path.splitext(safe_name)
    if name_ext.lower() not in ALLOWED_EXTENSIONS:
        safe_name = safe_name + detected_ext
    
    return safe_name, detected_mime
