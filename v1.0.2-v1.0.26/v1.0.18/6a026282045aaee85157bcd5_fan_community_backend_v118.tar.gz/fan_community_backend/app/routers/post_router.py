"""
帖子路由

处理帖子、评论、点赞、收藏、图片上传等请求。
业务逻辑委托给 PostService 处理，公共查询使用 query_helpers。
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from datetime import datetime
import os
import uuid

from app.database import get_db
from app.models import User, Post, Comment, Like, PostImage, Collection, Tag, PostTag
from app.schemas import (
    PostCreate, PostUpdate, PostPublic, PostDetail, PostList,
    CommentCreate, CommentUpdate, CommentPublic, CommentWithAuthor,
    LikeResponse, Msg, UserPublic, PostImagePublic,
    ImageUploadResponse, ImageDeleteResponse, CollectionResponse,
    TagPublic
)
from app.auth import get_current_active_user
from app.config import get_settings
from app.storage import get_storage
from app.utils import (
    get_post_counts,
    get_post_images,
    get_post_tags,
    build_post_detail,
    validate_image_file,
    validate_post_exists,
    validate_is_author_or_admin,
)
from app.constants import Pagination

settings = get_settings()
router = APIRouter(prefix="/posts", tags=["帖子"])


# ─── 存储后端（单例） ───
storage = get_storage()


# ─── 工具函数 ───

def _save_image_file(file: UploadFile) -> tuple[str, int]:
    """
    通过存储后端保存图片文件，返回 (url, size)
    """
    content = validate_image_file(file)
    size = len(content)
    url = storage.save(content, file.filename or "image.jpg", content_type=file.content_type)
    return url, size


# ─── 帖子 CRUD ───

@router.post("/", response_model=PostPublic, status_code=status.HTTP_201_CREATED)
def create_post(
    post: PostCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """创建帖子（需审核：普通用户 pending，管理员 approved）"""
    initial_status = "approved" if current_user.is_superuser else "pending"
    db_post = Post(
        title=post.title,
        content=post.content,
        author_id=current_user.id,
        is_published=post.is_published,
        status=initial_status
    )
    db.add(db_post)
    db.commit()
    db.refresh(db_post)
    return db_post


@router.get("/", response_model=PostList)
def list_posts(
    page: int = Query(Pagination.DEFAULT_PAGE, ge=1),
    page_size: int = Query(Pagination.POST_PAGE_SIZE, ge=Pagination.MIN_PAGE_SIZE, le=Pagination.MAX_PAGE_SIZE),
    author_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_active_user)
):
    """获取帖子列表（分页，仅审核通过的帖子）"""
    query = db.query(Post).filter(Post.is_published == True)

    if current_user:
        # 作者本人可看自己的所有帖子（pending/approved/rejected），其他人只看 approved
        query = query.filter(
            (Post.author_id == current_user.id) | (Post.status == "approved")
        )
    else:
        query = query.filter(Post.status == "approved")

    if author_id:
        query = query.filter(Post.author_id == author_id)

    total = query.count()
    posts = query.order_by(Post.created_at.desc())\
        .offset((page - 1) * page_size)\
        .limit(page_size)\
        .all()

    # 使用公共工具函数构建详情
    current_user_id = current_user.id if current_user else None
    post_details = [build_post_detail(db, p, current_user_id) for p in posts]

    return PostList(posts=post_details, total=total, page=page, page_size=page_size)


@router.get("/{post_id}", response_model=PostDetail)
def get_post(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_active_user)
):
    """获取帖子详情（未审核帖子仅作者和管理员可见）"""
    post = validate_post_exists(db, post_id)

    # 非管理员且非作者只能看 approved 帖子
    if post.status != "approved":
        if not current_user or (current_user.id != post.author_id and not current_user.is_superuser):
            raise HTTPException(status_code=404, detail="帖子不存在")

    # 增加浏览量
    post.view_count += 1
    db.commit()

    # 使用公共工具函数构建详情
    current_user_id = current_user.id if current_user else None
    return build_post_detail(db, post, current_user_id)


@router.put("/{post_id}", response_model=PostPublic)
def update_post(
    post_id: int,
    post_update: PostUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """更新帖子（仅作者）"""
    post = validate_post_exists(db, post_id)
    validate_is_author_or_admin(post, current_user, "修改")

    update_data = post_update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(post, key, value)

    db.commit()
    db.refresh(post)
    return post


@router.delete("/{post_id}", response_model=Msg)
def delete_post(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除帖子（仅作者或超级管理员）"""
    post = validate_post_exists(db, post_id)
    validate_is_author_or_admin(post, current_user, "删除")

    # 删除帖子关联的图片文件（通过存储后端）
    images = db.query(PostImage).filter(PostImage.post_id == post_id).all()
    for img in images:
        storage.delete(img.url)

    db.delete(post)
    db.commit()
    return Msg(msg="帖子已删除")


# ─── 评论 CRUD ───

@router.post("/{post_id}/comments", response_model=CommentPublic, status_code=status.HTTP_201_CREATED)
def create_comment(
    post_id: int,
    comment: CommentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """评论帖子"""
    post = validate_post_exists(db, post_id)

    if comment.parent_id:
        parent = db.query(Comment).filter(Comment.id == comment.parent_id).first()
        if not parent or parent.post_id != post_id:
            raise HTTPException(status_code=400, detail="无效的回复目标")

    db_comment = Comment(
        content=comment.content,
        author_id=current_user.id,
        post_id=post_id,
        parent_id=comment.parent_id,
        status="approved" if current_user.is_superuser else "pending"
    )
    db.add(db_comment)
    db.commit()
    db.refresh(db_comment)
    return db_comment


@router.get("/{post_id}/comments", response_model=List[CommentWithAuthor])
def list_comments(
    post_id: int,
    db: Session = Depends(get_db)
):
    """获取帖子的评论列表"""
    validate_post_exists(db, post_id)

    # 只显示审核通过的评论
    comments = db.query(Comment).filter(
        Comment.post_id == post_id,
        Comment.parent_id == None,
        Comment.status == "approved"
    ).order_by(Comment.created_at.desc()).all()

    return [CommentWithAuthor(
        id=c.id,
        content=c.content,
        author_id=c.author_id,
        post_id=c.post_id,
        parent_id=c.parent_id,
        status=c.status,
        created_at=c.created_at,
        updated_at=c.updated_at,
        author=UserPublic.model_validate(c.author)
    ) for c in comments]


@router.delete("/comments/{comment_id}", response_model=Msg)
def delete_comment(
    comment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除评论（仅作者或超级管理员）"""
    comment = db.query(Comment).filter(Comment.id == comment_id).first()
    if not comment:
        raise HTTPException(status_code=404, detail="评论不存在")

    from app.utils.validators import validate_is_comment_author_or_admin
    validate_is_comment_author_or_admin(comment, current_user, "删除")

    db.delete(comment)
    db.commit()
    return Msg(msg="评论已删除")


# ─── 点赞功能 ───

@router.post("/{post_id}/like", response_model=LikeResponse)
def toggle_like(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """切换帖子点赞状态"""
    validate_post_exists(db, post_id)

    existing_like = db.query(Like).filter(
        Like.post_id == post_id,
        Like.user_id == current_user.id
    ).first()

    if existing_like:
        db.delete(existing_like)
        db.commit()
        liked = False
        msg = "取消点赞成功"
    else:
        new_like = Like(user_id=current_user.id, post_id=post_id)
        db.add(new_like)
        db.commit()
        liked = True
        msg = "点赞成功"

    # 使用公共工具函数获取点赞数
    _, like_count, _ = get_post_counts(db, post_id)
    return LikeResponse(msg=msg, liked=liked, like_count=like_count)


# ─── 图片上传 ───

@router.post("/{post_id}/images", response_model=ImageUploadResponse)
async def upload_images(
    post_id: int,
    files: List[UploadFile] = File(..., description="图片文件，最多9张，支持 jpeg/png/gif/webp"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    上传帖子图片

    - 单张图片最大 5MB
    - 单篇帖子最多 9 张图片
    - 支持格式：jpeg / png / gif / webp
    """
    post = validate_post_exists(db, post_id)
    validate_is_author_or_admin(post, current_user, "上传图片")

    # 已有图片数量
    existing_count = db.query(func.count(PostImage.id)).filter(
        PostImage.post_id == post_id
    ).scalar()

    if existing_count >= settings.MAX_IMAGES_PER_POST:
        raise HTTPException(
            status_code=400,
            detail=f"该帖子已达到最大图片数量上限（{settings.MAX_IMAGES_PER_POST}张）"
        )

    remaining_slots = settings.MAX_IMAGES_PER_POST - existing_count
    if len(files) > remaining_slots:
        raise HTTPException(
            status_code=400,
            detail=f"最多只能再上传 {remaining_slots} 张图片，该帖子已有 {existing_count} 张"
        )

    # 获取当前最大 order
    max_order = db.query(func.max(PostImage.order)).filter(
        PostImage.post_id == post_id
    ).scalar() or 0

    saved_images = []
    for i, file in enumerate(files):
        try:
            url, size = _save_image_file(file)
            order = max_order + i + 1

            db_image = PostImage(
                post_id=post_id,
                url=url,
                filename=file.filename or os.path.basename(url),
                size=size,
                order=order
            )
            db.add(db_image)
            saved_images.append(db_image)
        except HTTPException:
            # 单张失败，回滚已保存的文件
            db.rollback()
            for saved in saved_images:
                storage.delete(saved.url)
            raise

    db.commit()
    for img in saved_images:
        db.refresh(img)

    result = [PostImagePublic.model_validate(img) for img in saved_images]
    return ImageUploadResponse(
        images=result,
        uploaded_count=len(result),
        post_id=post_id
    )


@router.get("/{post_id}/images", response_model=List[PostImagePublic])
def get_post_images_endpoint(
    post_id: int,
    db: Session = Depends(get_db)
):
    """获取帖子的所有图片"""
    validate_post_exists(db, post_id)
    # 使用公共工具函数
    return get_post_images(db, post_id)


@router.delete("/images/{image_id}", response_model=ImageDeleteResponse)
def delete_image(
    image_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除指定图片（仅帖子作者或超管）"""
    image = db.query(PostImage).filter(PostImage.id == image_id).first()
    if not image:
        raise HTTPException(status_code=404, detail="图片不存在")

    post = validate_post_exists(db, image.post_id)
    validate_is_author_or_admin(post, current_user, "删除")

    # 通过存储后端删除文件
    storage.delete(image.url)

    post_id = image.post_id
    db.delete(image)
    db.commit()

    # 使用公共工具函数获取剩余数量
    remaining = db.query(func.count(PostImage.id)).filter(
        PostImage.post_id == post_id
    ).scalar()

    return ImageDeleteResponse(
        msg="图片已删除",
        remaining_count=remaining
    )


# ─── 收藏功能 ───

@router.post("/{post_id}/collect", response_model=CollectionResponse)
def toggle_collection(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """收藏/取消收藏帖子（toggle）"""
    validate_post_exists(db, post_id)

    existing = db.query(Collection).filter(
        Collection.post_id == post_id,
        Collection.user_id == current_user.id
    ).first()

    if existing:
        db.delete(existing)
        db.commit()
        collected = False
        msg = "取消收藏成功"
    else:
        new_collection = Collection(user_id=current_user.id, post_id=post_id)
        db.add(new_collection)
        db.commit()
        collected = True
        msg = "收藏成功"

    # 使用公共工具函数获取收藏数
    _, _, collection_count = get_post_counts(db, post_id)

    return CollectionResponse(
        msg=msg,
        collected=collected,
        collection_count=collection_count
    )
