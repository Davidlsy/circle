"""
全局常量定义

统一管理项目中所有业务常量，避免魔法数字和分散定义。
环境相关配置仍在 config.py 中管理（可通过 .env 覆盖）。
"""


# ═══════════════════════════════════════════════════════════════
# 认证相关常量
# ═══════════════════════════════════════════════════════════════

class Auth:
    """认证相关常量"""
    CODE_EXPIRE_MINUTES: int = 15              # 验证码有效期（分钟）
    CODE_LENGTH: int = 6                       # 验证码位数
    MAX_LOGIN_ATTEMPTS: int = 5                # 最大登录尝试次数（预留）
    LOGIN_LOCKOUT_MINUTES: int = 30            # 登录锁定时间（预留）
    PASSWORD_MIN_LENGTH: int = 6               # 密码最小长度
    USERNAME_MIN_LENGTH: int = 3               # 用户名最小长度
    USERNAME_MAX_LENGTH: int = 50              # 用户名最大长度


# ═══════════════════════════════════════════════════════════════
# 帖子相关常量
# ═══════════════════════════════════════════════════════════════

class Post:
    """帖子相关常量"""
    TITLE_MAX_LENGTH: int = 200                # 帖子标题最大长度
    CONTENT_MAX_LENGTH: int = 10000            # 帖子内容最大长度
    MAX_TAGS_PER_POST: int = 9                 # 单篇帖子最多标签数
    TAG_NAME_MAX_LENGTH: int = 50              # 标签名最大长度
    TAG_DESC_MAX_LENGTH: int = 200             # 标签描述最大长度


# ═══════════════════════════════════════════════════════════════
# 分页相关常量
# ═══════════════════════════════════════════════════════════════

class Pagination:
    """分页相关常量"""
    DEFAULT_PAGE: int = 1                      # 默认页码
    DEFAULT_PAGE_SIZE: int = 10                # 默认每页条数
    MIN_PAGE_SIZE: int = 1                     # 最小每页条数
    MAX_PAGE_SIZE: int = 50                    # 最大每页条数

    # 各模块默认分页大小
    POST_PAGE_SIZE: int = 10                   # 帖子列表默认每页条数
    USER_PAGE_SIZE: int = 20                   # 用户列表默认每页条数
    TAG_PAGE_SIZE: int = 20                    # 标签列表默认每页条数
    MESSAGE_PAGE_SIZE: int = 20                # 消息列表默认每页条数
    AUDIT_PAGE_SIZE: int = 20                  # 审核列表默认每页条数
    FEED_PAGE_SIZE: int = 10                   # 动态流默认每页条数
    TAG_SEARCH_LIMIT: int = 20                 # 标签搜索最大返回数


# ═══════════════════════════════════════════════════════════════
# 内容审核相关常量
# ═══════════════════════════════════════════════════════════════

class Audit:
    """内容审核相关常量"""
    STATUS_PENDING: str = "pending"             # 待审核
    STATUS_APPROVED: str = "approved"           # 已通过
    STATUS_REJECTED: str = "rejected"           # 已驳回


# ═══════════════════════════════════════════════════════════════
# 用户相关常量
# ═══════════════════════════════════════════════════════════════

class User:
    """用户相关常量"""
    NICKNAME_MAX_LENGTH: int = 50              # 昵称最大长度
    BIO_MAX_LENGTH: int = 500                  # 个人简介最大长度
    AVATAR_URL_MAX_LENGTH: int = 500           # 头像 URL 最大长度


# ═══════════════════════════════════════════════════════════════
# 消息相关常量
# ═══════════════════════════════════════════════════════════════

class Message:
    """消息相关常量"""
    CONTENT_MAX_LENGTH: int = 5000             # 消息内容最大长度
    CONTENT_MIN_LENGTH: int = 1                # 消息内容最小长度
