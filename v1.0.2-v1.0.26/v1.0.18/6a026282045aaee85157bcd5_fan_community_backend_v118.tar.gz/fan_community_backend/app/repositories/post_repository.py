"""
Post Repository

帖子数据访问层，处理帖子相关的数据库操作。
"""
from typing import Optional, List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from app.models import Post, Like, Collection, PostImage
from app.repositories.base import BaseRepository


class PostRepository(BaseRepository[Post]):
    """帖子数据访问层"""

    def __init__(self, db: Session):
        super().__init__(db, Post)

    def get_published_posts(
        self,
        skip: int = 0,
        limit: int = 10,
        author_id: Optional[int] = None,
    ) -> Tuple[List[Post], int]:
        """
        获取已发布的帖子列表

        Returns:
            (posts, total)
        """
        query = self.db.query(Post).filter(
            Post.is_published == True,
            Post.status == "approved"
        )
        if author_id:
            query = query.filter(Post.author_id == author_id)

        total = query.count()
        posts = query.order_by(desc(Post.created_at)).offset(skip).limit(limit).all()
        return posts, total

    def get_posts_with_auth(
        self,
        skip: int = 0,
        limit: int = 10,
        author_id: Optional[int] = None,
        current_user_id: Optional[int] = None,
    ) -> Tuple[List[Post], int]:
        """
        获取帖子列表（考虑用户权限）

        Returns:
            (posts, total)
        """
        query = self.db.query(Post).filter(Post.is_published == True)

        if current_user_id:
            query = query.filter(
                (Post.author_id == current_user_id) | (Post.status == "approved")
            )
        else:
            query = query.filter(Post.status == "approved")

        if author_id:
            query = query.filter(Post.author_id == author_id)

        total = query.count()
        posts = query.order_by(desc(Post.created_at)).offset(skip).limit(limit).all()
        return posts, total

    def get_by_author(self, author_id: int, skip: int = 0, limit: int = 10) -> Tuple[List[Post], int]:
        """获取作者的帖子"""
        query = self.db.query(Post).filter(Post.author_id == author_id)
        total = query.count()
        posts = query.order_by(desc(Post.created_at)).offset(skip).limit(limit).all()
        return posts, total

    def get_pending_posts(self, skip: int = 0, limit: int = 20) -> Tuple[List[Post], int]:
        """获取待审核的帖子"""
        query = self.db.query(Post).filter(Post.status == "pending")
        total = query.count()
        posts = query.order_by(Post.created_at.asc()).offset(skip).limit(limit).all()
        return posts, total

    def get_rejected_posts(self, skip: int = 0, limit: int = 20) -> Tuple[List[Post], int]:
        """获取已驳回的帖子"""
        query = self.db.query(Post).filter(Post.status == "rejected")
        total = query.count()
        posts = query.order_by(desc(Post.updated_at)).offset(skip).limit(limit).all()
        return posts, total

    def increment_view_count(self, post: Post) -> None:
        """增加浏览量"""
        post.view_count += 1
        self.db.commit()

    def count_likes(self, post_id: int) -> int:
        """统计帖子点赞数"""
        return self.db.query(func.count(Like.id)).filter(Like.post_id == post_id).scalar() or 0

    def count_comments(self, post_id: int) -> int:
        """统计帖子评论数"""
        return self.db.query(func.count(Like.id)).filter(Like.id == post_id).scalar() or 0

    def count_collections(self, post_id: int) -> int:
        """统计帖子收藏数"""
        return self.db.query(func.count(Collection.id)).filter(Collection.post_id == post_id).first()

    def count_images(self, post_id: int) -> int:
        """统计帖子图片数"""
        return self.db.query(func.count(PostImage.id)).filter(PostImage.post_id == post_id).scalar() or 0

    def get_max_image_order(self, post_id: int) -> int:
        """获取当前最大图片顺序"""
        return self.db.query(func.max(PostImage.order)).filter(
            PostImage.post_id == post_id
        ).scalar() or 0
