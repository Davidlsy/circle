"""
User Repository

用户数据访问层，处理用户相关的数据库操作。
"""
from typing import Optional, List
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.models import User
from app.repositories.base import BaseRepository


class UserRepository(BaseRepository[User]):
    """用户数据访问层"""

    def __init__(self, db: Session):
        super().__init__(db, User)

    def get_by_username(self, username: str) -> Optional[User]:
        """根据用户名获取用户"""
        return self.db.query(User).filter(User.username == username).first()

    def get_by_email(self, email: str) -> Optional[User]:
        """根据邮箱获取用户"""
        return self.db.query(User).filter(User.email == email).first()

    def get_by_phone(self, phone: str) -> Optional[User]:
        """根据手机号获取用户"""
        return self.db.query(User).filter(User.phone == phone).first()

    def get_by_username_or_email(self, username_or_email: str) -> Optional[User]:
        """根据用户名或邮箱获取用户（用于登录）"""
        return self.db.query(User).filter(
            (User.username == username_or_email) | (User.email == username_or_email)
        ).first()

    def exists_by_username(self, username: str) -> bool:
        """检查用户名是否存在"""
        return self.db.query(User.username).filter(User.username == username).first() is not None

    def exists_by_email(self, email: str) -> bool:
        """检查邮箱是否存在"""
        return self.db.query(User.email).filter(User.email == email).first() is not None

    def exists_by_phone(self, phone: str) -> bool:
        """检查手机号是否存在"""
        return self.db.query(User.phone).filter(User.phone == phone).first() is not None

    def exists_other_with_email(self, user_id: int, email: str) -> bool:
        """检查其他用户是否已使用该邮箱（排除自己）"""
        return self.db.query(User).filter(
            User.email == email,
            User.id != user_id
        ).first() is not None

    def exists_other_with_phone(self, user_id: int, phone: str) -> bool:
        """检查其他用户是否已使用该手机号（排除自己）"""
        return self.db.query(User).filter(
            User.phone == phone,
            User.id != user_id
        ).first() is not None
