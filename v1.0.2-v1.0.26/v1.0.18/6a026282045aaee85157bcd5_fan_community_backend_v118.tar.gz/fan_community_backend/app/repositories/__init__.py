"""
Repository 层

数据访问层封装，提供标准 CRUD 操作和常用查询方法。
Service 层通过 Repository 访问数据，实现关注点分离。

架构：Router → Service → Repository → Model
"""
from app.repositories.base import BaseRepository
from app.repositories.user_repository import UserRepository
from app.repositories.post_repository import PostRepository
from app.repositories.comment_repository import CommentRepository
from app.repositories.follow_repository import FollowRepository
from app.repositories.message_repository import MessageRepository

__all__ = [
    "BaseRepository",
    "UserRepository",
    "PostRepository",
    "CommentRepository",
    "FollowRepository",
    "MessageRepository",
]
