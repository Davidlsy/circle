"""
Follow Repository

关注关系数据访问层，处理关注相关的数据库操作。
"""
from typing import List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from app.models import Follow
from app.repositories.base import BaseRepository


class FollowRepository(BaseRepository[Follow]):
    """关注关系数据访问层"""

    def __init__(self, db: Session):
        super().__init__(db, Follow)

    def is_following(self, follower_id: int, following_id: int) -> bool:
        """检查用户是否关注了另一个用户"""
        return self.db.query(Follow).filter(
            Follow.follower_id == follower_id,
            Follow.following_id == following_id
        ).first() is not None

    def get_follower_ids(self, user_id: int) -> List[int]:
        """获取用户的粉丝 ID 列表"""
        result = self.db.query(Follow.following_id).filter(
            Follow.follower_id == user_id
        ).all()
        return [r[0] for r in result]

    def get_following_ids(self, user_id: int) -> List[int]:
        """获取用户关注的 ID 列表"""
        result = self.db.query(Follow.following_id).filter(
            Follow.follower_id == user_id
        ).all()
        return [r[0] for r in result]

    def count_followers(self, user_id: int) -> int:
        """统计粉丝数"""
        return self.db.query(func.count(Follow.id)).filter(
            Follow.following_id == user_id
        ).scalar() or 0

    def count_following(self, user_id: int) -> int:
        """统计关注数"""
        return self.db.query(func.count(Follow.id)).filter(
            Follow.follower_id == user_id
        ).scalar() or 0

    def get_followers(
        self,
        user_id: int,
        skip: int = 0,
        limit: int = 20
    ) -> Tuple[List[Follow], int]:
        """获取粉丝列表"""
        query = self.db.query(Follow).filter(Follow.following_id == user_id)
        total = query.count()
        followers = query.order_by(desc(Follow.created_at)).offset(skip).limit(limit).all()
        return followers, total

    def get_following(
        self,
        user_id: int,
        skip: int = 0,
        limit: int = 20
    ) -> Tuple[List[Follow], int]:
        """获取关注列表"""
        query = self.db.query(Follow).filter(Follow.follower_id == user_id)
        total = query.count()
        following = query.order_by(desc(Follow.created_at)).offset(skip).limit(limit).all()
        return following, total

    def get_mutual_followers(
        self,
        user_id: int,
        skip: int = 0,
        limit: int = 20
    ) -> Tuple[List[Follow], int]:
        """获取互相关注的好友列表"""
        # 子查询：用户关注的 IDs
        following_ids = self.db.query(Follow.following_id).filter(
            Follow.follower_id == user_id
        ).subquery()

        # 互相关注：在 following_ids 中且对方也关注了我
        query = self.db.query(Follow).filter(
            Follow.follower_id == user_id,
            Follow.following_id.in_(
                self.db.query(Follow.follower_id).filter(
                    Follow.following_id == user_id
                )
            )
        )

        total = query.count()
        mutual = query.order_by(desc(Follow.created_at)).offset(skip).limit(limit).all()
        return mutual, total

    def delete_relation(self, follower_id: int, following_id: int) -> bool:
        """删除关注关系"""
        follow = self.db.query(Follow).filter(
            Follow.follower_id == follower_id,
            Follow.following_id == following_id
        ).first()
        if follow:
            self.db.delete(follow)
            self.db.commit()
            return True
        return False

    def create_relation(self, follower_id: int, following_id: int) -> Follow:
        """创建关注关系"""
        follow = Follow(follower_id=follower_id, following_id=following_id)
        self.db.add(follow)
        self.db.commit()
        self.db.refresh(follow)
        return follow
