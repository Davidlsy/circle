"""
Comment Repository

评论数据访问层，处理评论相关的数据库操作。
"""
from typing import List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.models import Comment
from app.repositories.base import BaseRepository


class CommentRepository(BaseRepository[Comment]):
    """评论数据访问层"""

    def __init__(self, db: Session):
        super().__init__(db, Comment)

    def get_by_post(
        self,
        post_id: int,
        skip: int = 0,
        limit: int = 100,
        include_replies: bool = True
    ) -> Tuple[List[Comment], int]:
        """
        获取帖子的评论列表（顶级评论）

        Returns:
            (comments, total)
        """
        query = self.db.query(Comment).filter(
            Comment.post_id == post_id,
            Comment.parent_id == None,
            Comment.status == "approved"
        )
        total = query.count()
        comments = query.order_by(desc(Comment.created_at)).offset(skip).limit(limit).all()
        return comments, total

    def get_pending_comments(
        self,
        skip: int = 0,
        limit: int = 20
    ) -> Tuple[List[Comment], int]:
        """获取待审核的评论"""
        query = self.db.query(Comment).filter(Comment.status == "pending")
        total = query.count()
        comments = query.order_by(Comment.created_at.asc()).offset(skip).limit(limit).all()
        return comments, total

    def get_by_post_and_parent(
        self,
        post_id: int,
        parent_id: int
    ) -> List[Comment]:
        """获取帖子的回复列表"""
        return self.db.query(Comment).filter(
            Comment.post_id == post_id,
            Comment.parent_id == parent_id,
            Comment.status == "approved"
        ).order_by(Comment.created_at.asc()).all()
