"""
Message Repository

消息数据访问层，处理私信会话和消息相关的数据库操作。
"""
from typing import List, Tuple, Optional
from sqlalchemy.orm import Session
from sqlalchemy import func, desc, or_

from app.models import Conversation, Message
from app.repositories.base import BaseRepository


class MessageRepository(BaseRepository[Message]):
    """消息数据访问层"""

    def __init__(self, db: Session):
        super().__init__(db, Message)

    def get_conversation_between_users(
        self,
        user1_id: int,
        user2_id: int
    ) -> Optional[Conversation]:
        """查找两个用户之间的会话（user1 < user2）"""
        uid_a, uid_b = sorted([user1_id, user2_id])
        return self.db.query(Conversation).filter(
            Conversation.user1_id == uid_a,
            Conversation.user2_id == uid_b
        ).first()

    def get_or_create_conversation(
        self,
        user1_id: int,
        user2_id: int
    ) -> Conversation:
        """获取或创建会话"""
        conv = self.get_conversation_between_users(user1_id, user2_id)
        if conv:
            return conv

        uid_a, uid_b = sorted([user1_id, user2_id])
        conv = Conversation(user1_id=uid_a, user2_id=uid_b)
        self.db.add(conv)
        self.db.commit()
        self.db.refresh(conv)
        return conv

    def get_user_conversations(
        self,
        user_id: int
    ) -> List[Conversation]:
        """获取用户的所有会话"""
        return self.db.query(Conversation).filter(
            or_(
                Conversation.user1_id == user_id,
                Conversation.user2_id == user_id
            )
        ).order_by(desc(Conversation.updated_at)).all()

    def get_messages_in_conversation(
        self,
        conversation_id: int,
        skip: int = 0,
        limit: int = 20
    ) -> Tuple[List[Message], int]:
        """获取会话中的消息列表"""
        query = self.db.query(Message).filter(
            Message.conversation_id == conversation_id
        )
        total = query.count()
        messages = query.order_by(desc(Message.created_at)).offset(skip).limit(limit).all()
        return list(reversed(messages)), total

    def get_last_message(self, conversation_id: int) -> Optional[Message]:
        """获取会话最后一条消息"""
        return self.db.query(Message).filter(
            Message.conversation_id == conversation_id
        ).order_by(desc(Message.created_at)).first()

    def count_unread_in_conversation(
        self,
        conversation_id: int,
        exclude_user_id: int
    ) -> int:
        """统计会话中未读消息数"""
        return self.db.query(func.count(Message.id)).filter(
            Message.conversation_id == conversation_id,
            Message.sender_id != exclude_user_id,
            Message.is_read == False
        ).scalar() or 0

    def mark_all_as_read_in_conversation(
        self,
        conversation_id: int,
        exclude_user_id: int
    ) -> int:
        """标记会话中所有消息为已读"""
        count = self.db.query(Message).filter(
            Message.conversation_id == conversation_id,
            Message.sender_id != exclude_user_id,
            Message.is_read == False
        ).update({"is_read": True})
        self.db.commit()
        return count

    def update_conversation_time(self, conversation: Conversation) -> None:
        """更新会话时间"""
        self.db.commit()

    def create_message(
        self,
        conversation_id: int,
        sender_id: int,
        content: str
    ) -> Message:
        """创建消息"""
        message = Message(
            conversation_id=conversation_id,
            sender_id=sender_id,
            content=content
        )
        self.db.add(message)
        self.db.commit()
        self.db.refresh(message)
        return message
