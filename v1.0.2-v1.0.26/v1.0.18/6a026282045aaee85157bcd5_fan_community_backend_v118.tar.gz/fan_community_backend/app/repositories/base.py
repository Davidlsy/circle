"""
Repository 基类

提供通用的 CRUD 操作封装，是所有 Repository 的基类。
"""
from typing import TypeVar, Generic, Optional, List, Type, Any
from sqlalchemy.orm import Session
from sqlalchemy import func

T = TypeVar("T")


class BaseRepository(Generic[T]):
    """
    Repository 基类

    提供通用的数据库操作封装，子类可继承并扩展特定查询方法。
    """

    def __init__(self, db: Session, model: Type[T]):
        """
        初始化 Repository

        Args:
            db: SQLAlchemy 数据库会话
            model: SQLAlchemy 模型类
        """
        self.db = db
        self.model = model

    def get_by_id(self, id: int) -> Optional[T]:
        """根据 ID 获取单条记录"""
        return self.db.query(self.model).filter(self.model.id == id).first()

    def get_all(self, skip: int = 0, limit: int = 100) -> List[T]:
        """获取所有记录（支持分页）"""
        return self.db.query(self.model).offset(skip).limit(limit).all()

    def count(self) -> int:
        """统计记录总数"""
        return self.db.query(func.count(self.model.id)).scalar() or 0

    def exists(self, **filters) -> bool:
        """检查记录是否存在"""
        query = self.db.query(self.model)
        for key, value in filters.items():
            if hasattr(self.model, key) and value is not None:
                query = query.filter(getattr(self.model, key) == value)
        return query.first() is not None

    def create(self, **kwargs) -> T:
        """创建新记录"""
        instance = self.model(**kwargs)
        self.db.add(instance)
        self.db.commit()
        self.db.refresh(instance)
        return instance

    def update(self, instance: T, **kwargs) -> T:
        """更新记录"""
        for key, value in kwargs.items():
            if hasattr(instance, key):
                setattr(instance, key, value)
        self.db.commit()
        self.db.refresh(instance)
        return instance

    def delete(self, instance: T) -> bool:
        """删除记录"""
        self.db.delete(instance)
        self.db.commit()
        return True

    def save(self, instance: T) -> T:
        """保存实例（添加或更新）"""
        self.db.add(instance)
        self.db.commit()
        self.db.refresh(instance)
        return instance

    def first(self, **filters) -> Optional[T]:
        """根据条件获取第一条记录"""
        query = self.db.query(self.model)
        for key, value in filters.items():
            if hasattr(self.model, key):
                query = query.filter(getattr(self.model, key) == value)
        return query.first()
