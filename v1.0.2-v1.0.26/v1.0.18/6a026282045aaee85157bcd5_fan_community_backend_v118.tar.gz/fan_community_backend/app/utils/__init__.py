"""
工具模块

提供公共的工具函数和辅助方法，供路由和 Service 层使用。
"""
from app.utils.query_helpers import (
    get_post_counts,
    get_post_images,
    get_post_tags,
    build_post_detail,
    get_user_follow_counts,
    is_following,
    delete_post_images_files,
)
from app.utils.validators import (
    validate_image_file,
    validate_post_exists,
    validate_user_exists,
    validate_is_author_or_admin,
)

__all__ = [
    # 查询工具
    "get_post_counts",
    "get_post_images",
    "get_post_tags",
    "build_post_detail",
    "get_user_follow_counts",
    "is_following",
    "delete_post_images_files",
    # 验证工具
    "validate_image_file",
    "validate_post_exists",
    "validate_user_exists",
    "validate_is_author_or_admin",
]
