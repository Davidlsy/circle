"""
验证工具函数

提供常用的数据验证和权限检查函数。
"""
from typing import Optional
from fastapi import HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.models import Post, User
from app.config import get_settings

settings = get_settings()


def validate_image_file(file: UploadFile) -> bytes:
    """
    验证图片文件类型和大小

    Args:
        file: 上传的文件

    Returns:
        文件内容字节

    Raises:
        HTTPException: 文件类型不支持或大小超限
    """
    # 校验文件类型
    if file.content_type not in settings.ALLOWED_IMAGE_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"不支持的图片格式，仅支持：{', '.join(settings.ALLOWED_IMAGE_TYPES)}"
        )

    # 读取内容校验大小
    content = file.file.read()
    size = len(content)

    if size > settings.MAX_IMAGE_SIZE:
        max_mb = settings.MAX_IMAGE_SIZE / (1024 * 1024)
        raise HTTPException(
            status_code=400,
            detail=f"单张图片大小不能超过 {max_mb:.0f}MB，当前 {size / (1024*1024):.2f}MB"
        )

    if size == 0:
        raise HTTPException(status_code=400, detail="图片文件不能为空")

    return content


def validate_post_exists(db: Session, post_id: int) -> Post:
    """
    验证帖子是否存在

    Args:
        db: 数据库会话
        post_id: 帖子 ID

    Returns:
        Post 对象

    Raises:
        HTTPException: 帖子不存在
    """
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="帖子不存在")
    return post


def validate_user_exists(db: Session, user_id: int) -> User:
    """
    验证用户是否存在

    Args:
        db: 数据库会话
        user_id: 用户 ID

    Returns:
        User 对象

    Raises:
        HTTPException: 用户不存在
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    return user


def validate_is_author_or_admin(
    post: Post,
    current_user: User,
    action: str = "操作"
) -> None:
    """
    验证当前用户是否为帖子作者或管理员

    Args:
        post: 帖子对象
        current_user: 当前用户
        action: 操作名称（用于错误提示）

    Raises:
        HTTPException: 无权操作
    """
    if post.author_id != current_user.id and not current_user.is_superuser:
        raise HTTPException(status_code=403, detail=f"无权{action}此帖子")


def validate_is_comment_author_or_admin(
    comment,
    current_user: User,
    action: str = "操作"
) -> None:
    """
    验证当前用户是否为评论作者或管理员

    Args:
        comment: 评论对象
        current_user: 当前用户
        action: 操作名称（用于错误提示）

    Raises:
        HTTPException: 无权操作
    """
    if comment.author_id != current_user.id and not current_user.is_superuser:
        raise HTTPException(status_code=403, detail=f"无权{action}此评论")


def ensure_upload_dir() -> None:
    """确保上传目录存在"""
    import os
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
