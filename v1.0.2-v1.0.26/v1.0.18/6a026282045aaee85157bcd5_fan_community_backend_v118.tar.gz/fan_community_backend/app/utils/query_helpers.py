"""
查询工具函数

提供常用的数据库查询辅助函数，消除路由中的重复代码。
"""
from typing import Optional, List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.models import Post, Comment, Like, Collection, PostImage, PostTag, Tag, Follow
from app.schemas import PostDetail, PostImagePublic, TagPublic, UserPublic


def get_post_counts(db: Session, post_id: int) -> Tuple[int, int, int]:
    """
    获取帖子的评论数、点赞数、收藏数

    Args:
        db: 数据库会话
        post_id: 帖子 ID

    Returns:
        (comment_count, like_count, collection_count)
    """
    comment_count = db.query(func.count(Comment.id)).filter(
        Comment.post_id == post_id
    ).scalar() or 0

    like_count = db.query(func.count(Like.id)).filter(
        Like.post_id == post_id
    ).scalar() or 0

    collection_count = db.query(func.count(Collection.id)).filter(
        Collection.post_id == post_id
    ).scalar() or 0

    return comment_count, like_count, collection_count


def get_post_images(db: Session, post_id: int) -> List[PostImagePublic]:
    """
    获取帖子的图片列表

    Args:
        db: 数据库会话
        post_id: 帖子 ID

    Returns:
        图片列表
    """
    images = db.query(PostImage).filter(
        PostImage.post_id == post_id
    ).order_by(PostImage.order, PostImage.created_at).all()
    return [PostImagePublic.model_validate(img) for img in images]


def get_post_tags(db: Session, post_id: int) -> List[TagPublic]:
    """
    获取帖子的标签列表

    Args:
        db: 数据库会话
        post_id: 帖子 ID

    Returns:
        标签列表
    """
    post_tags = db.query(PostTag).filter(PostTag.post_id == post_id).all()
    result = []
    for pt in post_tags:
        db.refresh(pt.tag)
        result.append(TagPublic.model_validate(pt.tag))
    return result


def get_user_follow_counts(db: Session, user_id: int) -> Tuple[int, int]:
    """
    获取用户的粉丝数和关注数

    Args:
        db: 数据库会话
        user_id: 用户 ID

    Returns:
        (follower_count, following_count)
    """
    follower_count = db.query(func.count(Follow.id)).filter(
        Follow.following_id == user_id
    ).scalar() or 0

    following_count = db.query(func.count(Follow.id)).filter(
        Follow.follower_id == user_id
    ).scalar() or 0

    return follower_count, following_count


def is_following(db: Session, follower_id: int, following_id: int) -> bool:
    """
    检查用户是否关注了另一个用户

    Args:
        db: 数据库会话
        follower_id: 关注者 ID
        following_id: 被关注者 ID

    Returns:
        是否已关注
    """
    return db.query(Follow).filter(
        Follow.follower_id == follower_id,
        Follow.following_id == following_id
    ).first() is not None


def is_liked(db: Session, post_id: int, user_id: int) -> bool:
    """
    检查用户是否点赞了帖子

    Args:
        db: 数据库会话
        post_id: 帖子 ID
        user_id: 用户 ID

    Returns:
        是否已点赞
    """
    return db.query(Like).filter(
        Like.post_id == post_id,
        Like.user_id == user_id
    ).first() is not None


def is_collected(db: Session, post_id: int, user_id: int) -> bool:
    """
    检查用户是否收藏了帖子

    Args:
        db: 数据库会话
        post_id: 帖子 ID
        user_id: 用户 ID

    Returns:
        是否已收藏
    """
    return db.query(Collection).filter(
        Collection.post_id == post_id,
        Collection.user_id == user_id
    ).first() is not None


def delete_post_images_files(db: Session, post_id: int, upload_dir: str) -> None:
    """
    删除帖子关联的所有图片文件

    Args:
        db: 数据库会话
        post_id: 帖子 ID
        upload_dir: 上传目录路径
    """
    import os
    images = db.query(PostImage).filter(PostImage.post_id == post_id).all()
    for img in images:
        file_path = os.path.join(upload_dir, os.path.basename(img.url))
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass


def build_post_detail(
    db: Session,
    post: Post,
    current_user_id: Optional[int] = None
) -> PostDetail:
    """
    构建 PostDetail 对象（含评论数/点赞数/是否点赞/收藏数/是否收藏/图片）

    Args:
        db: 数据库会话
        post: Post 模型对象
        current_user_id: 当前用户 ID（用于判断是否点赞/收藏）

    Returns:
        PostDetail 对象
    """
    comment_count, like_count, collection_count = get_post_counts(db, post.id)
    images = get_post_images(db, post.id)
    tags = get_post_tags(db, post.id)

    # 根据当前登录用户判断是否点赞/收藏
    is_liked_flag = False
    is_collected_flag = False
    if current_user_id:
        is_liked_flag = is_liked(db, post.id, current_user_id)
        is_collected_flag = is_collected(db, post.id, current_user_id)

    return PostDetail(
        id=post.id,
        title=post.title,
        content=post.content,
        author_id=post.author_id,
        is_published=post.is_published,
        view_count=post.view_count,
        created_at=post.created_at,
        updated_at=post.updated_at,
        author=UserPublic.model_validate(post.author),
        comment_count=comment_count,
        like_count=like_count,
        is_liked=is_liked_flag,
        collection_count=collection_count,
        is_collected=is_collected_flag,
        images=images,
        tags=tags,
        status=post.status,
    )
