"""
私信服务层

处理私信会话、消息发送、未读计数等业务逻辑。
"""
from datetime import datetime
from typing import Optional, List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import func, or_

from app.models import User, Conversation, Message
from app.services.base import BaseService
from app.schemas import (
    ConversationCreate, ConversationListItem, MessagePublic,
    MessageWithSender, UserPublic
)


class MessageService(BaseService[Message]):
    """私信服务"""

    def __init__(self, db: Session):
        super().__init__(db, Message)

    # ─── 会话管理 ───

    def get_or_create_conversation(
        self,
        current_user_id: int,
        target_user_id: int
    ) -> Conversation:
        """
        获取或创建会话

        Args:
            current_user_id: 当前用户 ID
            target_user_id: 目标用户 ID

        Returns:
            Conversation 对象

        Raises:
            ValueError: 不能给自己发私信 / 用户不存在
        """
        if current_user_id == target_user_id:
            raise ValueError("不能给自己发私信")

        # 确保 user1_id < user2_id，保证唯一性
        uid_a, uid_b = sorted([current_user_id, target_user_id])

        conv = self.db.query(Conversation).filter(
            Conversation.user1_id == uid_a,
            Conversation.user2_id == uid_b
        ).first()

        if not conv:
            conv = Conversation(user1_id=uid_a, user2_id=uid_b)
            self.db.add(conv)
            self.db.commit()
            self.db.refresh(conv)

        return conv

    def list_conversations(
        self,
        user_id: int
    ) -> List[ConversationListItem]:
        """
        获取用户的会话列表

        Returns:
            按最新消息时间倒序的会话列表
        """
        convs = self.db.query(Conversation).filter(
            or_(
                Conversation.user1_id == user_id,
                Conversation.user2_id == user_id
            )
        ).order_by(Conversation.updated_at.desc()).all()

        result = []
        for conv in convs:
            other = self._get_other_user(conv, user_id)

            # 最后一条消息
            last_msg = self.db.query(Message).filter(
                Message.conversation_id == conv.id
            ).order_by(Message.created_at.desc()).first()

            # 未读数
            unread = self.db.query(func.count(Message.id)).filter(
                Message.conversation_id == conv.id,
                Message.sender_id != user_id,
                Message.is_read == False
            ).scalar() or 0

            result.append(ConversationListItem(
                id=conv.id,
                other_user=UserPublic.model_validate(other),
                last_message=MessagePublic.model_validate(last_msg) if last_msg else None,
                unread_count=unread,
                updated_at=conv.updated_at,
                created_at=conv.created_at,
            ))

        return result

    # ─── 消息操作 ───

    def send_message(
        self,
        conversation_id: int,
        sender_id: int,
        content: str
    ) -> MessageWithSender:
        """
        发送消息

        Args:
            conversation_id: 会话 ID
            sender_id: 发送者 ID
            content: 消息内容

        Returns:
            MessageWithSender

        Raises:
            ValueError: 会话不存在 / 无权访问
        """
        conv = self.db.query(Conversation).filter(Conversation.id == conversation_id).first()
        if not conv:
            raise ValueError("会话不存在")

        if sender_id not in (conv.user1_id, conv.user2_id):
            raise ValueError("无权访问此会话")

        msg = Message(
            conversation_id=conversation_id,
            sender_id=sender_id,
            content=content
        )
        self.db.add(msg)

        # 更新会话时间
        conv.updated_at = msg.created_at
        self.db.commit()
        self.db.refresh(msg)

        sender = self.db.query(User).filter(User.id == sender_id).first()
        return MessageWithSender(
            id=msg.id,
            conversation_id=msg.conversation_id,
            sender_id=msg.sender_id,
            content=msg.content,
            is_read=msg.is_read,
            created_at=msg.created_at,
            sender=UserPublic.model_validate(sender),
        )

    def list_messages(
        self,
        conversation_id: int,
        user_id: int,
        page: int = 1,
        page_size: int = 20
    ) -> Tuple[List[MessageWithSender], int]:
        """
        获取会话消息列表

        Returns:
            (messages, total)
        """
        conv = self.db.query(Conversation).filter(Conversation.id == conversation_id).first()
        if not conv:
            raise ValueError("会话不存在")

        if user_id not in (conv.user1_id, conv.user2_id):
            raise ValueError("无权访问此会话")

        query = self.db.query(Message).filter(Message.conversation_id == conversation_id)
        total = query.count()

        messages = query.order_by(Message.created_at.desc())\
            .offset((page - 1) * page_size)\
            .limit(page_size)\
            .all()

        # 倒序展示（最新在上）
        result = []
        for m in reversed(messages):
            result.append(MessageWithSender(
                id=m.id,
                conversation_id=m.conversation_id,
                sender_id=m.sender_id,
                content=m.content,
                is_read=m.is_read,
                created_at=m.created_at,
                sender=UserPublic.model_validate(m.sender),
            ))

        return result, total

    def mark_all_as_read(
        self,
        conversation_id: int,
        user_id: int
    ) -> int:
        """
        标记会话中所有消息为已读

        Returns:
            标记的消息数量
        """
        conv = self.db.query(Conversation).filter(Conversation.id == conversation_id).first()
        if not conv:
            raise ValueError("会话不存在")

        if user_id not in (conv.user1_id, conv.user2_id):
            raise ValueError("无权访问此会话")

        count = self.db.query(Message).filter(
            Message.conversation_id == conversation_id,
            Message.sender_id != user_id,
            Message.is_read == False
        ).update({"is_read": True})

        self.db.commit()
        return count

    def get_total_unread(self, user_id: int) -> int:
        """
        获取用户所有会话的未读消息总数
        """
        total = self.db.query(func.count(Message.id)).filter(
            Message.sender_id != user_id,
            Message.is_read == False,
            or_(
                Message.conversation_id.in_(
                    self.db.query(Conversation.id).filter(Conversation.user1_id == user_id)
                ),
                Message.conversation_id.in_(
                    self.db.query(Conversation.id).filter(Conversation.user2_id == user_id)
                )
            )
        ).scalar() or 0

        return total

    # ─── 辅助方法 ───

    def _get_other_user(self, conv: Conversation, current_user_id: int) -> User:
        """获取会话中的对方用户"""
        if conv.user1_id == current_user_id:
            return conv.user2
        return conv.user1
