"""
帖子服务层

处理帖子、评论、点赞、收藏、图片上传等业务逻辑。
"""
import os
import uuid
from datetime import datetime
from typing import Optional, List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.models import User, Post, Comment, Like, PostImage, Collection, Tag, PostTag
from app.services.base import BaseService
from app.schemas import (
    PostCreate, PostUpdate, PostDetail, PostImagePublic, TagPublic,
    CommentCreate, UserPublic
)
from app.config import get_settings
from fastapi import HTTPException, UploadFile

settings = get_settings()


class PostService(BaseService[Post]):
    """帖子服务"""

    def __init__(self, db: Session):
        super().__init__(db, Post)

    # ─── 帖子 CRUD ───

    def create_post(self, post_data: PostCreate, author: User) -> Post:
        """
        创建帖子

        Args:
            post_data: 帖子数据
            author: 作者

        Returns:
            创建的帖子
        """
        # 管理员直接通过，普通用户待审核
        initial_status = "approved" if author.is_superuser else "pending"
        return self.create(
            title=post_data.title,
            content=post_data.content,
            author_id=author.id,
            is_published=post_data.is_published,
            status=initial_status,
        )

    def get_post_with_details(
        self,
        post_id: int,
        current_user: Optional[User] = None,
        increment_view: bool = True
    ) -> Optional[PostDetail]:
        """
        获取帖子详情

        Args:
            post_id: 帖子 ID
            current_user: 当前用户（用于判断点赞/收藏状态）
            increment_view: 是否增加浏览量

        Returns:
            PostDetail 或 None
        """
        post = self.get_by_id(post_id)
        if not post:
            return None

        # 增加浏览量
        if increment_view:
            post.view_count += 1
            self.db.commit()

        return self._build_post_detail(post, current_user)

    def update_post(self, post: Post, update_data: PostUpdate, user: User) -> Post:
        """
        更新帖子

        Raises:
            PermissionError: 无权修改
        """
        if post.author_id != user.id and not user.is_superuser:
            raise PermissionError("无权修改此帖子")

        update_dict = update_data.model_dump(exclude_unset=True)
        return self.update(post, **update_dict)

    def delete_post(self, post: Post, user: User) -> bool:
        """
        删除帖子

        Raises:
            PermissionError: 无权删除
        """
        if post.author_id != user.id and not user.is_superuser:
            raise PermissionError("无权删除此帖子")

        # 删除关联图片文件
        self._delete_post_images_files(post.id)

        return self.delete(post)

    # ─── 帖子列表 ───

    def list_posts(
        self,
        page: int = 1,
        page_size: int = 10,
        author_id: Optional[int] = None,
        current_user: Optional[User] = None
    ) -> Tuple[List[PostDetail], int]:
        """
        获取帖子列表

        Returns:
            (posts, total)
        """
        query = self.db.query(Post).filter(Post.is_published == True)

        # 权限过滤
        if current_user:
            query = query.filter(
                (Post.author_id == current_user.id) | (Post.status == "approved")
            )
        else:
            query = query.filter(Post.status == "approved")

        if author_id:
            query = query.filter(Post.author_id == author_id)

        total = query.count()
        posts = query.order_by(Post.created_at.desc())\
            .offset((page - 1) * page_size)\
            .limit(page_size)\
            .all()

        post_details = [self._build_post_detail(p, current_user) for p in posts]
        return post_details, total

    # ─── 评论 ───

    def create_comment(
        self,
        post_id: int,
        comment_data: CommentCreate,
        author: User
    ) -> Comment:
        """创建评论"""
        post = self.get_by_id(post_id)
        if not post:
            raise ValueError("帖子不存在")

        if comment_data.parent_id:
            parent = self.db.query(Comment).filter(Comment.id == comment_data.parent_id).first()
            if not parent or parent.post_id != post_id:
                raise ValueError("无效的回复目标")

        initial_status = "approved" if author.is_superuser else "pending"
        comment = Comment(
            content=comment_data.content,
            author_id=author.id,
            post_id=post_id,
            parent_id=comment_data.parent_id,
            status=initial_status,
        )
        self.db.add(comment)
        self.db.commit()
        self.db.refresh(comment)
        return comment

    def delete_comment(self, comment: Comment, user: User) -> bool:
        """删除评论"""
        if comment.author_id != user.id and not user.is_superuser:
            raise PermissionError("无权删除此评论")
        return self.delete(comment)

    # ─── 点赞 ───

    def toggle_like(self, post_id: int, user_id: int) -> Tuple[bool, int]:
        """
        切换点赞状态

        Returns:
            (is_liked, like_count)
        """
        post = self.get_by_id(post_id)
        if not post:
            raise ValueError("帖子不存在")

        existing = self.db.query(Like).filter(
            Like.post_id == post_id,
            Like.user_id == user_id
        ).first()

        if existing:
            self.db.delete(existing)
            self.db.commit()
            liked = False
        else:
            new_like = Like(user_id=user_id, post_id=post_id)
            self.db.add(new_like)
            self.db.commit()
            liked = True

        like_count = self._count_likes(post_id)
        return liked, like_count

    # ─── 收藏 ───

    def toggle_collection(self, post_id: int, user_id: int) -> Tuple[bool, int]:
        """
        切换收藏状态

        Returns:
            (is_collected, collection_count)
        """
        post = self.get_by_id(post_id)
        if not post:
            raise ValueError("帖子不存在")

        existing = self.db.query(Collection).filter(
            Collection.post_id == post_id,
            Collection.user_id == user_id
        ).first()

        if existing:
            self.db.delete(existing)
            self.db.commit()
            collected = False
        else:
            new_collection = Collection(user_id=user_id, post_id=post_id)
            self.db.add(new_collection)
            self.db.commit()
            collected = True

        collection_count = self._count_collections(post_id)
        return collected, collection_count

    # ─── 图片上传 ───

    def upload_images(
        self,
        post_id: int,
        files: List[UploadFile],
        user: User
    ) -> List[PostImage]:
        """上传帖子图片"""
        post = self.get_by_id(post_id)
        if not post:
            raise ValueError("帖子不存在")
        if post.author_id != user.id and not user.is_superuser:
            raise PermissionError("无权为此帖上传图片")

        # 检查图片数量限制
        existing_count = self._count_images(post_id)
        if existing_count >= settings.MAX_IMAGES_PER_POST:
            raise ValueError(f"该帖子已达到最大图片数量上限（{settings.MAX_IMAGES_PER_POST}张）")

        remaining = settings.MAX_IMAGES_PER_POST - existing_count
        if len(files) > remaining:
            raise ValueError(f"最多只能再上传 {remaining} 张图片")

        # 获取当前最大顺序
        max_order = self.db.query(func.max(PostImage.order)).filter(
            PostImage.post_id == post_id
        ).scalar() or 0

        saved_images = []
        for i, file in enumerate(files):
            filename, size = self._save_image_file(file)
            order = max_order + i + 1
            url = f"/uploads/{filename}"

            db_image = PostImage(
                post_id=post_id,
                url=url,
                filename=file.filename or filename,
                size=size,
                order=order
            )
            self.db.add(db_image)
            saved_images.append(db_image)

        self.db.commit()
        for img in saved_images:
            self.db.refresh(img)

        return saved_images

    def delete_image(self, image: PostImage, user: User) -> int:
        """删除图片，返回剩余数量"""
        post = self.get_by_id(image.post_id)
        if post.author_id != user.id and not user.is_superuser:
            raise PermissionError("无权删除此图片")

        # 删除文件
        filename = os.path.basename(image.url)
        file_path = os.path.join(settings.UPLOAD_DIR, filename)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass

        post_id = image.post_id
        self.db.delete(image)
        self.db.commit()

        return self._count_images(post_id)

    # ─── 辅助方法 ───

    def _build_post_detail(self, post: Post, current_user: Optional[User] = None) -> PostDetail:
        """构建 PostDetail 对象"""
        comment_count = self._count_comments(post.id)
        like_count = self._count_likes(post.id)
        collection_count = self._count_collections(post.id)

        is_liked = False
        is_collected = False
        if current_user:
            is_liked = self.db.query(Like).filter(
                Like.post_id == post.id,
                Like.user_id == current_user.id
            ).first() is not None
            is_collected = self.db.query(Collection).filter(
                Collection.post_id == post.id,
                Collection.user_id == current_user.id
            ).first() is not None

        images = self._get_post_images(post.id)
        tags = self._get_post_tags(post.id)

        return PostDetail(
            id=post.id,
            title=post.title,
            content=post.content,
            author_id=post.author_id,
            is_published=post.is_published,
            view_count=post.view_count,
            created_at=post.created_at,
            updated_at=post.updated_at,
            author=UserPublic.model_validate(post.author),
            comment_count=comment_count,
            like_count=like_count,
            is_liked=is_liked,
            collection_count=collection_count,
            is_collected=is_collected,
            images=images,
            tags=tags,
            status=post.status,
        )

    def _count_comments(self, post_id: int) -> int:
        return self.db.query(func.count(Comment.id)).filter(Comment.post_id == post_id).scalar() or 0

    def _count_likes(self, post_id: int) -> int:
        return self.db.query(func.count(Like.id)).filter(Like.post_id == post_id).scalar() or 0

    def _count_collections(self, post_id: int) -> int:
        return self.db.query(func.count(Collection.id)).filter(Collection.post_id == post_id).scalar() or 0

    def _count_images(self, post_id: int) -> int:
        return self.db.query(func.count(PostImage.id)).filter(PostImage.post_id == post_id).scalar() or 0

    def _get_post_images(self, post_id: int) -> List[PostImagePublic]:
        images = self.db.query(PostImage).filter(
            PostImage.post_id == post_id
        ).order_by(PostImage.order, PostImage.created_at).all()
        return [PostImagePublic.model_validate(img) for img in images]

    def _get_post_tags(self, post_id: int) -> List[TagPublic]:
        post_tags = self.db.query(PostTag).filter(PostTag.post_id == post_id).all()
        result = []
        for pt in post_tags:
            self.db.refresh(pt.tag)
            result.append(TagPublic.model_validate(pt.tag))
        return result

    def _save_image_file(self, file: UploadFile) -> Tuple[str, int]:
        """保存图片文件，返回 (filename, size)"""
        os.makedirs(settings.UPLOAD_DIR, exist_ok=True)

        if file.content_type not in settings.ALLOWED_IMAGE_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"不支持的图片格式，仅支持：{', '.join(settings.ALLOWED_IMAGE_TYPES)}"
            )

        content = file.file.read()
        size = len(content)

        if size > settings.MAX_IMAGE_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"单张图片大小不能超过 {settings.MAX_IMAGE_SIZE / (1024*1024):.0f}MB"
            )

        if size == 0:
            raise HTTPException(status_code=400, detail="图片文件不能为空")

        ext = os.path.splitext(file.filename or ".jpg")[1] or ".jpg"
        unique_name = f"{uuid.uuid4().hex}{ext}"
        file_path = os.path.join(settings.UPLOAD_DIR, unique_name)

        with open(file_path, "wb") as f:
            f.write(content)

        return unique_name, size

    def _delete_post_images_files(self, post_id: int) -> None:
        """删除帖子的图片文件"""
        images = self.db.query(PostImage).filter(PostImage.post_id == post_id).all()
        for img in images:
            file_path = os.path.join(settings.UPLOAD_DIR, os.path.basename(img.url))
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except OSError:
                    pass
