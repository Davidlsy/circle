"""
用户服务层

处理用户资料、关注关系等业务逻辑。
依赖 UserRepository 和 FollowRepository 进行数据访问。
"""
from datetime import datetime
from typing import Optional, Tuple, List
from sqlalchemy.orm import Session

from app.models import User
from app.services.base import BaseService
from app.repositories import UserRepository, FollowRepository
from app.schemas import UserUpdate, UserProfile, UserWithCounts, FollowStatus


class UserService(BaseService[User]):
    """用户服务"""

    def __init__(self, db: Session):
        super().__init__(db, User)
        self.user_repo = UserRepository(db)
        self.follow_repo = FollowRepository(db)

    # ─── 用户资料 ───

    def get_profile(self, user_id: int) -> Optional[UserProfile]:
        """获取用户资料（含粉丝数/关注数）"""
        user = self.user_repo.get_by_id(user_id)
        if not user:
            return None

        follower_count, following_count = self.follow_repo.count_followers(user_id), self.follow_repo.count_following(user_id)
        return UserProfile(
            id=user.id,
            username=user.username,
            nickname=user.nickname,
            avatar_url=user.avatar_url,
            bio=user.bio,
            is_superuser=user.is_superuser,
            created_at=user.created_at,
            follower_count=follower_count,
            following_count=following_count,
        )

    def update_profile(self, user: User, update_data: UserUpdate) -> User:
        """更新用户资料"""
        # 检查邮箱唯一性
        if update_data.email:
            if self.user_repo.exists_other_with_email(user.id, update_data.email):
                raise ValueError("该邮箱已被使用")

        # 检查手机号唯一性
        if update_data.phone:
            if self.user_repo.exists_other_with_phone(user.id, update_data.phone):
                raise ValueError("该手机号已被使用")

        # 更新字段
        update_dict = update_data.model_dump(exclude_unset=True)
        for key, value in update_dict.items():
            setattr(user, key, value)

        user.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(user)
        return user

    # ─── 关注统计 ───

    def get_follow_counts(self, user_id: int) -> Tuple[int, int]:
        """获取用户的粉丝数和关注数"""
        follower_count = self.follow_repo.count_followers(user_id)
        following_count = self.follow_repo.count_following(user_id)
        return follower_count, following_count

    def get_user_with_counts(self, user: User) -> UserWithCounts:
        """获取带统计数据的用户信息"""
        follower_count, following_count = self.get_follow_counts(user.id)
        return UserWithCounts(
            id=user.id,
            username=user.username,
            nickname=user.nickname,
            avatar_url=user.avatar_url,
            bio=user.bio,
            is_superuser=user.is_superuser,
            created_at=user.created_at,
            follower_count=follower_count,
            following_count=following_count,
        )

    # ─── 关注关系 ───

    def is_following(self, follower_id: int, following_id: int) -> bool:
        """检查是否关注"""
        return self.follow_repo.is_following(follower_id, following_id)

    def toggle_follow(self, current_user_id: int, target_user_id: int) -> Tuple[bool, str]:
        """切换关注状态"""
        if current_user_id == target_user_id:
            raise ValueError("不能关注自己")

        target = self.user_repo.get_by_id(target_user_id)
        if not target:
            raise ValueError("用户不存在")

        if self.follow_repo.is_following(current_user_id, target_user_id):
            self.follow_repo.delete_relation(current_user_id, target_user_id)
            return False, "取消关注成功"
        else:
            self.follow_repo.create_relation(current_user_id, target_user_id)
            return True, "关注成功"

    def get_follow_status(self, current_user_id: Optional[int], target_user_id: int) -> FollowStatus:
        """获取关注状态"""
        follower_count, following_count = self.get_follow_counts(target_user_id)

        is_following = False
        is_followed_by = False

        if current_user_id and current_user_id != target_user_id:
            is_following = self.is_following(current_user_id, target_user_id)
            is_followed_by = self.is_following(target_user_id, current_user_id)

        return FollowStatus(
            is_following=is_following,
            is_followed_by=is_followed_by,
            follower_count=follower_count,
            following_count=following_count,
        )

    # ─── 粉丝/关注列表 ───

    def get_followers(self, user_id: int, skip: int = 0, limit: int = 20) -> Tuple[List[UserWithCounts], int]:
        """获取粉丝列表"""
        follows, total = self.follow_repo.get_followers(user_id, skip, limit)
        users = [self.get_user_with_counts(f.follower) for f in follows]
        return users, total

    def get_following(self, user_id: int, skip: int = 0, limit: int = 20) -> Tuple[List[UserWithCounts], int]:
        """获取关注列表"""
        follows, total = self.follow_repo.get_following(user_id, skip, limit)
        users = [self.get_user_with_counts(f.following) for f in follows]
        return users, total

    def get_friends(self, user_id: int, skip: int = 0, limit: int = 20) -> Tuple[List[UserWithCounts], int]:
        """获取互相关注的好友列表"""
        mutual, total = self.follow_repo.get_mutual_followers(user_id, skip, limit)
        users = [self.get_user_with_counts(f.following) for f in mutual]
        return users, total
