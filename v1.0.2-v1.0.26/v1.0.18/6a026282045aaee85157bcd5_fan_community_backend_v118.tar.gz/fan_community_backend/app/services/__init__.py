"""
Service 层

业务逻辑层，负责处理核心业务规则，介于 Router 和 Model 之间。
Router → Service → Model/Repository
"""
from app.services.base import BaseService
from app.services.auth_service import AuthService
from app.services.user_service import UserService
from app.services.post_service import PostService
from app.services.message_service import MessageService

__all__ = [
    "BaseService",
    "AuthService",
    "UserService",
    "PostService",
    "MessageService",
]
