from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # JWT 配置
    SECRET_KEY: str = "your-super-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30            # Access Token 有效期：30 分钟
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7               # Refresh Token 有效期：7 天

    # 数据库
    DATABASE_URL: str = "sqlite:///./fan_community.db"

    # 数据库连接池配置
    DB_POOL_SIZE: int = 10                          # 连接池保持的连接数
    DB_MAX_OVERFLOW: int = 20                       # 超出 pool_size 后可临时创建的最大连接数
    DB_POOL_RECYCLE: int = 3600                     # 连接回收时间（秒），防止数据库断开长连接
    DB_POOL_PRE_PING: bool = True                   # 每次从池中取出连接前先 ping，自动剔除失效连接
    DB_POOL_TIMEOUT: int = 30                       # 获取连接的等待超时时间（秒）
    DB_ECHO: bool = False                           # 是否打印 SQL 语句（开发调试用）

    # 图片上传配置
    UPLOAD_DIR: str = "uploads"                    # 图片存储目录（local 模式使用）
    MAX_IMAGE_SIZE: int = 5 * 1024 * 1024          # 单张图片最大 5MB
    MAX_IMAGES_PER_POST: int = 9                    # 单篇帖子最多 9 张图
    ALLOWED_IMAGE_TYPES: list = ["image/jpeg", "image/png", "image/gif", "image/webp"]

    # 存储后端配置
    # 可选值: local（本地文件系统）、oss（阿里云 OSS）、s3（AWS S3 / 兼容 S3）
    STORAGE_BACKEND: str = "local"

    # OSS 配置（STORAGE_BACKEND=oss 时使用）
    OSS_ACCESS_KEY_ID: str = ""
    OSS_ACCESS_KEY_SECRET: str = ""
    OSS_ENDPOINT: str = "oss-cn-hangzhou.aliyuncs.com"
    OSS_BUCKET_NAME: str = ""
    OSS_CDN_DOMAIN: str = ""                        # 可选，CDN 加速域名

    # S3 配置（STORAGE_BACKEND=s3 时使用）
    S3_ACCESS_KEY_ID: str = ""
    S3_SECRET_ACCESS_KEY: str = ""
    S3_ENDPOINT_URL: str = "https://s3.amazonaws.com"
    S3_BUCKET_NAME: str = ""
    S3_REGION: str = "us-east-1"
    S3_CDN_DOMAIN: str = ""                         # 可选，CDN 加速域名

    # CORS 配置
    # 生产环境请在 .env 文件中设置具体前端域名，逗号分隔，例如：
    # CORS_ORIGINS=http://localhost:3000,https://example.com
    CORS_ORIGINS: str = ""  # 空字符串表示仅允许本地开发，生产环境必须设置

    class Config:
        env_file = ".env"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
