"""
OSS 存储后端（阿里云）

使用阿里云 OSS 存储文件，适用于生产环境。

使用前需安装依赖：
    pip install oss2

环境变量配置：
    STORAGE_BACKEND=oss
    OSS_ACCESS_KEY_ID=your_access_key_id
    OSS_ACCESS_KEY_SECRET=your_access_key_secret
    OSS_ENDPOINT=oss-cn-hangzhou.aliyuncs.com
    OSS_BUCKET_NAME=your-bucket-name
    OSS_CDN_DOMAIN=https://cdn.example.com  # 可选，CDN 加速域名
"""
from typing import Optional

from app.storage.base import StorageBackend


class OSSStorage(StorageBackend):
    """
    阿里云 OSS 存储后端

    - save: 上传到 OSS，返回 CDN 或 OSS 访问 URL
    - delete: 从 OSS 删除文件
    - exists: 检查 OSS 中文件是否存在
    - get_url: 返回文件的完整访问 URL
    """

    def __init__(self):
        from app.config import get_settings
        settings = get_settings()

        self.endpoint = settings.OSS_ENDPOINT
        self.bucket_name = settings.OSS_BUCKET_NAME
        self.cdn_domain = settings.OSS_CDN_DOMAIN or ""

        try:
            import oss2
            auth = oss2.Auth(settings.OSS_ACCESS_KEY_ID, settings.OSS_ACCESS_KEY_SECRET)
            self.bucket = oss2.Bucket(auth, self.endpoint, self.bucket_name)
        except ImportError:
            raise ImportError(
                "使用 OSS 存储需要安装 oss2：pip install oss2"
            )

    def save(self, content: bytes, filename: str, content_type: Optional[str] = None) -> str:
        """上传文件到 OSS"""
        import uuid
        ext = filename.rsplit(".", 1)[-1] if "." in filename else "jpg"
        object_key = f"uploads/{uuid.uuid4().hex}.{ext}"

        headers = {}
        if content_type:
            headers["Content-Type"] = content_type

        self.bucket.put_object(object_key, content, headers=headers)
        return self.get_url(object_key)

    def delete(self, url: str) -> bool:
        """从 OSS 删除文件"""
        object_key = self._url_to_object_key(url)
        if not object_key:
            return False
        try:
            self.bucket.delete_object(object_key)
            return True
        except Exception:
            return False

    def exists(self, url: str) -> bool:
        """检查 OSS 中文件是否存在"""
        object_key = self._url_to_object_key(url)
        if not object_key:
            return False
        try:
            return self.bucket.object_exists(object_key)
        except Exception:
            return False

    def get_url(self, filename: str) -> str:
        """获取文件访问 URL（优先使用 CDN 域名）"""
        if self.cdn_domain:
            return f"{self.cdn_domain.rstrip('/')}/{filename}"
        return f"https://{self.bucket_name}.{self.endpoint}/{filename}"

    def _url_to_object_key(self, url: str) -> Optional[str]:
        """从 URL 中提取 OSS object key"""
        # CDN URL: https://cdn.example.com/uploads/xxx.jpg -> uploads/xxx.jpg
        if self.cdn_domain and url.startswith(self.cdn_domain):
            return url[len(self.cdn_domain.rstrip('/')) + 1:]
        # OSS URL: https://bucket.oss-cn-xxx.aliyuncs.com/uploads/xxx.jpg -> uploads/xxx.jpg
        prefix = f"https://{self.bucket_name}.{self.endpoint}/"
        if url.startswith(prefix):
            return url[len(prefix):]
        return url  # 直接作为 object key
