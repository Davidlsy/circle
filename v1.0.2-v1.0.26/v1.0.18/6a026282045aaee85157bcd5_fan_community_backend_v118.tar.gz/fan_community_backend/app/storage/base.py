"""
存储后端抽象基类

定义统一的文件存储接口，所有存储后端必须实现这些方法。
"""
from abc import ABC, abstractmethod
from typing import Optional


class StorageBackend(ABC):
    """
    存储后端抽象基类

    所有存储后端（Local、OSS、S3 等）都必须实现以下方法。
    """

    @abstractmethod
    def save(self, content: bytes, filename: str, content_type: Optional[str] = None) -> str:
        """
        保存文件

        Args:
            content: 文件二进制内容
            filename: 原始文件名（含扩展名）
            content_type: 文件 MIME 类型（可选）

        Returns:
            str: 文件的访问 URL

        Raises:
            Exception: 保存失败时抛出异常
        """
        pass

    @abstractmethod
    def delete(self, url: str) -> bool:
        """
        删除文件

        Args:
            url: 文件的访问 URL（即 save 返回的 URL）

        Returns:
            bool: 是否删除成功

        Raises:
            Exception: 删除失败时抛出异常
        """
        pass

    @abstractmethod
    def exists(self, url: str) -> bool:
        """
        检查文件是否存在

        Args:
            url: 文件的访问 URL

        Returns:
            bool: 文件是否存在
        """
        pass

    @abstractmethod
    def get_url(self, filename: str) -> str:
        """
        根据文件名获取完整的访问 URL

        Args:
            filename: 文件名（存储后返回的唯一文件名）

        Returns:
            str: 完整的访问 URL
        """
        pass
