"""
存储后端工厂

根据配置创建对应的存储后端实例（单例模式）。
"""
from functools import lru_cache

from app.storage.base import StorageBackend
from app.storage.local import LocalStorage


@lru_cache()
def get_storage() -> StorageBackend:
    """
    根据配置获取存储后端实例（单例）

    通过 STORAGE_BACKEND 环境变量切换：
    - local: 本地文件系统（默认）
    - oss: 阿里云 OSS
    - s3: AWS S3 / 兼容 S3 协议

    Returns:
        StorageBackend: 存储后端实例
    """
    from app.config import get_settings
    settings = get_settings()

    backend = settings.STORAGE_BACKEND.lower()

    if backend == "local":
        return LocalStorage()
    elif backend == "oss":
        from app.storage.oss import OSSStorage
        return OSSStorage()
    elif backend == "s3":
        from app.storage.s3 import S3Storage
        return S3Storage()
    else:
        raise ValueError(
            f"不支持的存储后端: {backend}，"
            f"可选值: local, oss, s3"
        )
