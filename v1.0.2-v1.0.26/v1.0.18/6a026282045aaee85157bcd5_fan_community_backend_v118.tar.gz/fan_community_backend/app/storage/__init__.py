"""
存储抽象层

提供统一的文件存储接口，支持多种存储后端切换：
- local: 本地文件系统（默认，开发环境）
- oss: 阿里云 OSS（生产环境）
- s3: AWS S3 / 兼容 S3 协议的对象存储（生产环境）

通过 STORAGE_BACKEND 环境变量切换后端，无需修改业务代码。
"""
from app.storage.base import StorageBackend
from app.storage.local import LocalStorage
from app.storage.factory import get_storage

__all__ = [
    "StorageBackend",
    "LocalStorage",
    "get_storage",
]
