"""
本地文件系统存储后端

将文件保存到本地磁盘，通过 FastAPI StaticFiles 提供访问。
适用于开发环境和单机部署。
"""
import os
import uuid
from typing import Optional

from app.storage.base import StorageBackend
from app.config import get_settings


class LocalStorage(StorageBackend):
    """
    本地文件系统存储

    - save: 保存到 UPLOAD_DIR，返回 /uploads/{unique_name}
    - delete: 从 UPLOAD_DIR 删除文件
    - exists: 检查文件是否存在
    - get_url: 返回 /uploads/{filename}
    """

    def __init__(self):
        settings = get_settings()
        self.upload_dir = settings.UPLOAD_DIR
        self.base_url = "/uploads"
        # 确保上传目录存在
        os.makedirs(self.upload_dir, exist_ok=True)

    def save(self, content: bytes, filename: str, content_type: Optional[str] = None) -> str:
        """
        保存文件到本地磁盘

        Args:
            content: 文件二进制内容
            filename: 原始文件名
            content_type: MIME 类型（本地存储不使用）

        Returns:
            str: 访问 URL，格式为 /uploads/{unique_name}
        """
        # 生成唯一文件名，保留原始扩展名
        ext = os.path.splitext(filename)[1] or ".jpg"
        unique_name = f"{uuid.uuid4().hex}{ext}"
        file_path = os.path.join(self.upload_dir, unique_name)

        with open(file_path, "wb") as f:
            f.write(content)

        return self.get_url(unique_name)

    def delete(self, url: str) -> bool:
        """
        从本地磁盘删除文件

        Args:
            url: 访问 URL，格式为 /uploads/{filename}

        Returns:
            bool: 是否删除成功
        """
        filename = self._url_to_filename(url)
        if not filename:
            return False

        file_path = os.path.join(self.upload_dir, filename)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                return True
            except OSError:
                return False
        return False

    def exists(self, url: str) -> bool:
        """检查文件是否存在"""
        filename = self._url_to_filename(url)
        if not filename:
            return False
        file_path = os.path.join(self.upload_dir, filename)
        return os.path.exists(file_path)

    def get_url(self, filename: str) -> str:
        """
        根据文件名获取访问 URL

        Args:
            filename: 唯一文件名

        Returns:
            str: 访问 URL，格式为 /uploads/{filename}
        """
        return f"{self.base_url}/{filename}"

    def _url_to_filename(self, url: str) -> Optional[str]:
        """从 URL 中提取文件名"""
        if url.startswith(self.base_url + "/"):
            return url[len(self.base_url) + 1:]
        # 兼容完整 URL
        return os.path.basename(url) or None
