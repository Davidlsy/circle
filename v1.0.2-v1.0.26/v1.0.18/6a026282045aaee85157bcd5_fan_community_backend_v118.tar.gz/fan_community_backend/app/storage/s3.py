"""
S3 存储后端（AWS S3 / 兼容 S3 协议的对象存储）

使用 boto3 操作 S3，适用于生产环境。

使用前需安装依赖：
    pip install boto3

环境变量配置：
    STORAGE_BACKEND=s3
    S3_ACCESS_KEY_ID=your_access_key_id
    S3_SECRET_ACCESS_KEY=your_secret_access_key
    S3_ENDPOINT_URL=https://s3.amazonaws.com  # 或兼容 S3 的端点
    S3_BUCKET_NAME=your-bucket-name
    S3_REGION=us-east-1
    S3_CDN_DOMAIN=https://cdn.example.com  # 可选，CDN 加速域名
"""
from typing import Optional

from app.storage.base import StorageBackend


class S3Storage(StorageBackend):
    """
    AWS S3 / 兼容 S3 协议的存储后端

    - save: 上传到 S3，返回 CDN 或 S3 访问 URL
    - delete: 从 S3 删除文件
    - exists: 检查 S3 中文件是否存在
    - get_url: 返回文件的完整访问 URL
    """

    def __init__(self):
        from app.config import get_settings
        settings = get_settings()

        self.bucket_name = settings.S3_BUCKET_NAME
        self.region = settings.S3_REGION
        self.cdn_domain = settings.S3_CDN_DOMAIN or ""

        try:
            import boto3
            self.s3_client = boto3.client(
                "s3",
                aws_access_key_id=settings.S3_ACCESS_KEY_ID,
                aws_secret_access_key=settings.S3_SECRET_ACCESS_KEY,
                endpoint_url=settings.S3_ENDPOINT_URL,
                region_name=self.region,
            )
        except ImportError:
            raise ImportError(
                "使用 S3 存储需要安装 boto3：pip install boto3"
            )

    def save(self, content: bytes, filename: str, content_type: Optional[str] = None) -> str:
        """上传文件到 S3"""
        import uuid
        ext = filename.rsplit(".", 1)[-1] if "." in filename else "jpg"
        object_key = f"uploads/{uuid.uuid4().hex}.{ext}"

        extra_args = {}
        if content_type:
            extra_args["ContentType"] = content_type

        self.s3_client.put_object(
            Bucket=self.bucket_name,
            Key=object_key,
            Body=content,
            **extra_args,
        )
        return self.get_url(object_key)

    def delete(self, url: str) -> bool:
        """从 S3 删除文件"""
        object_key = self._url_to_object_key(url)
        if not object_key:
            return False
        try:
            self.s3_client.delete_object(Bucket=self.bucket_name, Key=object_key)
            return True
        except Exception:
            return False

    def exists(self, url: str) -> bool:
        """检查 S3 中文件是否存在"""
        object_key = self._url_to_object_key(url)
        if not object_key:
            return False
        try:
            self.s3_client.head_object(Bucket=self.bucket_name, Key=object_key)
            return True
        except Exception:
            return False

    def get_url(self, filename: str) -> str:
        """获取文件访问 URL（优先使用 CDN 域名）"""
        if self.cdn_domain:
            return f"{self.cdn_domain.rstrip('/')}/{filename}"
        return f"https://{self.bucket_name}.s3.{self.region}.amazonaws.com/{filename}"

    def _url_to_object_key(self, url: str) -> Optional[str]:
        """从 URL 中提取 S3 object key"""
        if self.cdn_domain and url.startswith(self.cdn_domain):
            return url[len(self.cdn_domain.rstrip('/')) + 1:]
        # S3 URL: https://bucket.s3.region.amazonaws.com/uploads/xxx.jpg
        prefix = f"https://{self.bucket_name}.s3.{self.region}.amazonaws.com/"
        if url.startswith(prefix):
            return url[len(prefix):]
        return url
