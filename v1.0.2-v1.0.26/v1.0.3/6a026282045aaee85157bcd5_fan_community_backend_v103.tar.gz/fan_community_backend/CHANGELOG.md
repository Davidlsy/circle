# 粉丝社群平台 - 变更日志 / CHANGELOG

---

## v1.0.3 - CORS 安全加固

> **版本：** v1.0.3
> **日期：** 2026-05-12
> **功能：** CORS 安全加固
> **安全问题：** 高风险（CVSS 中-高危）

---

## 一、问题背景

在 v1.0.2 及之前版本中，CORS 配置使用了 `allow_origins=["*"]`，允许所有来源的跨域请求。这一配置在开发环境下虽然方便，但存在以下安全风险：

1. **跨站请求伪造（CSRF）风险**：任何网站都可以向后端发起跨域请求，利用用户的登录态执行敏感操作
2. **数据泄露风险**：恶意网站可以通过 CORS 读取用户的私有数据
3. **不符合安全最佳实践**：生产环境不应允许无限制的跨域访问

---

## 二、修改内容

### 1. `app/config.py` - 新增 CORS 配置项

在配置类中添加 `CORS_ORIGINS` 配置项：

```python
# CORS 配置
# 生产环境请在 .env 文件中设置具体前端域名，逗号分隔，例如：
# CORS_ORIGINS=http://localhost:3000,https://example.com
CORS_ORIGINS: str = ""  # 空字符串表示仅允许本地开发，生产环境必须设置
```

**配置说明：**

| 环境 | CORS_ORIGINS 值 | 允许的来源 |
|------|-----------------|-----------|
| 开发环境（未设置） | 空字符串 | `http://localhost:3000`, `http://127.0.0.1:3000` |
| 生产环境 | `http://example.com,https://www.example.com` | 仅列表中的域名 |

---

### 2. `app/main.py` - 收紧 CORS 配置

**修改前：**
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境记得改成具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

**修改后：**
```python
# CORS 配置：根据环境变量动态设置允许的前端域名
# 开发环境：CORS_ORIGINS 未设置或为空，仅允许 localhost
# 生产环境：CORS_ORIGINS 设置为具体前端域名，逗号分隔
_origins = settings.CORS_ORIGINS
if _origins:
    cors_origins = [origin.strip() for origin in _origins.split(",") if origin.strip()]
else:
    # 生产环境必须设置 CORS_ORIGINS，未设置时仅允许本地开发
    cors_origins = ["http://localhost:3000", "http://127.0.0.1:3000"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

同时将 API 版本号从 `1.0.2` 更新为 `1.0.3`。

---

### 3. `.env.example` - 新增环境变量示例（建议新建）

```env
# CORS 配置 - 生产环境必须设置
# 多个域名用逗号分隔
CORS_ORIGINS=http://localhost:3000,https://your-frontend-domain.com
```

---

## 三、部署指南

### 开发环境

无需修改任何配置，默认仅允许 `localhost:3000` 和 `127.0.0.1:3000` 访问。

### 生产环境

**步骤 1：在 `.env` 文件中设置前端域名**

```env
# .env 文件
CORS_ORIGINS=https://your-frontend-domain.com
```

如果有多域名需求：
```env
CORS_ORIGINS=https://example.com,https://www.example.com,https://app.example.com
```

**步骤 2：验证配置**

启动服务后，可以通过以下方式验证：
```bash
# 检查启动日志中的 CORS 配置
curl -I -X OPTIONS https://your-api-domain.com/ \
  -H "Origin: https://your-frontend-domain.com"
# 应返回 200，且 Access-Control-Allow-Origin 头为对应域名

curl -I -X OPTIONS https://your-api-domain.com/ \
  -H "Origin: https://malicious-site.com"
# 应返回 403 或不包含 Access-Control-Allow-Origin 头
```

---

## 四、安全建议

1. **务必在生产环境设置 CORS_ORIGINS**：`allow_origins=["*"]` 会将 API 暴露给所有网站
2. **使用 HTTPS**：确保前端和后端都使用 HTTPS，避免 Cookie 被劫持
3. **最小权限原则**：只允许必要的域名，不要添加无关域名
4. **定期审查**：定期检查 CORS 配置，确保没有遗漏的测试域名

---

## 五、影响范围

| 影响项 | 说明 |
|--------|------|
| API 版本 | 从 1.0.2 升级到 1.0.3 |
| 向后兼容 | ✅ 向后兼容，无破坏性变更 |
| 前端适配 | 前端域名必须在 CORS_ORIGINS 中配置 |
| 部署要求 | 生产环境必须设置 CORS_ORIGINS |

---

## 六、相关文档更新

以下文档需要同步更新：

- `README.md` - 环境变量章节添加 CORS_ORIGINS 说明
- `REQUIREMENTS.md` - 生产部署注意事项补充 CORS 配置说明

---

## 七、测试清单

- [ ] 开发环境下，localhost:3000 可以正常访问 API
- [ ] 生产环境下，配置的域名可以正常访问 API
- [ ] 未配置的域名访问 API 被拒绝
- [ ] 携带 credentials 的请求正常工作
- [ ] 跨域预检请求（OPTIONS）正常工作

---

## 八、回滚方案

如需回滚到 v1.0.2 的宽松配置，在 `.env` 文件中设置：

```env
CORS_ORIGINS=*
```

⚠️ **警告**：仅建议在紧急情况或开发测试时使用，生产环境务必配置具体域名。

---

---

# 历史版本

## v1.0.2 - 用户资料功能补丁

> **版本：** v1.0.2
> **日期：** 2026-04-17
> **功能：** 用户资料编辑功能

### 新增功能
- 用户可编辑个人资料（昵称、头像、简介、邮箱、手机号）
- `PATCH /users/me` 接口

---

## v1.0.1 - 用户资料功能补丁

> **版本：** v1.0.1
> **日期：** 2026-04-17
> **功能：** 用户资料功能补丁

---

## v1.0.0 - 内容审核功能

> **版本：** v1.0.0
> **日期：** 2026-04-17
> **功能：** 内容审核

### 新增功能
- 所有用户发布的内容（帖子、评论）默认进入待审核状态
- 管理员可对内容进行通过或驳回操作
- 新增 `/admin` 路由组，包含 9 个审核相关接口

### 数据模型变更
- `posts` 表新增 `status` 字段
- `comments` 表新增 `status` 字段
