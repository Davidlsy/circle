# 变更日志 / CHANGELOG - 内容审核功能

> **版本：** v1.0.0
> **日期：** 2026-04-17
> **功能：** 内容审核

---

## 一、需求说明

所有用户发布的内容（帖子、评论）默认进入**待审核状态**，管理员可对内容进行**通过**或**驳回**操作。只有审核通过的内容才会出现在公开列表中。

---

## 二、数据模型变更

### `posts` 表新增字段

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| status | VARCHAR(20) | 'pending' | pending(待审) / approved(通过) / rejected(驳回) |

### `comments` 表新增字段

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| status | VARCHAR(20) | 'pending' | pending(待审) / approved(通过) / rejected(驳回) |

---

## 三、具体修改

### 1. `app/models.py`

`Post` 和 `Comment` 模型均新增 `status` 字段，默认值 `"pending"`。

---

### 2. `app/schemas.py`

- `PostPublic` / `PostDetail` 新增 `status` 字段
- `CommentPublic` 新增 `status` 字段
- 新增审核相关 Pydantic 模型：`AuditRequest` / `AuditResponse` / `PendingPostItem` / `PendingPostList` / `PendingCommentItem` / `PendingCommentList`

---

### 3. `app/routers/audit_router.py`（新建）

新增 9 个管理员接口：

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/admin/posts/pending` | 待审核帖子列表 |
| `GET` | `/admin/posts/rejected` | 已驳回帖子列表 |
| `POST` | `/admin/posts/{id}/audit` | 审核帖子（通过/驳回） |
| `POST` | `/admin/posts/{id}/approve` | 快捷通过帖子 |
| `POST` | `/admin/posts/{id}/reject` | 快捷驳回帖子 |
| `GET` | `/admin/comments/pending` | 待审核评论列表 |
| `POST` | `/admin/comments/{id}/audit` | 审核评论（通过/驳回） |
| `POST` | `/admin/comments/{id}/approve` | 快捷通过评论 |
| `POST` | `/admin/comments/{id}/reject` | 快捷驳回评论 |

**权限：** 所有接口仅 `is_superuser=True` 的管理员可访问。

---

### 4. `app/routers/post_router.py`

- `POST /posts/` — 普通用户发帖：`status="pending"`；管理员发帖：`status="approved"`
- `GET /posts/` — 列表过滤：作者本人可见自己的所有状态帖子；其他人只看 `status="approved"`
- `GET /posts/{id}` — 详情权限同上
- `POST /posts/{id}/comments` — 评论：普通用户 `status="pending"`；管理员 `status="approved"`
- `GET /posts/{id}/comments` — 评论列表：只返回 `status="approved"` 的评论

---

### 5. `app/routers/feed_router.py`

- 动态流只显示 `status="approved"` 的帖子

---

### 6. `app/main.py`

注册 `audit_router`，prefix `/admin`。

---

### 7. `schema.sql`

`posts` 和 `comments` 表新增 `status VARCHAR(20) DEFAULT 'pending'` 字段。

---

## 四、审核流程

### 帖子审核流程

```
用户发帖 → status=pending（不在公开列表显示）
    ↓
管理员审阅 → approve（出现在公开列表）
    或
管理员审阅 → reject（仅作者和管理员可见状态为 rejected）
```

### 评论审核流程

```
用户评论 → status=pending（不在评论列表显示）
    ↓
管理员审阅 → approve（出现在评论区）
    或
管理员审阅 → reject
```

---

## 五、接口详情

### 待审核帖子列表

```
GET /admin/posts/pending?page=1&page_size=20
→ PendingPostList: { posts, total, page, page_size }
```

### 审核帖子（通用）

```
POST /admin/posts/1/audit
Body: { "status": "approved", "reason": "" }
→ AuditResponse: { msg, id, status }
```

### 快捷通过/驳回

```
POST /admin/posts/1/approve
→ AuditResponse: { msg: "帖子已通过", id: 1, status: "approved" }

POST /admin/posts/1/reject
Body: ?reason=（query参数）
→ AuditResponse: { msg: "帖子已驳回", id: 1, status: "rejected" }
```

### 待审核评论列表

```
GET /admin/comments/pending?page=1&page_size=20
→ PendingCommentList: { comments, total, page, page_size }
```

---

## 六、内容可见性规则

| 状态 | 作者本人 | 其他登录用户 | 管理员 | 未登录 |
|------|---------|-------------|--------|--------|
| pending | ✅ | ❌ | ✅ | ❌ |
| approved | ✅ | ✅ | ✅ | ✅ |
| rejected | ✅ | ❌ | ✅ | ❌ |

---

## 七、数据库现状

当前共 **12 张表**（无新增表，仅在 posts/comments 上扩展字段）：

users / posts / comments / likes / follows / verification_codes / post_images / collections / conversations / messages / tags / post_tags
