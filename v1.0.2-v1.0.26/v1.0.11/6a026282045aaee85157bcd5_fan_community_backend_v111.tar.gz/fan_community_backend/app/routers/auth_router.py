from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, VerificationCode
from app.schemas import (
    UserCreate, UserPublic, TokenPair, Msg,
    ForgotPasswordRequest, ForgotPasswordResponse, ResetPasswordRequest,
    RefreshTokenRequest,
)
from app.auth import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    save_refresh_token,
    verify_refresh_token,
    revoke_refresh_token,
    revoke_all_refresh_tokens,
    get_current_active_user,
)
from app.config import get_settings
from datetime import timedelta, datetime
import secrets

router = APIRouter(prefix="/auth", tags=["认证"])
settings = get_settings()


@router.post("/register", response_model=UserPublic, status_code=status.HTTP_201_CREATED)
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """
    用户注册
    - username: 唯一，必填，3-50字符
    - password: 必填，最少6字符
    - email/phone/nickname: 选填
    """
    # 检查用户名是否已存在
    if db.query(User).filter(User.username == user_data.username).first():
        raise HTTPException(status_code=400, detail="用户名已被注册")

    # 检查邮箱唯一性（如果提供了）
    if user_data.email and db.query(User).filter(User.email == user_data.email).first():
        raise HTTPException(status_code=400, detail="邮箱已被注册")

    # 检查手机号唯一性（如果提供了）
    if user_data.phone and db.query(User).filter(User.phone == user_data.phone).first():
        raise HTTPException(status_code=400, detail="手机号已被注册")

    # 创建用户
    user = User(
        username=user_data.username,
        email=user_data.email,
        phone=user_data.phone,
        nickname=user_data.nickname or user_data.username,
        hashed_password=hash_password(user_data.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=TokenPair)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """
    用户登录（OAuth2 兼容方式）
    - username 字段传用户名或邮箱
    - password 字段传密码
    返回 access_token 和 refresh_token，前端需保存：
      - access_token: 放在请求头 Authorization: Bearer <access_token>
      - refresh_token: 在 access_token 过期时用于刷新
    """
    # 支持 username 或 email 登录
    user = db.query(User).filter(
        (User.username == form_data.username) | (User.email == form_data.username)
    ).first()

    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用户名或密码错误",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        raise HTTPException(status_code=400, detail="用户已被禁用")

    # 生成双 Token
    access_token = create_access_token(
        data={"sub": user.id},
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    refresh_token = create_refresh_token(
        data={"sub": user.id},
        expires_delta=timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )

    # 保存 Refresh Token 到数据库
    save_refresh_token(db, user.id, refresh_token)

    return TokenPair(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


# ─── Token 刷新 ───

@router.post("/refresh", response_model=TokenPair)
def refresh_token(request: RefreshTokenRequest, db: Session = Depends(get_db)):
    """
    使用 Refresh Token 刷新 Access Token
    - 验证 Refresh Token 有效性
    - 吊销旧 Refresh Token（一次性使用）
    - 签发新的 Access Token 和 Refresh Token
    """
    # 验证 Refresh Token
    stored = verify_refresh_token(db, request.refresh_token)
    if not stored:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh Token 无效或已过期",
        )

    # 验证用户是否仍然有效
    user = db.query(User).filter(User.id == stored.user_id).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="用户不存在或已被禁用")

    # 吊销旧 Refresh Token（一次性使用，防止重放攻击）
    revoke_refresh_token(db, request.refresh_token)

    # 签发新的双 Token
    new_access_token = create_access_token(
        data={"sub": user.id},
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    new_refresh_token = create_refresh_token(
        data={"sub": user.id},
        expires_delta=timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )

    # 保存新 Refresh Token
    save_refresh_token(db, user.id, new_refresh_token)

    return TokenPair(
        access_token=new_access_token,
        refresh_token=new_refresh_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


# ─── 登出 ───

@router.post("/logout", response_model=Msg)
def logout(request: RefreshTokenRequest, db: Session = Depends(get_db)):
    """
    登出（吊销当前 Refresh Token）
    - 前端需清除本地存储的 access_token 和 refresh_token
    - 吊销后该 Refresh Token 无法再用于刷新
    """
    revoked = revoke_refresh_token(db, request.refresh_token)
    if revoked:
        return Msg(msg="登出成功")
    return Msg(msg="Token 已失效")


@router.post("/logout-all", response_model=Msg)
def logout_all(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """
    登出所有设备（吊销该用户的所有 Refresh Token）
    - 需要有效的 Access Token
    - 所有设备上的 Refresh Token 都将失效
    """
    count = revoke_all_refresh_tokens(db, current_user.id)
    return Msg(msg=f"已登出所有设备，共吊销 {count} 个 Refresh Token")


# ─── 找回密码 ───

CODE_EXPIRE_MINUTES = 15


@router.post("/forgot-password", response_model=ForgotPasswordResponse)
def forgot_password(request: ForgotPasswordRequest, db: Session = Depends(get_db)):
    """
    发起找回密码
    - 凭用户名或邮箱查找用户
    - 生成6位验证码，存库（生产环境应通过邮件/短信发送，此处直接返回）
    - 验证码15分钟内有效，且一次性使用
    """
    user = db.query(User).filter(
        (User.username == request.username) | (User.email == request.username)
    ).first()

    if not user:
        # 用户不存在也返回成功，防止恶意遍历探测用户名
        return ForgotPasswordResponse(
            msg="如果账号存在，验证码已生成",
            code="------",
            expires_in_seconds=CODE_EXPIRE_MINUTES * 60
        )

    # 作废该用户同用途的旧验证码
    db.query(VerificationCode).filter(
        VerificationCode.email == user.email,
        VerificationCode.purpose == "reset_password",
        VerificationCode.used == False
    ).update({"used": True})

    # 生成6位数字验证码
    code = "".join([str(secrets.randbelow(10)) for _ in range(6)])
    hashed_code = hash_password(code)  # 存哈希，不存明文

    verification = VerificationCode(
        email=user.email,
        phone=user.phone,
        code=hashed_code,
        purpose="reset_password",
        expires_at=datetime.utcnow() + timedelta(minutes=CODE_EXPIRE_MINUTES)
    )
    db.add(verification)
    db.commit()

    # MVP 直接返回明文验证码，生产环境替换为发邮件/短信
    return ForgotPasswordResponse(
        msg="如果账号存在，验证码已生成",
        code=code,
        expires_in_seconds=CODE_EXPIRE_MINUTES * 60
    )


@router.post("/reset-password", response_model=Msg)
def reset_password(request: ResetPasswordRequest, db: Session = Depends(get_db)):
    """
    重置密码
    - 验证6位验证码（一次性，15分钟内有效）
    - 验证通过后用新密码替换旧密码
    - 同时吊销该用户的所有 Refresh Token（安全措施）
    """
    # 查找未使用且未过期的验证码
    codes = db.query(VerificationCode).filter(
        VerificationCode.code != "------",  # 排除上面伪造的占位码
        VerificationCode.used == False,
        VerificationCode.expires_at > datetime.utcnow(),
        VerificationCode.purpose == "reset_password"
    ).order_by(VerificationCode.created_at.desc()).all()

    valid_code = None
    for vc in codes:
        if verify_password(request.code, vc.code):
            valid_code = vc
            break

    if not valid_code:
        raise HTTPException(status_code=400, detail="验证码无效或已过期")

    # 找到对应用户
    user = db.query(User).filter(User.email == valid_code.email).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")

    # 更新密码
    user.hashed_password = hash_password(request.new_password)
    valid_code.used = True

    # 安全措施：密码重置后吊销所有 Refresh Token
    revoke_all_refresh_tokens(db, user.id)

    db.commit()

    return Msg(msg="密码重置成功，请使用新密码登录")
