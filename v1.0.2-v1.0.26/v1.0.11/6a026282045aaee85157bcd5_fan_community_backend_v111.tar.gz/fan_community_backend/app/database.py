"""
数据库连接配置

根据 DATABASE_URL 自动判断数据库类型：
- SQLite：使用 StaticPool（单连接共享），连接池参数不生效
- MySQL/PostgreSQL：使用 QueuePool，支持完整的连接池配置
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import StaticPool, QueuePool
from app.config import get_settings
from app.logging_config import logger

settings = get_settings()

# 判断数据库类型
_db_url = settings.DATABASE_URL.lower()
_is_sqlite = _db_url.startswith("sqlite")

if _is_sqlite:
    # SQLite 使用 StaticPool，确保多线程共享同一连接
    # 连接池参数对 SQLite 不生效，但保持配置兼容
    logger.info("数据库类型: SQLite（使用 StaticPool 单连接模式）")
    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=settings.DB_ECHO,
    )
else:
    # MySQL / PostgreSQL 使用 QueuePool 连接池
    logger.info(
        f"数据库类型: 非 SQLite（使用 QueuePool 连接池） | "
        f"pool_size={settings.DB_POOL_SIZE} | "
        f"max_overflow={settings.DB_MAX_OVERFLOW} | "
        f"pool_recycle={settings.DB_POOL_RECYCLE}s | "
        f"pool_timeout={settings.DB_POOL_TIMEOUT}s | "
        f"pool_pre_ping={settings.DB_POOL_PRE_PING}"
    )
    engine = create_engine(
        settings.DATABASE_URL,
        pool_size=settings.DB_POOL_SIZE,
        max_overflow=settings.DB_MAX_OVERFLOW,
        pool_recycle=settings.DB_POOL_RECYCLE,
        pool_pre_ping=settings.DB_POOL_PRE_PING,
        pool_timeout=settings.DB_POOL_TIMEOUT,
        poolclass=QueuePool,
        echo=settings.DB_ECHO,
    )

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """依赖注入：每个请求一个独立的数据库 session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
